package neadraw.mwar;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import neadraw.mwar.world.*;
import neadraw.mwar.util.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.badlogic.gdx.scenes.scene2d.*;
import java.util.*;
import java.io.*;

public class Main implements ApplicationListener
{

	public static Random RANDOM = new Random();
	public static Batch batch;
	public static BitmapFont font;
	public static Matrix4 camera;
	public static float cameraX, cameraY, cameraWidth, cameraHeight, cameraSize = 8, updateDeltaTimer;
	public static Texture tile, gui;

	@Override
	public void create()
	{
		batch = new SpriteBatch();
		font = new BitmapFont();
		font.setUseIntegerPositions(false);
		camera = new Matrix4();
		tile = new Texture("tile.png");
		gui = new Texture("gui.png");
		World.setWorld(new MainMenuWorld());
	}

	@Override
	public void resize(int width, int height)
	{
		GameUI.resize(width, height);
	}

	@Override
	public void render()
	{
		try
		{
			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			Gdx.gl.glClearColor(0.2f, 1f, 0.2f, 1);
			float rawDelta = Gdx.graphics.getDeltaTime();
			World world = World.world;
			world.orthoCamera();
			cameraWidth = Gdx.graphics.getWidth();
			cameraHeight = Gdx.graphics.getHeight();
			if (cameraWidth > cameraHeight)
			{
				cameraWidth = cameraSize * cameraWidth / cameraHeight;
				cameraHeight = cameraSize;
			}
			else
			{
				cameraHeight = cameraSize * cameraHeight / cameraWidth;
				cameraWidth = cameraSize;
			}
			camera.setToOrtho2D(- cameraWidth / 2 + cameraX, - cameraHeight / 2 + cameraY, cameraWidth, cameraHeight);
			batch.setProjectionMatrix(camera);
			batch.begin();
			world.draw(batch, tile);
			batch.end();
			GameUI.render(rawDelta);
			if (!GameUI.groupMenu.isVisible())
			{
				updateDeltaTimer += rawDelta;
				final float worldDelta = 0.0166f;
				int updateCount = 0;
				while (updateDeltaTimer >= worldDelta)
				{
					if (updateCount >= 3)
					{
						updateDeltaTimer = 0;
						break;
					}
					world.update(rawDelta);
					updateCount ++;
					updateDeltaTimer -= worldDelta;
				}
			}
		}
		catch (Exception e)
		{
			try
			{
				PrintStream printer = new PrintStream(Gdx.files.external("mwar.log").write(false));
				e.printStackTrace(printer);
				printer.flush();
				printer.close();
			} catch (Exception f)
			{
				
			}
		}
	}

	@Override
	public void dispose()
	{
		tile.dispose();
		gui.dispose();
	}

	@Override
	public void pause()
	{
	}

	@Override
	public void resume()
	{
	}
}
