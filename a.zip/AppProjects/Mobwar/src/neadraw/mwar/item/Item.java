package neadraw.mwar.item;
import neadraw.mwar.*;
import neadraw.mwar.entity.*;

public class Item extends Nilo
{
	public Mob user;

	public boolean call ()
	{
		return true;
	}

	public float duration ()
	{
		return 0;
	}
}
