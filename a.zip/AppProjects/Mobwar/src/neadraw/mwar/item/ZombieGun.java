package neadraw.mwar.item;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.entity.*;
import neadraw.mwar.*;

public class ZombieGun extends Gun
{

	@Override
	public void draw(Batch batch, Texture tile)
	{
	}

	@Override
	public boolean call()
	{
		float raw = Main.cameraSize;
		Main.cameraSize = 0;
		super.call();
		Main.cameraSize = 5;
		super.call();
		Main.cameraSize = - 5;
		super.call();
		Main.cameraSize = raw;
		return true;
	}

	@Override
	public Bullet newBullet()
	{
		return new ZombieBullet();
	}

	@Override
	public float duration()
	{
		return 0.5f;
	}
}
