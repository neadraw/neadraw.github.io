package neadraw.mwar.item;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.entity.*;
import neadraw.mwar.world.*;

public class Gun extends Item
{

	
	@Override
	public boolean call()
	{
		Bullet bullet = newBullet();
		bullet.init(user);
		World.world.addEntity(bullet);
		return super.call();
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		super.draw(batch, tile);
		Mob user = this.user;
		float x = user.x, y = user.y, width = user.width, height = user.height;
		batch.draw(tile, x, y + height, width / 2, - height / 2, width, height, 1, 1, - user.face, 8, 0, 8, 8, false, false);
	}

	@Override
	public float duration()
	{
		return 0.1f;
	}

	public Bullet newBullet ()
	{
		return new Bullet();
	}
}
