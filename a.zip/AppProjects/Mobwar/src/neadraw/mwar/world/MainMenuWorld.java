package neadraw.mwar.world;
import neadraw.mwar.entity.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import java.io.*;
import com.badlogic.gdx.*;
import neadraw.mwar.item.*;

public class MainMenuWorld extends World
{

	public Entity door;

	@Override
	public void create()
	{
		super.create();
		player = new Player();
		player.center(0, 0);
		addEntity(player);
		player.addItem(new Gun());
		player.checkItem();
		door = new Entity();
		door.width = 8;
		door.height = 8;
		door.center(0, 7);
		addEntity(door);
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		super.draw(batch, tile);
		Entity door = this.door;
		batch.draw(tile, door.x, door.y, door.width, door.height, 0, 0, 8, 8, false, false);
	}

	@Override
	public void update(float delta)
	{
		super.update(delta);
		if (door.overlaps(player))
		{
			try
			{
				ObjectInputStream in = new ObjectInputStream(Gdx.files.external("mwar.sr").read());
				World data = (World) in.readObject();
				in.close();
				World.setWorld(data, true, false);
			}
			catch (Exception e)
			{
				World.setWorld(new Gaming1World());
			}
		}
	}
}
