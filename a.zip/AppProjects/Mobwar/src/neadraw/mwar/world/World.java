package neadraw.mwar.world;
import neadraw.mwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import neadraw.mwar.util.*;
import neadraw.mwar.entity.*;

public class World extends Nilo
{
	public SimpleList<Entity>[] entities;
	public Player player;
	public float cameraX, cameraY;

	public World()
	{
		entities = new SimpleList[64];
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		super.draw(batch, tile);
		SimpleList<Entity>[] entities = this.entities;
		for (SimpleList<Entity> list: entities)
		{
			if (list == null)
			{
				continue;
			}
			Object[] array = list.array;
			for (Object entityObject: array)
			{
				Entity entity = (Entity) entityObject;
				if (entity.dead)
				{
					continue;
				}
				batch.setColor(1, 1, 1, 1);
				entity.draw(batch, tile);
			}
		}
	}

	public void orthoCamera ()
	{
		Main.cameraX = cameraX;
		Main.cameraY = cameraY;
	}

	@Override
	public void update(float delta)
	{
		super.update(delta);
		SimpleList<Entity>[] entities = this.entities;
		for (SimpleList<Entity> list: entities)
		{
			if (list == null)
			{
				continue;
			}
			for (int i = 0; i < list.size(); i ++)
			{
				Entity entity = list.get(i);
				if (entity.dead)
				{
					list.remove(i);
					i --;
					entity.dead();
					continue;
				}
				entity.update(delta);
			}
		}
		Player player = this.player;
		Main.cameraSize = Math.min(Main.cameraSize, 32);
		final float CAMERA_SIZE = Main.cameraSize;
		final float CAMERA_MOVE_DELTA = delta * CAMERA_SIZE / 1.6f;
		final float CAMERA_TARGET_DISTANCE = CAMERA_SIZE / 3f;
		float targetX = player.centerX() + GameUI.padFaceKnobX * CAMERA_TARGET_DISTANCE;
		float targetY = player.centerY() + GameUI.padFaceKnobY * CAMERA_TARGET_DISTANCE;
		cameraX += (targetX - cameraX) * CAMERA_MOVE_DELTA;
		cameraY += (targetY - cameraY) * CAMERA_MOVE_DELTA;
		//cameraX = player.centerX();
		//cameraY = player.centerY();
		if (player.dead)
		{
			setWorld(new MainMenuWorld());
		}
	}

	public void addEntity (int family, Entity entity)
	{
		SimpleList<Entity> list = entities[family];
		if (list == null)
		{
			list = new SimpleList<Entity>();
			entities[family] = list;
		}
		list.add(entity);
		entity.create();
	}

	public void addEntity (Entity entity)
	{
		addEntity(entity.family(), entity);
	}

	public SimpleList<Entity> getEntitiesList (int family)
	{
		SimpleList<Entity> list = entities[family];
		if (list == null)
		{
			list = entities[family] = new SimpleList<Entity>();
		}
		return list;
	}

	public Object[] getEntitiesArray (int family)
	{
		return getEntitiesList(family).array;
	}

	public boolean canSave ()
	{
		return false;
	}

	public static World world;
	public static void setWorld (World newWorld, boolean dead, boolean create)
	{
		if (world != null && dead)
		{
			world.dead();
		}
		world = newWorld;
		if (create) newWorld.create();
	}

	public static void setWorld (World newWorld)
	{
		setWorld(newWorld, true, true);
	}
}
