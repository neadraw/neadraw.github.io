package neadraw.mwar.world;
import neadraw.mwar.entity.*;
import neadraw.mwar.item.*;
import java.util.*;
import neadraw.mwar.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.util.*;

public class Gaming1World extends World
{

	@Override
	public void create()
	{
		super.create();
		player = new Player();
		player.addItem(new Gun());
		player.checkItem();
		player.life = 1000000;
		addEntity(player);
		Random random = Main.RANDOM;
		for (int i = 0; i < 128; i ++)
		{
			Mob mob = new Zombie();
			mob.center(random.nextInt(100) - 50, random.nextInt(100) - 50);
			addEntity(mob);
		}
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		Utils.draw(batch, tile, 20, 0, 2, 2);
		super.draw(batch, tile);
	}

	@Override
	public boolean canSave()
	{
		return true;
	}
}
