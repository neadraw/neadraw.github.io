package neadraw.mwar;
import java.io.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;

public class Nilo implements Serializable, Cloneable
{
	public void create ()
	{
	}

	public void update (float delta)
	{
	}

	public void draw (Batch batch, Texture tile)
	{
	}

	public void dead ()
	{
	}
}
