package neadraw.mwar.util;
import neadraw.mwar.entity.*;

public class MobHurtMover extends TimerMover
{

	public MobHurtMover (Entity entity)
	{
		super(entity);
	}

	@Override
	public void act (float delta)
	{
		super.act(delta);
		if (true) return;
		Mover last = this.last;
		if (last != null)
		{
			if (last instanceof MobHurtMover)
			{
				last = last.last;
				if (last != null)
				{
					if (last instanceof MobHurtMover)
					{
						last = last.last;
						if (last != null)
						{
							if (last instanceof MobHurtMover)
							{
								last = last.last;
								if (last != null)
								{
									if (last instanceof MobHurtMover)
									{
										del();
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

