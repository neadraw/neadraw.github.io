package neadraw.mwar.util;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import neadraw.mwar.*;

public class Utils
{
	public static void draw (Batch batch, Texture texture, int regionX, int regionY, int regionWidth, int regionHeight)
	{
		if (Main.cameraSize > 32) return;
		
		float width = Main.cameraWidth, height = Main.cameraHeight;
		float startX = (float) Math.floor(Main.cameraX) - width / 2f - 1, endX = startX + width + 2;
		float startY = (float) Math.floor(Main.cameraY) - height / 2f - 1, endY = startY + height + 2;
		for (float nowX = startX; nowX <= endX; nowX += 1) {
			for (float nowY = startY; nowY <= endY; nowY += 1) {
				batch.draw(texture, nowX, nowY, 1, 1, regionX, regionY, regionWidth, regionHeight, false, false);
			}
		}
	}
}
