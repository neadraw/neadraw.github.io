package neadraw.mwar.util;
import java.io.*;

public class SimpleList<E> implements Serializable
{
	public Object[] array;

	public SimpleList(Object[] array)
	{
		this.array = array;
	}

	public SimpleList(int size)
	{
		this(new Object[size]);
	}

	public SimpleList()
	{
		this(0);
	}

	public E get(int index)
	{
		return (E) array[index];
	}

	public void add(E e)
	{
		Object[] list = array;
		int length = list.length;
		Object[] newList = new Object[length + 1];
		System.arraycopy(list, 0, newList, 0, length);
		newList[length] = e;
		array = newList;
	}

	public void remove(int index)
	{
		Object[] list = array;
		int length = list.length;
		int newLength = length - 1;
		Object[] newList = new Object[newLength];
		System.arraycopy(list, 0, newList, 0, index);
		System.arraycopy(list, index + 1, newList, index, newLength - index);
		array = newList;
	}

	public void removeFirst()
	{
		Object[] list = array;
		int length = list.length;
		int newLength = length - 1;
		Object[] newList = new Object[newLength];
		System.arraycopy(list, 1, newList, 0, newLength);
		array = newList;
	}

	public int size()
	{
		return array.length;
	}
}
