package neadraw.mwar.util;
import java.io.*;
import neadraw.mwar.entity.*;

public class Mover implements Serializable
{

	public Entity entity;
	public Mover last, next;
	public float xSpeed, ySpeed;

	public Mover (Entity entity)
	{
		this.entity = entity;
	}

	public void move (float delta)
	{
		Entity entity = this.entity;
		float deltaXSpeed = delta * getXSpeed(), deltaYSpeed = delta * getYSpeed();
		entity.x += deltaXSpeed;
		entity.y += deltaYSpeed;
		act(delta);
		Mover next = this;
		while ((next = next.next) != null)
		{
			next.act(delta);
		}
	}

	public void set (float angle, float speed)
	{
		angle = angle % 360f;
		float buff = (float) (angle * Math.PI / 180.0);
		xSpeed = (float) Math.sin(buff) * speed;
		ySpeed = (float) Math.cos(buff) * speed;
	}

	public float set (float x, float y, float speed)
	{
		float angle = (float) (Math.atan2(x, y) * 180 / Math.PI);
		set(angle, speed);
		return angle;
	}

	public void stop ()
	{
		xSpeed = 0;
		ySpeed = 0;
	}

	public void act (float delta)
	{}

	public void del()
	{
		if (next != null)
		{
			next.last = last;
		}
		if (last != null)
		{
			last.next = next;
		}
	}

	public void add(Mover mover)
	{
		if (next != null)
		{
			next.last = mover;
		}
		mover.last = this;
		mover.next = next;
		next = mover;
	}

	public float getXSpeed()
	{
		float speed = 0;
		Mover mover = this;
		do
		{
			speed += mover.xSpeed;
		} while ((mover = mover.next) != null);
		return speed;
	}

	public float getYSpeed()
	{
		float speed = 0;
		Mover mover = this;
		do
		{
			speed += mover.ySpeed;
		} while ((mover = mover.next) != null);
		return speed;
	}
}

