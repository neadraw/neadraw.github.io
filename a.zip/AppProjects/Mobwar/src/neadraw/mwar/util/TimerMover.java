package neadraw.mwar.util;
import neadraw.mwar.entity.*;

public class TimerMover extends Mover
{
	public float runTime;

	public TimerMover (Entity entity)
	{
		super(entity);
	}

	@Override
	public void act (float delta)
	{
		super.act(delta);
		runTime -= delta;
		if (runTime <= 0)
		{
			del();
			return;
		}
	}
}
