package neadraw.mwar.util;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.viewport.*;
import neadraw.mwar.world.*;
import neadraw.mwar.entity.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.*;
import com.badlogic.gdx.*;
import java.io.*;
import com.badlogic.gdx.graphics.*;

public class GameUI extends ClickListener
{
	public int event;
	public static Stage stage;
	public static Touchpad padMove, padFace;
	public static Button buttonUseItem, buttonCheckItem, buttonMenu, buttonSave, buttonBack;
	public static Label labelPlayer;
	public static Group groupMenu;

	public static float padFaceKnobX, padFaceKnobY;

	public GameUI (int event)
	{
		this.event = event;
	}

	public static void resize (int rawWidth, int rawHeight)
	{
		if (stage != null)
		{
			stage.dispose();
		}
		float width = rawWidth, height = rawHeight;
		final float STAGE_SIZE = 140;
		if (width > height)
		{
			width = STAGE_SIZE * width / height;
			height = STAGE_SIZE;
		}
		else
		{
			height = STAGE_SIZE * height / width;
			width = STAGE_SIZE;
		}
		float minSize = Math.min(width, height);
		Stage stage = new Stage(new FillViewport(width, height));
		GameUI.stage = stage;
		Gdx.input.setInputProcessor(stage);
		float unit = minSize / 7;
		Drawable drawPad = tex(28, 0, 4, 4), drawKnob = tex(29, 5, 2, 2), drawNull = tex(31, 31, 1, 1);

		Button.ButtonStyle styleButton = new Button.ButtonStyle();
		styleButton.up = drawPad;
		styleButton.down = drawNull;
		Button button = new Button(styleButton);
		button.setBounds(width - unit * 3, unit * 4, unit * 2, unit * 2);
		stage.addActor(button);
		buttonUseItem = button;

		styleButton = new Button.ButtonStyle();
		styleButton.up = drawKnob;
		styleButton.down = drawNull;
		button = new Button(styleButton);
		button.setBounds(width - unit * 3, unit * 4, unit, unit);
		button.addListener(new GameUI(3));
		stage.addActor(button);
		buttonCheckItem = button;

		Label.LabelStyle styleLabel = new Label.LabelStyle();
		styleLabel.font = Main.font;
		styleLabel.background = drawPad;
		styleLabel.fontColor = new Color(0, 0, 0, 0.5f);
		Label label = new Label("Loading...", styleLabel);
		label.setFontScale(0.4f);
		label.setAlignment(Align.center);
		label.setBounds(0, height - unit, unit * 3, unit);
		stage.addActor(label);
		labelPlayer = label;

		Group group = new Group();
		group.setSize(width, height);
		group.setVisible(false);
		stage.addActor(group);
		groupMenu = group;

		styleButton = new Button.ButtonStyle();
		styleButton.up = tex(14, 0, 7, 7);
		styleButton.down = drawNull;
		button = new Button(styleButton);
		button.addListener(new GameUI(1));
		button.setBounds(unit, height - unit * 3, unit * 2, unit * 2);
		group.addActor(button);
		buttonBack = button;

		styleButton = new Button.ButtonStyle();
		styleButton.up = tex(21, 0, 7, 7);
		styleButton.down = drawNull;
		button = new Button(styleButton);
		button.addListener(new GameUI(2));
		button.setBounds(unit * 3, height - unit * 3, unit * 2, unit * 2);
		group.addActor(button);
		buttonSave = button;

		styleButton = new Button.ButtonStyle();
		styleButton.up = tex(0, 0, 7, 7);
		styleButton.down = tex(7, 0, 7, 7);
		button = new Button(styleButton);
		button.setBounds(width - unit, height - unit, unit, unit);
		button.addListener(new GameUI(0));
		stage.addActor(button);
		buttonMenu = button;

		Touchpad.TouchpadStyle stylePad = new Touchpad.TouchpadStyle(drawPad, drawKnob);
		stylePad.knob.setMinWidth(unit);
		stylePad.knob.setMinHeight(unit);
		Touchpad pad = new Touchpad(0, stylePad);
		pad.setBounds(unit, unit, unit * 2, unit * 2);
		stage.addActor(pad);
		padMove = pad;
		pad = new Touchpad(0, stylePad);
		pad.setBounds(width - unit * 3, unit, unit * 2, unit * 2);
		stage.addActor(pad);
		padFace = pad;
	}

	public static void render (float delta)
	{
		stage.draw();
		stage.act(delta);
		World world = World.world;
		Player player = world.player;
		final float CAMERA_SIZE = Main.cameraSize;
		if (groupMenu.isVisible())
		{
			world.cameraX += padMove.getKnobPercentX() * delta * CAMERA_SIZE;
			world.cameraY += padMove.getKnobPercentY() * delta * CAMERA_SIZE;
			Main.cameraSize += padFace.getKnobPercentX() * CAMERA_SIZE * delta;
		}
		else
		{
			if (padMove.isTouched())
			{
				player.mover.set(padMove.getKnobPercentX(), padMove.getKnobPercentY(), player.speed());
			}
			else
			{
				player.mover.stop();
			}
			if (padFace.isTouched())
			{
				padFaceKnobX = padFace.getKnobPercentX();
				padFaceKnobY = padFace.getKnobPercentY();
				player.face = (float) (Math.atan2(padFaceKnobX, padFaceKnobY) * 180 / Math.PI);
			}
		}
		player.isUseItem = buttonUseItem.isPressed();
		labelPlayer.setText("FPS: " + Gdx.graphics.getFramesPerSecond() + "  " + (int) player.centerX() + "," + (int) player.centerY() + "\nHP: " + player.life);
	}

	public static Drawable tex (int x, int y, int width, int height)
	{
		return new TextureRegionDrawable(new TextureRegion(Main.gui, x, y, width, height));
	}

	@Override
	public void clicked(InputEvent event, float x, float y)
	{
		super.clicked(event, x, y);
		World world = World.world;
		Player player = world.player;
		switch (this.event)
		{
			case 0:
				Button button = buttonMenu;
				Button.ButtonStyle style = button.getStyle();
				Drawable temp = style.up;
				style.up = style.down;
				style.down = temp;
				Group menu = groupMenu;
				menu.setVisible(!menu.isVisible());
				break;
			case 1:
				World.setWorld(new MainMenuWorld());
				break;
			case 2:
				try
				{
					if (world.canSave())
					{
						ObjectOutputStream out = new ObjectOutputStream(Gdx.files.external("mwar.sr").write(false));
						out.writeObject(world);
						out.flush();
						out.close();
					}
				}
				catch (IOException e)
				{}
				break;
			case 3:
				player.checkItem();
				break;
		}
	}
}
