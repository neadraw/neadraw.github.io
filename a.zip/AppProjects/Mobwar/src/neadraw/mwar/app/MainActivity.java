package neadraw.mwar.app;
import com.badlogic.gdx.backends.android.*;
import android.os.*;
import neadraw.mwar.*;

public class MainActivity extends AndroidApplication
{
	@Override
	protected void onCreate (Bundle bundle)
	{
		super.onCreate(bundle);
		initialize(new Main());
	}
}
