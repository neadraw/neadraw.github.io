package neadraw.mwar.entity;
import neadraw.mwar.util.*;

public class MoveableEntity extends Entity
{
	public Mover mover;

	public MoveableEntity ()
	{
		mover = new Mover(this);
	}

	@Override
	public void update(float delta)
	{
		super.update(delta);
		mover.move(delta);
	}
}
