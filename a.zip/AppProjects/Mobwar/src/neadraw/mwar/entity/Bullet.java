package neadraw.mwar.entity;
import neadraw.mwar.util.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.world.*;

public class Bullet extends MoveableEntity
{
	public Mob user;
	public float runTime;

	public Bullet ()
	{
		width = height = 0.4f;
	}

	public void init (Mob user)
	{
		this.user = user;
		center(user.centerX(), user.centerY());
		mover.set(user.face, 1);
		mover.move((user.width + user.height) / 4 * 2.6f);
		mover.set(user.face, speed());
		runTime = 8;
	}

	@Override
	public void update (float delta)
	{
		super.update(delta);
		mover.move(delta);
		runTime -= delta;
		if (runTime <= 0)
		{
			dead = true;
			return;
		}
		Mob user = this.user;
		Object[] mobs = World.world.getEntitiesArray(MOB);
		for (Object object: mobs)
		{
			Mob mob = (Mob) object;
			if (mob == user)
			{
				continue;
			}
			if (overlaps(mob))
			{
				mover.move(-10);
				user.attack(mob, this, 16);
				dead = true;
				return;
			}
		}
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		super.draw(batch, tile);
		batch.draw(tile, x, y, width, height, 16, 0, 4, 4, false, false);
	}

	@Override
	public int family()
	{
		return BULLET;
	}

	public float speed ()
	{
		return 16;
	}
}
