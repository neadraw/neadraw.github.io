package neadraw.mwar.entity;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.item.*;

public class Zombie extends Moster
{
	public static Gun gun;

	public Zombie ()
	{
		if (gun == null)
		{
			gun = new ZombieGun();
		}
		width = height = 1;
		life = 200;
		item = gun;
	}

	@Override
	public void update(float delta)
	{
		super.update(delta);
		isUseItem = distance(focus) <= 10;
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		super.draw(batch, tile);
		batch.draw(tile, x, y, width, height, 24 + (hashCode() % 4) * 8, 0, 8, 8, false, false);
	}

	@Override
	public void shouldAttackFocus()
	{
		super.shouldAttackFocus();
		facingMoveFocus();
	}

	@Override
	public float speed()
	{
		return 8;
	}
}
