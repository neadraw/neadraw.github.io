package neadraw.mwar.entity;
import neadraw.mwar.util.*;
import neadraw.mwar.item.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.world.*;

public class Mob extends MoveableEntity
{
	public int life;
	public float face, itemUsedTime;
	public boolean isUseItem;
	public Item item;

	public Mob ()
	{
	}

	@Override
	public void update(float delta)
	{
		super.update(delta);
		if (life <= 0)
		{
			dead = true;
		}
		useItem(delta);
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		super.draw(batch, tile);
		Item item = this.item;
		if (item != null)
		{
			item.user = this;
			item.draw(batch, tile);
		}
	}

	public String typeMob ()
	{
		return "Mob";
	}

	public void useItem (float delta)
	{
		Item item = this.item;
		if (item != null)
		{
			item.user = this;
			item.update(delta);
			float duration = item.duration();
			if (itemUsedTime >= duration)
			{
				if (isUseItem)
				{
					if (item.call())
					{
						itemUsedTime = 0;
					}
				}
				else
				{
					itemUsedTime = duration;
				}
			}
			else
			{
				itemUsedTime += delta;
			}
		}
	}

	public void attack(Mob focus, Entity from, float value, float time, float speed)
	{
		focus.life -= value;
		MobHurtMover mover = new MobHurtMover(focus);
		mover.runTime = time;
		mover.set(focus.centerX() - from.centerX(), focus.centerY() - from.centerY(), speed);
		Mover focusMover = focus.mover;
		focusMover.add(mover);
		int bloodCount = Math.min(Math.round(value), 256);
		Mob by = this;
		focus.breakBloods(bloodCount, by);
		focus.onHurt(this, value);
	}

	public void breakBloods (int count, Mob by)
	{
		SimpleList<Entity> bloods = World.world.getEntitiesList(BLOOD);
		Object[] bloodsList = bloods.array;
		Object[] bloodsNewList = new Object[bloodsList.length + count];
		System.arraycopy(bloodsList, 0, bloodsNewList, 0, bloodsList.length);
		for (int i = bloodsList.length; i < bloodsNewList.length; i ++)
		{
			Blood blood = new Blood();
			blood.by = by;
			blood.init(this);
			onBreakBlood(blood);
			bloodsNewList[i] = blood;
			if (bloods.size() > 4096) bloods.removeFirst();
		}
		bloods.array = bloodsNewList;
		while (bloods.size() > 4096)
		{
			bloods.removeFirst();
		}
	}

	public void onBreakBlood (Blood blood)
	{
	}

	public void attack(Mob focus, Entity from, float value)
	{
		attack(focus, from, value, 0.2f, 8);
	}

	public void attack(Mob focus, float value)
	{
		attack(focus, this, value);
	}

	public void onHurt(Mob by, float value)
	{
	}

	@Override
	public int family()
	{
		return MOB;
	}

	public float speed ()
	{
		return 0;
	}

	public Mob newInstance ()
	{
		try
		{
			return getClass().newInstance();
		}
		catch (Exception e)
		{}
		return new Mob();
	}
}
