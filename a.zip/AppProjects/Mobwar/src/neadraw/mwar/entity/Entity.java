package neadraw.mwar.entity;
import neadraw.mwar.*;

public class Entity extends Nilo
{
	public final static int STAGE = 0, BLOOD = 8, BLOCK = 16, BULLET = 24, MOB = 32, FOREGROUND = 63;
	public float x, y, width, height;
	public boolean dead;

	public boolean overlaps(Entity e)
	{
		float left = x, right = left + width, bottom = y, top = bottom + height;
		float left1 = e.x, right1 = left1 + e.width, bottom1 = e.y, top1 = bottom1 + e.height;
		return left < right1 && right > left1 && bottom< top1 && top > bottom1;
	}

	public float distance(Entity e)
	{
		float rw = (width + e.width) / 2f, rh = (width + e.height) / 2f;
		float xx = Math.max(0, Math.abs(centerX() - e.centerX()) - rw);
		float yy = Math.max(0, Math.abs(centerY() - e.centerY()) - rh);
		return (float) Math.sqrt(xx * xx + yy * yy);
	}

	public float hard ()
	{
		return 1;
	}

	public int family ()
	{
		return STAGE;
	}

	public float centerX ()
	{
		return x + width / 2f;
	}

	public float centerY ()
	{
		return y + height / 2f;
	}

	public void centerX (float centerX)
	{
		x = centerX - width / 2f;
	}

	public void centerY (float centerY)
	{
		y = centerY - height / 2f;
	}

	public void center (float centerX, float centerY)
	{
		x = centerX - width / 2;
		y = centerY - height / 2;
	}

	public void bounds (float x, float y, float width, float height)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
}
