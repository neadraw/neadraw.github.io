package neadraw.mwar.entity;
import neadraw.mwar.world.*;

public class Moster extends Mob
{
	public Mob focus;

	public Moster ()
	{
		
	}

	@Override
	public void update(float delta)
	{
		super.update(delta);
		if (focus == null || focus == this)
		{
			World world = World.world;
			Object[] mobs = world.getEntitiesArray(MOB);
			String type = typeMob();
			float minDistance = Float.MAX_VALUE;
			Mob theFocus = null;
			for (Object object: mobs)
			{
				Mob mob = (Mob) object;
				if (type == mob.typeMob())
				{
					continue;
				}
				float distance = distance(mob);
				if (distance < minDistance)
				{
					minDistance = distance;
					theFocus = mob;
				}
			}
			focus = theFocus;
		}
		else if (focus.dead)
		{
			focus = null;
		}
		if (focus != null)
		{
			shouldAttackFocus();
		}
	}

	@Override
	public String typeMob()
	{
		return "Moster";
	}

	@Override
	public void onHurt(Mob by, float value)
	{
		super.onHurt(by, value);
		if (typeMob() == by.typeMob()) return;
		focus = by;
	}

	public void shouldAttackFocus ()
	{
		
	}

	public void facingMoveFocus ()
	{
		face = (float) (Math.atan2(focus.centerX() - centerX(), focus.centerY() - centerY()) * 180 / Math.PI);
		mover.set(face, speed());
	}
}
