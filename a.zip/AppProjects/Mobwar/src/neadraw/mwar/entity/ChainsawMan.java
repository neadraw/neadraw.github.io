package neadraw.mwar.entity;

public class ChainsawMan extends Moster
{
	
}
