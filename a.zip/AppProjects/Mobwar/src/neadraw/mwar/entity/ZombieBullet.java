package neadraw.mwar.entity;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import neadraw.mwar.*;

public class ZombieBullet extends Bullet
{

	@Override
	public void init(Mob user)
	{
		this.user = user;
		float face = user.face;
		center(user.centerX(), user.centerY());
		mover.set(face + Main.cameraSize, speed());
		runTime = 1;
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		batch.draw(tile, x, y, width, height, 24, 0, 4, 4, false, false);
	}

	@Override
	public float speed()
	{
		return 10;
	}
}
