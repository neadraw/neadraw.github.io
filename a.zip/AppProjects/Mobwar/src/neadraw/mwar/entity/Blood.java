package neadraw.mwar.entity;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import java.util.*;
import neadraw.mwar.*;

public class Blood extends MoveableEntity
{
	public float red, xSpeed, ySpeed;

	public Blood()
	{
	}

	public Mob by;
	public float runTime;

	public void init(Mob from)
	{
		Random random = Main.RANDOM;
		width = (float) (random.nextInt(8) + 1) / 8f * from.width;
		height = (float) (random.nextInt(8) + 1) / 8f * from.height;
		center(from.centerX(), from.centerY());
		float speed = (float) random.nextInt(1700) / 100f + 1f;
		double degrees = Math.atan2(by.centerX() - from.centerX(), by.centerY() - from.centerY()) + Math.random() * 0.8 - 0.4;
		xSpeed = (float) Math.sin(degrees) * speed;
		ySpeed = (float) Math.cos(degrees) * speed;
		runTime = (float) random.nextInt(17) / 8f + 2;
		red = (float) (random.nextInt(256) + 256) / 512f;
	}

	@Override
	public void update(float delta)
	{
		super.update(delta);
		x += xSpeed * delta;
		y += ySpeed * delta;
		if (runTime >= 12)
		{
			dead = true;
			return;
		}
		runTime += delta;
		if (by == null) return;
		if (by.dead)
		{
			by = null;
			return;
		}
		if (runTime >= 8)
		{
			xSpeed = 0;
			ySpeed = 0;
			return;
		}
		if (overlaps(by))
		{
			float health = 1;
			by.life += health;
			dead = true;
		}
	}
	
	@Override
	public void draw(Batch batch, Texture tile)
	{
		float width = this.width, height = this.height;
		float r = red, g = 0, b = 0;
		batch.setColor(r, g, b, 1 - runTime / 12f);
		batch.draw(tile, x, y, width / 2f, height / 2f, width, height, 1, 1, Math.min(runTime, 8f) * 180 * (hashCode() % 4 + 1), 16, 4, 4, 4, false, false);
	}

	@Override
	public int family()
	{
		return BLOOD;
	}
}
