package neadraw.mwar.entity;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import neadraw.mwar.item.*;
import neadraw.mwar.util.*;

public class Player extends Mob
{
	public SimpleList<Item> items;
	public int itemsIndex;

	public Player ()
	{
		life = 100;
		width = height = 1;
		items = new SimpleList<>();
	}

	@Override
	public void draw(Batch batch, Texture tile)
	{
		super.draw(batch, tile);
		batch.draw(tile, x, y, width, height, 0, 0, 8, 8, false, false);
	}

	public float speed ()
	{
		return 8;
	}

	public Item getItem (int index)
	{
		if (index >= items.size()) return null;
		return items.get(index);
	}

	public Item getItem ()
	{
		return getItem(itemsIndex);
	}

	public void addItem (Item item)
	{
		items.add(item);
	}

	public void checkItem ()
	{
		itemsIndex ++;
		if (itemsIndex >= items.size())
		{
			itemsIndex = 0;
		}
		item = getItem();
	}

	public Item findItemByClass (Class<?> cla)
	{
		for (int i = 0; i < items.size(); i ++)
		{
			Item item = items.get(i);
			if (cla.isInstance(item))
			{
				return item;
			}
		}
		return null;
	}

	@Override
	public String typeMob()
	{
		return "Player";
	}

	@Override
	public Mob newInstance()
	{
		return new Player();
	}
}
