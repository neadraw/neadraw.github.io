package com.csqnew.klgk;
import android.app.*;
import android.os.*;
import android.view.*;
import java.util.*;
import android.content.*;
import android.graphics.*;
import java.io.*;
import android.graphics.drawable.*;
public class Main extends Activity
implements View.OnTouchListener {
	final static int CARD_SIZE = 13;
	List<int[]> cards;
	List<Integer> checkedCards;
	float scale, x, y;
	Bitmap tile;
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		View view = new View(this) {
			@Override
			protected void onDraw (Canvas canvas) {
				super.onDraw(canvas);
				Main main = Main.this;
				Paint paint = new Paint();
				float width = canvas.getWidth(), height = canvas.getHeight();
				float min = Math.min(width, height);
				float x = (width - min) / 2, y = (height - min) / 2;
				main.x = x;
				main.y = y;
				float scale = min / 100f;
				main.scale = scale;
				Bitmap tile = main.tile;
				int srcSize = 64;
				List<int[]> cards = main.cards;
				List<Integer> checkedCards = main.checkedCards;
				Matrix matrix = new Matrix();
				int cardSize = CARD_SIZE;
				matrix.postScale(scale, scale);
				matrix.postTranslate(x, y);
				paint.setColor(0xffa0a0a0);
				canvas.drawRect(0, 0, width, height, paint);
				canvas.setMatrix(matrix);
				paint.setColor(0xffc0c0c0);
				canvas.drawRect(0, 0, 100, 100, paint);
				Rect src = new Rect(), dst = new Rect();
				for (int[] card : cards) {
					int srcX = card[0] * srcSize;
					src.set(srcX, 0, srcX + srcSize, srcSize);
					dst.set(card[1], card[2], card[1] + cardSize, card[2] + cardSize);
					paint.setColor(0xffffffff);
					canvas.drawBitmap(tile, src, dst, paint);
					if (card[3] == 1) {
						paint.setColor(0x80000000);
						canvas.drawRect(dst, paint);
					}
				}
				for (int i = 0; i < 8; i ++) {
					paint.setColor(i % 2 == 0 ? 0x20202020 : 0x40202020);
					canvas.drawRect(i * 10, 90, i * 10 + 10, 100, paint);
				}
				paint.setColor(0xffffffff);
				src.set(64, 0, 76, 6);
				dst.set(80, 90, 100, 100);
				canvas.drawBitmap(tile, src, dst, paint);
				for (int i = 0; i < checkedCards.size(); i ++) {
					int type = checkedCards.get(i);
					int srcX = type * srcSize;
					src.set(srcX, 0, srcX + srcSize, srcSize);
					dst.set(i * 10, 90, i * 10 + 10, 100);
					canvas.drawBitmap(tile, src, dst, paint);
				}
			}
		};
		view.setLongClickable(true);
		view.setOnTouchListener(this);
		cards = new ArrayList<>();
		checkedCards = new ArrayList<>();
		try {
			InputStream in = getAssets().open("tile.png");
			tile = BitmapFactory.decodeStream(in);
			in.close();
		} catch (Throwable e) {}
		reset();
		setContentView(view);
	}
	public boolean onTouch (View view, MotionEvent event) {
		int action = event.getAction();
		if (action != MotionEvent.ACTION_UP) return true;
		int count = event.getPointerCount();
		float scale = this.scale;
		float tx = x, ty = y;
		for (int i = 0; i < count; i ++) {
			float x = event.getX(i), y = event.getY(i);
			click((int) ((x - tx) / scale), (int) ((y - ty) / scale));
		}
		view.invalidate();
		return false;
	}
	void reset () {
		List<int[]> cards = this.cards;
		List<Integer> checkedCards = this.checkedCards;
		int cardSize = CARD_SIZE;
		cards.clear();
		checkedCards.clear();
		int typeCount = 5, maxX = 101 - cardSize, maxY = 91 - cardSize;
		for (int i = 0; i < typeCount * 100; i ++) {
			for (int c = 0; c < 3; c ++) {
				int[] card = new int[] { i % typeCount, (int) (Math.random() * maxX), (int) (Math.random() * maxY), 0 };
				cards.add(card);
			}
		}
		click(- 1, 0);
	}
	void click (int x, int y) {
		if (x > 80 && y > 90) {
			reset();
			return;
		}
		if (y > 90) return;
		List<int[]> cards = this.cards;
		List<Integer> checkedCards = this.checkedCards;
		Rect rect = new Rect(), checkCardRect = new Rect();
		int checkedCard[] = null, checkedCardIndex = 0;
		int cardSize = CARD_SIZE;
		for (int i = 0; i < cards.size(); i ++) {
			int[] card = cards.get(i);
			rect.set(card[1], card[2], card[1] + cardSize, card[2] + cardSize);
			if (checkedCard != null) {
				if (rect.intersect(checkCardRect)) {
					checkedCard = null;
				}
			}
			if (rect.contains(x, y)) {
				checkedCardIndex = i;
				checkedCard = card;
				checkCardRect.set(rect);
			}
		}
		if (checkedCard != null) {
			cards.remove(checkedCardIndex);
			checkedCards.add(checkedCard[0]);
			for (int i = 0; i < checkedCards.size() - 2; i ++) {
				int type = checkedCards.get(i);
				if (checkedCards.get(i + 1).equals(type) && checkedCards.get(i + 2).equals(type)) {
					checkedCards.remove(i);
					checkedCards.remove(i);
					checkedCards.remove(i);
					i --;
				}
			}
			if (checkedCards.size() >= 8 || (checkedCards.size() > 0 && cards.size() == 0)) {
				reset();
				new AlertDialog.Builder(this).setTitle("游戏结束").setMessage("即使如此我也依然爱着你").setCancelable(false).setPositiveButton(android.R.string.cancel, null).show();
				return;
			}
		}
		for (int i = 0; i < cards.size(); i ++) {
			int[] card = cards.get(i);
			card[3] = 0;
			for (int j = i + 1; j < cards.size(); j ++) {
				checkedCard = cards.get(j);
				rect.set(checkedCard[1], checkedCard[2], checkedCard[1] + cardSize, checkedCard[2] + cardSize);
				if (rect.intersect(card[1], card[2], card[1] + cardSize, card[2] + cardSize)) {
					card[3] = 1;
					break;
				}
			}
			if (card[3] == 1) continue;
		}
		if (cards.size() == 0) {
			new AlertDialog.Builder(this).setTitle("Alert").setMessage("SBSBSBSBSBSBSBSBSBSBSBSBSBSSBSBSBSBSBSBSBSBSBSBSBBSBSBSBSBSBSSBSBSBSBSBSBSBSBSBBSBSBSBSBSBSB").setCancelable(false).setPositiveButton(android.R.string.cancel, null).show();
			reset();
		}
	}
}
