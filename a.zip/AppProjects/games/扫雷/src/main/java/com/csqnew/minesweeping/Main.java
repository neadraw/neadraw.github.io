package com.csqnew.minesweeping;

import android.app.*;
import android.os.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.graphics.*;
import android.widget.*;
import android.content.res.*;
import android.text.*;
import java.io.*;
import java.util.*;

public class Main extends Activity
implements View.OnClickListener, View.OnLongClickListener {

	MyView view;
	static Bitmap tile;

	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {
			AssetManager assets = getAssets();
			tile = BitmapFactory.decodeStream(assets.open("tile.png"));
		} catch (Throwable e) {}
		MyView view = new MyView(this);
		RelativeLayout contentView = new RelativeLayout(this);
		LinearLayout toolbar = new LinearLayout(this);
		toolbar.setLayoutParams(new LinearLayout.LayoutParams(- 1, - 2));
		toolbar.setOrientation(LinearLayout.HORIZONTAL);
		toolbar.setGravity(Gravity.CENTER);
		TextView button = new Button(this);
		button.setText("^_^");
		button.setOnClickListener(this);
		button.setOnLongClickListener(this);
		toolbar.addView(button);
		contentView.addView(view);
		contentView.addView(toolbar);
		setContentView(contentView);
		this.view = view;
	}

	String str = "";
	@Override
	public void onClick (View p1) {
		final MyView view = this.view;
		final EditText contentView = new EditText(this);
		contentView.setText(str);
		new AlertDialog.Builder(this).setTitle("Seed").setNegativeButton("Cancel", null).setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick (DialogInterface p1, int p2) {
				str = contentView.getText().toString();
				try {
					MyView.defaultSeed = Long.parseLong(str);
					view.reset();
				} catch (Exception e) {
					try
					{
						if (! "/".equals(str.substring(0, 1))) throw new Exception();
						byte[][] grid = new byte[Integer.parseInt(str.substring(1, 3), 16)][Integer.parseInt(str.substring(3, 5), 16)];
						for (int x = 0; x < grid.length; x ++)
						{
							byte[] line = grid[x];
							for (int y = 0; y < line.length; y ++)
							{
								line[y] = 1;
							}
						}
						for (int i = 5; i < str.length(); i += 4)
						{
							grid[Integer.parseInt(str.substring(i, i + 2), 16)][Integer.parseInt(str.substring(i + 2, i + 4), 16)] = 2;
						}
						view.reset(grid);
					} catch (Exception f)
					{
						MyView.defaultSeed = str.hashCode();
						view.reset();
					}
				}
			}
		}).setView(contentView).show();
	}

	@Override
	public boolean onLongClick(View p1) {
		MyView.showTnt =! MyView.showTnt;
		view.invalidate();
		return false;
	}
}

class MyView extends View
implements View.OnClickListener, View.OnLongClickListener {

	float x, y, scale;
	byte type;
	byte[][] grid;
	static long defaultSeed = 520;
	static boolean showTnt;
	

	public MyView (Context context) {
		super(context);
		setLongClickable(true);
		setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
		reset();
		setOnClickListener(this);
		setOnLongClickListener(this);
		setBackgroundColor(0xff000000);
	}

	@Override
	protected void onDraw (Canvas canvas) {
		super.onDraw(canvas);
		scale = Math.min(canvas.getWidth(), canvas.getHeight()) / 8f;
		byte[][] grid = this.grid;
		int width = grid.length, height = grid[0].length;
		float scale = this.scale;
		Paint paint = new Paint();
		Matrix matrix = new Matrix();
		matrix.postTranslate(x, y);
		matrix.postScale(scale, scale, x, y);
		canvas.setMatrix(matrix);
		Bitmap tile = Main.tile;
		Rect src = new Rect();
		RectF dst = new RectF();
		for (int x = 0; x < width; x ++) {
			for (int y = 0; y < height; y ++) {
				dst.set(x, y, x + 1, y + 1);
				byte col = grid[x][y];
				if (col > 0) {
					src.set(0, 0, 8, 8);
					canvas.drawBitmap(tile, src, dst, paint);
				} else if (col == 0) {
					int count = getCount(x, y, width, height);
					src.set(8, 8 * count, 16, 8 * count + 8);
					canvas.drawBitmap(tile, src, dst, paint);
				} else if (col < 0) {
					src.set(0, 8, 8, 16);
					canvas.drawBitmap(tile, src, dst, paint);
				}
			}
		}
		if (showTnt)
		{
			for (int x = 0; x < width; x ++) {
				for (int y = 0; y < height; y ++) {
					byte col = grid[x][y];
					if (Math.abs(col) == 2)
					{
						dst.set(x, y, x + 1, y + 1);
						src.set(0, 16, 8, 24);
						canvas.drawBitmap(tile, src, dst, paint);
					}
				}
			}
		}
	}

	float lastTouchedX, lastTouchedY, firstTouchedX, firstTouchedY;
	boolean isMoved;

	@Override
	public boolean onTouchEvent (MotionEvent event) {
		int action = event.getAction();
		float x = event.getX(), y = event.getY();
		switch (action) {
			case MotionEvent.ACTION_DOWN:
				lastTouchedX = x;
				lastTouchedY = y;
				firstTouchedX = x;
				firstTouchedY = y;
				break;
			case MotionEvent.ACTION_MOVE:
				float tranX = x - lastTouchedX, tranY = y - lastTouchedY;
				this.x += tranX;
				this.y += tranY;
				lastTouchedX = x;
				lastTouchedY = y;
				tranX = firstTouchedX - lastTouchedX;
				tranY = firstTouchedY - lastTouchedY;
				float maxLength = getResources().getDisplayMetrics().density * 4;
				if (Math.abs(tranX) >= maxLength || Math.abs(tranY) >= maxLength) {
					isMoved = true;
				}
				break;
			case MotionEvent.ACTION_UP:
		}
		invalidate();
		return super.onTouchEvent(event);
	}

	@Override
	public void onClick (View p1) {
		if (isMoved) {
			isMoved = false;
			return;
		}
		byte[][] grid = this.grid;
		int x = (int) ((lastTouchedX - this.x) / scale);
		int y = (int) ((lastTouchedY - this.y) / scale);
		int width = grid.length, height = grid[0].length;
		if (x >= 0 && x < width && y >= 0 && y < height) {
			click(x, y, width, height);
		}
		invalidate();
		for (int gx = 0; gx < width; gx ++) {
			for (int gy = 0; gy < height; gy ++) {
				byte col = grid[gx][gy];
				if (Math.abs(col) == 1) {
					return;
				}
			}
		}
		new AlertDialog.Builder(getContext()).setTitle("SHABI").setPositiveButton("Cancel", null).setCancelable(false).show();
	}

	void click (int x, int y, int width, int height) {
		if (x < 0 || y < 0 || x >= width || y >= height) return;
		byte[][] grid = this.grid;
		byte col = grid[x][y];
		if (col == 1) {
			grid[x][y] = 0;
			int count = getCount(x, y, width, height);
			if (count == 0) {
				click(x - 1, y - 1, width, height);
				click(x, y - 1, width, height);
				click(x + 1, y - 1, width, height);
				click(x - 1, y, width, height);
				click(x + 1, y, width, height);
				click(x - 1, y + 1, width, height);
				click(x, y + 1, width, height);
				click(x + 1, y + 1, width, height);
			}
		} else if (col < 0) {
			grid[x][y] = (byte) - col;
		} else if (col == 2) {
			reset();
			new AlertDialog.Builder(getContext()).setTitle("GAME OVER").setPositiveButton("Cancel", null).setCancelable(false).show();
		}
	}

	int getCount (int x, int y, int width, int height) {
		int count = 0;
		for (int tx = - 1; tx < 2; tx ++) {
			int mx = x + tx;
			if (mx < 0 || mx >= width) {
				continue;
			}
			for (int ty = - 1; ty < 2; ty ++) {
				int my = y + ty;
				if (my < 0 || my >= height) {
					continue;
				}
				byte col2 = grid[mx][my];
				if (Math.abs(col2) == 2) {
					count ++;
				}
			}
		}
		return count;
	}

	@Override
	public boolean onLongClick (View p1) {
		if (isMoved) {
			isMoved = false;
			return false;
		}
		byte[][] grid = this.grid;
		int x = (int) ((lastTouchedX - this.x) / scale);
		int y = (int) ((lastTouchedY - this.y) / scale);
		int width = grid.length, height = grid[0].length;
		if (x >= 0 && x < width && y >= 0 && y < height) {
			byte col = grid[x][y];
			grid[x][y] = (byte) - col;
		}
		invalidate();
		isMoved = true;
		return false;
	}

	void reset (long seed) {
		Random random = new Random(seed);
		int r = random.nextInt(random.nextInt(100));
		int width = random.nextInt(50) + 1, height = random.nextInt(50) + 1;
		byte[][] grid = new byte[width][height];
		for (int x = 0; x < width; x ++) {
			for (int y = 0; y < height; y ++) {
				int randomValue = random.nextInt(100);
				if (randomValue > r) {
					grid[x][y] = 1;
				} else {
					grid[x][y] = 2;
				}
			}
		}
		this.grid = grid;
		x = 0;
		y = 0;
		invalidate();
	}

	void reset () {
		try
		{
			ObjectInputStream oin = new ObjectInputStream(new FileInputStream("/sdcard/New/minesweeping/ser.j"));
			reset((byte[][])oin.readObject());
			oin.close();
		} catch (Exception e) {
			reset(defaultSeed);
		}
	}

	void reset (byte[][] grid) {
		this.grid = grid;
		x = 0;
		y = 0;
	}
}
