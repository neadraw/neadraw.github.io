package com.csqnew.nbwar.entity.mob;

public interface Moster {

	public void setFocus (Mob mob)

	public Mob getFocus ()
}
