package com.csqnew.nbwar.entity.mob;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.gaming.Gaming;
import com.csqnew.nbwar.util.TimerMover;
import com.csqnew.nbwar.entity.boss.NBZombie;
import com.csqnew.nbwar.entity.boss.KunKun;
import com.csqnew.nbwar.entity.ThreeHeader;
import com.csqnew.nbwar.item.*;

public class NBCow extends NewbeHuman implements Moster
{

	public NBCow ()
	{
		speed = 5;
		width = height = 1f;
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		float w = width, h = height;
		batch.draw(Textures.nb_cow, x, y, w, h, Math.abs(hashCode() % 4) * 8, 0, 8, 8, false, false);
	}

	@Override
	public void dead (Gaming game) throws Exception
	{
		super.dead(game);
		Knife knife = new Knife();
		for (int i = 0; i < 12; i ++) {
			Zombie zombie = new Zombie();
			zombie.health = 72;
			zombie.width = 0.5f;
			zombie.height = 0.5f;
			zombie.item = knife;
			TimerMover mover = new TimerMover(zombie);
			mover.maxTime = 0.5f;
			mover.set((float) (Math.random() * 360), 8);
			zombie.mover.add(mover);
			zombie.speed = 12 + i / 10f;
			zombie.focusMob = focusMob;
			zombie.setX(getX());
			zombie.setY(getY());
			NBZombie.AfterEffect effect = new NBZombie.AfterEffect(zombie);
			game.addEntity("background", effect);
			game.addEntity("mob", zombie);
		}
		ThreeHeader header = new ThreeHeader();
		header.focus = focusMob;
		header.setX(getX());
		header.setY(getY());
	}

	@Override
	public Mob getFocus ()
	{
		return focusMob;
	}

	@Override
	public void setFocus (Mob mob)
	{
		focusMob = mob;
	}
}
