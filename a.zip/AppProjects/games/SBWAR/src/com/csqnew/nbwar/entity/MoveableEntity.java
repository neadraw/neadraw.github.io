package com.csqnew.nbwar.entity;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.gaming.*;

public class MoveableEntity extends Entity {

	public Mover mover;

	public MoveableEntity() {
		mover = new Mover(this);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception {
		super.act(game, delta);
		mover.move(game, delta);
	}
}
