package com.csqnew.nbwar.util;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.gaming.*;

public class TimerMover extends Mover {

	public float runTime, maxTime;

	public TimerMover (Entity entity) {
		super(entity);
	}

	@Override
	public void act (Gaming game, float delta) {
		super.act(game, delta);
		runTime += delta;
		if (runTime >= maxTime) {
			del();
			return;
		}
	}
}
