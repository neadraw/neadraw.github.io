package com.csqnew.nbwar.entity.mob;
import com.csqnew.nbwar.item.*;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.math.collision.*;
import com.badlogic.gdx.utils.*;
import java.util.*;

public class Human extends Mob {

	public static Human human = new Human();
	public Item item;
	public boolean isUseItem;
	public float itemUsedTime;

	@Override
	public void act (Gaming game, float delta) throws Exception {
		super.act(game, delta);
		useItem(game, delta);
	}

	public void useItem (Gaming game, float delta) throws Exception
	{
		if (item != null) {
			item.user = this;
			item.act(game, delta);
			if (itemUsedTime >= item.duration) {
				if (isUseItem) {
					if (item.call(game)) {
						itemUsedTime = 0;
					}
				} else {
					itemUsedTime = item.duration;
				}
			} else {
				itemUsedTime += delta;
			}
		}
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		if (item != null) {
			item.user = this;
			item.draw(batch);
		}
	}

	@Override
	public void drawBox (Batch batch) throws Exception {
		super.drawBox(batch);
		if (item != null) {
			item.user = this;
			item.drawBox(batch);
		}
	}

	public void addItem (Item item) {
	}
}
