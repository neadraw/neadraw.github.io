package com.csqnew.nbwar.entity;

public class Wall extends Entity {

	public float hard = 2048f;

	@Override
	public float hard () {
		return hard;
	}
}
