package com.csqnew.nbwar.item;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.graphics.g2d.*;

public class Item extends Nilo {

	public Human user;
	public float duration;

	public boolean call(Gaming game) throws Exception {
		return true;
	}

	public void drawBox(Batch batch) throws Exception {}
}
