package com.csqnew.nbwar.entity;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;

public abstract class TextureEntity extends Entity {

	public static TextureRegion region = new TextureRegion();

	@Override
	public void draw (Batch batch) throws Exception {
		batch.draw(texture(), x, y, width, height);
	}

	public static TextureRegion texture (Texture src, int x, int y, int w, int h)
	{
		TextureRegion region = TextureEntity.region;
		region.setTexture(src);
		region.setRegion(x, y, w, h);
		return region;
	}

	public abstract TextureRegion texture ()
}
