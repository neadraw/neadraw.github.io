package com.csqnew.nbwar.entity;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.*;
import org.json.*;

public class Entity extends Nilo {

	public byte mode = 0;
	public float x, y, width, height;

	public Rectangle asRectangle() {
		return new Rectangle(x, y, width, height);
	}

	public boolean overlaps(Entity e) {
		float left = x, right = left + width, bottom = y, top = bottom + height;
		float left1 = e.x, right1 = left1 + e.width, bottom1 = e.y, top1 = bottom1 + e.height;
		return left < right1 && right > left1 && bottom< top1 && top > bottom1;
	}

	public float distance(Entity e) {
		float rw = (width + e.width) / 2f, rh = (width + e.height) / 2f;
		float xx = Math.max(0, Math.abs(getX() - e.getX()) - rw);
		float yy = Math.max(0, Math.abs(getY() - e.getY()) - rh);
		return (float) Math.sqrt(xx * xx + yy * yy);
	}

	public float hard () {
		return 0.4f;
	}

	public float getX() {
		return x + width / 2;
	}

	public void setX(float x) {
		this.x = x - width / 2;
	}

	public void setY(float y) {
		this.y = y - height / 2;
	}

	public float getY() {
		return y + height / 2;
	}

	public void drawBox(Batch batch) throws Exception {
		Texture green = Main.TEXTURE_WHITE;
		float l = 0.02f;
		Color lastColor = batch.getColor();
		batch.setColor(Color.GREEN);
		batch.draw(green, x - l, y, l, height);
		batch.draw(green, x, y + height, width, l);
		batch.draw(green, x, y - l, width, l);
		batch.draw(green, x + width, y, l, height);
		Texture red = green;
		batch.setColor(Color.RED);
		batch.draw(red, x - l - l, y - l, l, height + l + l);
		batch.draw(red, x - l, y + height + l, width + l * 2, l);
		batch.draw(red, x - l, y - l - l, width + l * 2, l);
		batch.draw(red, x + width + l, y - l, l, height + l * 2);
		batch.setColor(lastColor);
	}

	public void onCollisionBlock(Entity block, boolean isVertical) throws Exception {
	}

	@Override
	public void save (JSONObject object) throws Exception {
		super.save(object);
		JSONArray bounds = new JSONArray();
		object.put("mode", mode);
		bounds.put(x);
		bounds.put(y);
		bounds.put(width);
		bounds.put(height);
		object.put("bounds", bounds);
	}

}
