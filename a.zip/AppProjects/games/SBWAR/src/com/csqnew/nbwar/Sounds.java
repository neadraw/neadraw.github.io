package com.csqnew.nbwar;
import com.badlogic.gdx.audio.*;
import java.lang.reflect.*;
import com.badlogic.gdx.*;

public class Sounds
{
	public static Sound chainsaw, gun_call, player_hurt,
	tnt, zombie_hurt;

	public static void create ()
	{
		try
		{
			Field[] fields = Sounds.class.getFields();
			for (Field field: fields)
			{
				field.set(null, Gdx.audio.newSound(Gdx.files.internal("music/" + field.getName() + ".ogg")));
			}
		}
		catch (Exception e)
		{
			Gdx.files.external("sbwar.log").writeString(e.toString(), false);
		}
	}

	public static void dispose()
	{
		try
		{
			Field[] fields = Sounds.class.getFields();
			for (Field field: fields)
			{
				((Sound)field.get(null)).dispose();
			}
		}
		catch (Exception e)
		{}
	}
}
