package com.csqnew.nbwar.entity.mob;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.graphics.g2d.*;

public class MobHelper extends NewbeHuman {

	public Mob mob;
	public Mob mobFocus;

	public MobHelper() {
		width = height = 0.8f;
		speed = 6;
	}

	@Override
	public void act(Gaming game, float delta) throws Exception {
		Mob mobFocus = this.mobFocus;
		if (mobFocus != null) {
			focusMob = mobFocus; 
			if (mobFocus.mode == 1) {
				mobFocus = null;
				this.mobFocus = null;
			}
		}
		super.act(game, delta);
	}

	@Override
	public void draw(Batch batch) throws Exception {
		super.draw(batch);
		batch.draw(Textures.helper, x, y, width, height);
	}

	@Override
	public void onHurt(Gaming game, Mob by, float value) throws Exception {
		super.onHurt(game, by, value);
		if (mobFocus == null) focusMob = by;
	}
}
