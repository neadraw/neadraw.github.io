package com.csqnew.nbwar.entity.boss;
import com.csqnew.nbwar.entity.mob.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.item.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.*;
import java.util.*;

public class KunKun extends Human implements Moster
{

	@Override
	public void setFocus (Mob mob)
	{
		focusMob = mob;
	}

	@Override
	public Mob getFocus ()
	{
		return focusMob;
	}
	
	public KunBar kun;
	public Mob focusMob;

	public KunKun () {
		width = height = 2;
		health = 5200;
		kun = new KunBar();
		item = kun;
		speed = 4;
	}

	@Override
	public void act (Gaming game, float delta) throws Exception {
		super.act(game, delta);
		Mob focus = focusMob;
		if (focus != null) {
			isUseItem = true;
			angle = (float) (Math.atan2(focus.getX() - getX(), focus.getY() - getY()) * 180d / Math.PI);
			if (distance(focus) > 3) {
				mover.set(angle, speed);
			} else {
				mover.stop();
			}
			if (focus.mode == 1) {
				focusMob = null;
			}
		}
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		batch.draw(Textures.alan, x, y, width, height);
	}

	public static class KunBar extends Item {

		public KunBar () {
			duration = 2f;
		}

		@Override
		public boolean call (Gaming game) throws Exception {
			int count = 128;
			Human user = this.user;
			if (user instanceof Player) {
				count = 512;
			}
			if (user instanceof KunKun) {
				count = 1024;
			}
			for (int i = 0; i < count; i ++) {
				double degrees = user.angle / 180f * Math.PI;
				Child child = new Child(degrees);
				child.setX(user.getX() + (float) (Math.sin(degrees) * 3.6f));
				child.setY(user.getY() + (float) (Math.cos(degrees) * 3.6f));
				child.user = user;
				game.addEntity("sperm", child);
			}
			return super.call(game);
		}

		@Override
		public void draw (Batch batch) throws Exception {
			super.draw(batch);
			double degrees = user.angle / 180 * Math.PI;
			batch.draw(Textures.kunbar, user.getX() - 1.6f + (float) (Math.sin(degrees) * 2.4f), user.getY() - 1.6f + (float) (Math.cos(degrees) * 2.4f), 1.6f, 1.6f, 3.2f, 3.2f, 1, 1, 45 - user.angle, 0, 0, 8, 8, false, false);
		}
	}

	public static class Child extends Entity {

		float runTime, xSpeed, ySpeed;
		Human user;

		public Child (double userDegress) {
			Random random = Main.RANDOM;
			width = (float) (random.nextInt(32) + 1) / 32f;
			height = (float) (random.nextInt(32) + 1) / 32f;
			float speed =  (float) random.nextInt(1000) / 50f;
			double degrees = (Math.random()) - 0.5f + userDegress;
			xSpeed = (float) Math.sin(degrees) * speed;
			ySpeed = (float) Math.cos(degrees) * speed;
		}

		@Override
		public void act (Gaming game, float delta) throws Exception {
			super.act(game, delta);
			x += xSpeed * delta;
			y += ySpeed * delta;
			runTime += delta;
			if (runTime >= 4) {
				mode = 1;
			} else if (runTime >= 2) {
				xSpeed = 0;
				ySpeed = 0;
			}
			Object[] mobs = game.mobs.list;
			Human user = this.user;
			for (int i = 0; i < mobs.length; i ++) {
				Mob mob = (Mob) mobs[i];
				if (mob == user) continue;
				if (overlaps(mob)) {
					mode = 1;
					user.attack(game, this, mob, user instanceof Player ? 8 : 4, 0.1f, 4);
					return;
				}
			}
		}

		@Override
		public void draw (Batch batch) throws Exception {
			super.draw(batch);
			int hash = hashCode();
			batch.setColor((hash >> 8) % 2, (hash >> 16) % 2, (hash >> 24) % 2, 1 - runTime / 4f);
			batch.draw(Main.TEXTURE_WHITE, x, y, width, height);
		}
	}
}
