package com.csqnew.nbwar.item;
import com.csqnew.nbwar.entity.ThreeHeader;
import com.csqnew.nbwar.gaming.Gaming;
import com.csqnew.nbwar.entity.mob.Human;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.csqnew.nbwar.Main;
import com.csqnew.nbwar.entity.ThreeHeader.Bullet;
import com.csqnew.nbwar.entity.mob.Mob;
import com.csqnew.nbwar.util.Mover;

public class Throder extends Item
{
	TH th;

	public Throder ()
	{
		duration = 0.04f;
		th = new TH();
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		TH th = this.th;
		th.user = user;
		th.act(Main.GAMING, 0);
		th.draw(batch);
	}

	@Override
	public boolean call (Gaming game) throws Exception
	{
		TH th = this.th;
		th.user = user;
		th.breakBullets(game);
		return super.call(game);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		super.act(game, delta);
		Human user = this.user;
		TH th = this.th;
		th.mode = 1;
		th.user = user;
		th.act(game, delta);
		//user.mover.move(null, 4 * delta);
	}

	public static class TH extends ThreeHeader
	{

		@Override
		public void act (Gaming game, float delta) throws Exception
		{
			if (mode == 1)
			{
				Human user = this.user;
				setX(user.getX());
				setY(user.getY());
				angle = user.angle;
			}
			else
			{
				super.act(game, delta);
			}
		}

		@Override
		public ThreeHeader.Bullet newBullet ()
		{
			MyBullet bullet = new MyBullet();
			bullet.initBullet(this);
			return bullet;
		}

		@Override
		public void onHurt (Gaming game, Mob by, float value) throws Exception
		{
			super.onHurt(game, by, value);
			focus = by;
		}

		@Override
		public void drawBox (Batch batch) throws Exception
		{
			batch.setColor(0, 0, 0, 1);
			batch.draw(Main.TEXTURE_WHITE, x - 20, y - 20, width + 40, height + 40);
		}
	}

	public static class MyBullet extends ThreeHeader.Bullet
	{
		@Override
		public void act (Gaming game, float delta) throws Exception
		{
			if (runTime >= 1.5f)
			{
				mode = 1;
				return;
			}
			runTime += delta;
			ThreeHeader from = this.from;
			Mob user = from.mode == 0 ? from : from.user;
			Mover mover = this.mover;
			Object[] mobs = game.mobs.list;
			for (int i = 0; i < mobs.length; i ++)
			{
				Mob mob = (Mob) mobs[i];
				if (mob == user) continue;
				if (overlaps(mob))
				{
					mover.move(null, - 1);
					user.attack(game, this, mob, 20, 0.1f, 2);
					mode = 1;
				}
			}
			mover.move(null, delta);
		}

		@Override
		public void draw (Batch batch) throws Exception
		{
			batch.setColor(0, 1, 1, 1);
			super.draw(batch);
		}
	}
}
