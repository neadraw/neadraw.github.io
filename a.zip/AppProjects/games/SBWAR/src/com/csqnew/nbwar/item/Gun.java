package com.csqnew.nbwar.item;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import java.util.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.audio.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;

public class Gun extends Item {

	public Gun() {
		duration = 0.16f;
	}

	@Override
	public boolean call (Gaming game) throws Exception {
		Human user = this.user;
		Bullet entity = new Bullet();
		entity.user = user;
		game.addEntity("bullet", entity);
		Mover mover = entity.mover;
		mover.set(user.angle, 32);
		Main.play(Sounds.gun_call);
		return true;
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		Human user = this.user;
		float r = (user.width + user.height) / 4f;
		batch.draw(Textures.gun, user.getX() - r / 2, user.getY() + r, + r / 2, - r, 1.6f, 1.6f, 1, 1, - user.angle + 45, 0, 0, 16, 16, false, false);
	}

	public static class Bullet extends MoveableEntity {

		public Human user;
		public float runTime;

		public Bullet () {
		}

		@Override
		public void create () throws Exception {
			super.create();
			width = height = 0.1f;
			setX(user.getX());
			setY(user.getY());
		}

		@Override
		public void draw (Batch batch) throws Exception {
			super.draw(batch);
			batch.draw(Textures.gun, x - 0.2f, y - 0.2f, 0, 0, width + 0.4f, height + 0.4f, 1, 1, 0, 16, 0, 4, 4, false, false);
		}

		@Override
		public void act (Gaming game, float delta) throws Exception {
			if (runTime >= 8) {
				mode = 1;
				return;
			}
			runTime += delta;
			Object[] mobs = game.mobs.list;
			Human user = this.user;
			float lastX = x, lastY = y;
			for (int i = 0; i < mobs.length; i ++) {
				Mob mob = (Mob) mobs[i];
				if (mob == user) continue;
				if (overlaps(mob)) {
					float value = 8;
					if (user instanceof Player) {
						value = 48;
						/*for (int j = 0; j < 4; j ++) {
							Trinitrotoluene tnt = new Trinitrotoluene();
							tnt.width = tnt.height = 0.6f;
							tnt.setX(mob.getX());
							tnt.setY(mob.getY());
							TimerMover tntMover = new TimerMover(tnt);
							tntMover.maxTime = 0.3f;
							tntMover.set((float) (Math.random() * 360), 10f);
							tnt.mover.add(tntMover);
							game.addEntity("tnt", tnt);
							tnt.runTime = 2.5f;
						}*/
					}
					mover.move(null, - 1);
					user.attack(game, this, mob, value);
					x = lastX;
					y = lastY;
					mode = 1;
					dead(game);
					return;
				}
			}
			super.act(game, delta);
		}

		@Override
		public void onCollisionBlock (Entity block, boolean is) throws Exception {
			super.onCollisionBlock(block, is);
			if (is)
			{
				mover.xSpeed = -mover.xSpeed;
			}
			else
			{
				mover.ySpeed = -mover.ySpeed;
			}
		}

		@Override
		public void dead(Gaming game) throws Exception {
			super.dead(game);
			AnimationEntity anim = new AnimationEntity() {

				@Override
				public Texture texture()
				{
					return Textures.gun;
				}
			};
			anim.set(0.25f, 16, 8, 8, 8, 6, false, false);
			anim.width = 1.6f;
			anim.height = 1.6f;
			anim.setX(getX());
			anim.setY(getY());
			game.addEntity("anim", anim);
		}
	}
}
