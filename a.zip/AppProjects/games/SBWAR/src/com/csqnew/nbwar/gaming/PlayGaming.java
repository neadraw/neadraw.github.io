package com.csqnew.nbwar.gaming;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.util.*;
import java.io.*;

public class PlayGaming extends Gaming {

	public int index;

	public void setGaming (PlayGaming gaming, boolean con, boolean dispose) {
		if (con) gaming.index = index + 1;
		gaming.player = player;
		Main.setGaming(gaming);
		try
		{
			Utils.saveGameData(gaming);
		}
		catch (IOException e)
		{}
	}

	public void setGaming (PlayGaming gaming, boolean con) {
		setGaming(gaming, con, false);
	}

	public void setGaming (PlayGaming gaming) {
		setGaming(gaming, true);
	}
}
