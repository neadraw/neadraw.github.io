package com.csqnew.nbwar.entity;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.graphics.*;

public abstract class AnimationEntity extends Entity {

	public float duration, runTime;
	public int regionWidth, regionHeight, startX, startY, count;
	public boolean isLopping, isVertical;

	public AnimationEntity () {
	}

	@Override
	public void act(Gaming game, float delta) throws Exception {
		super.act(game, delta);
		if (runTime >= duration) {
			if (isLopping) {
				runTime -= duration;
				return;
			} else {
				mode = 1;
			}
		}
		runTime += delta;
	}

	public void set(float duration, int startX, int startY, int regionWidth, int regionHeight, int count, boolean isVertical, boolean isLoopping) {
		this.duration = duration;
		this.regionWidth = regionWidth;
		this.regionHeight = regionHeight;
		this.isLopping = isLoopping;
		this.isVertical = isVertical;
		this.count = count;
		this.startX = startX;
		this.startY = startY;
	}

	@Override
	public void draw(Batch batch) throws Exception {
		super.draw(batch);
		int regionX = 0, regionY = 0;
		if (isVertical) {
			regionY = (int) (Math.min(1, runTime / duration) * count) * regionHeight;
		} else {
			regionX = (int) (Math.min(1, runTime / duration) * count) * regionWidth;
		}
		batch.draw(texture(), x, y, 0, 0, width, height, 1, 1, 0, startX + regionX, startY + regionY, regionWidth, regionHeight, false, false);
	}

	public abstract Texture texture();
}
