package com.csqnew.nbwar.item;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.mob.*;

public class Balls extends Item {

	public Balls () {
		duration = 0.2f;
	}

	@Override
	public boolean call (Gaming game) throws Exception {
		Ball ball = new Ball();
		ball.init(this);
		game.addEntity("ball", ball);
		return true;
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		Human user = this.user;
		float r = (user.width + user.height + 1) / 4;
		double degrees = user.angle / 180 * Math.PI;
		batch.draw(Textures.ball, user.getX() + (float) Math.sin(degrees) * r - 0.5f, user.getY() + (float) Math.cos(degrees) * r - 0.5f, 1, 1);
	}

	public static class Ball extends MoveableEntity {

		public Human user;
		public Mob lastMob;
		public float runTime;

		public Ball () {
			width = 0.7f;
			height = 0.7f;
		}

		public void init (Balls balls) {
			Human user = balls.user;
			mover.set(user.angle, 12);
			setX(user.getX());
			setY(user.getY());
			lastMob = user;
			this.user = user;
		}

		@Override
		public void act (Gaming game, float delta) throws Exception {
			super.act(game, delta);
			runTime += delta;
			if (runTime >= 16) {
				mode = 1;
				return;
			}
			Human user = this.user;
			Object[] mobs = game.mobs.list;
			Mob lastMob = this.lastMob;
			for (int i = 0; i < mobs.length; i ++) {
				Mob mob = (Mob) mobs[i];
				if (overlaps(mob)) {
					if (lastMob == mob) continue;
					user.attack(game, this, mob, 6);
					this.lastMob = mob;
				} else {
					if (mob == lastMob) {
						this.lastMob = null;
					}
				}
			}
			if (user instanceof Player)
			{
				mover.set(user.angle, user.speed);
				if (!(user.item instanceof Balls))
				{
					runTime = 0;
				}
			}
		}

		@Override
		public void draw (Batch batch) throws Exception {
			super.draw(batch);
			float x = this.x, y = this.y, width = this.width, height = this.height;
			Texture texture = Textures.ball;
			batch.draw(texture, x - 0.05f, y - 0.05f, width + 0.1f, height + 0.1f, 6, 1, 1, 1, false, false);
			batch.draw(texture, x, y, width, height);
		}

		@Override
		public void onCollisionBlock (Entity block, boolean isVertical) throws Exception {
			super.onCollisionBlock(block, isVertical);
			if (user instanceof Player) return;
			Mover mover = this.mover;
			if (isVertical) {
				mover.xSpeed = - mover.xSpeed;
			} else {
				mover.ySpeed = - mover.ySpeed;
			}
		}
	}
}
