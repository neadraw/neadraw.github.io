package com.csqnew.nbwar.entity;
import com.csqnew.nbwar.util.Utils;
import com.csqnew.nbwar.gaming.Gaming;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.csqnew.nbwar.entity.mob.Human;
import com.csqnew.nbwar.entity.mob.Mob;
import com.csqnew.nbwar.Main;
import com.badlogic.gdx.graphics.Texture;
import com.csqnew.nbwar.*;

public class Laser extends Entity
{

	public Mob user;
	public float runTime, runUnitTime;

	public Laser () {
	}

	@Override
	public boolean overlaps (Entity e)
	{
		float x = this.x, y = this.y, width = this.width, height = this.height;
		float ex = e.x, ey = e.y, ewidth = e.width, eheight = e.height;
		return Utils.isLineIntersectRectangle(x, y, x + width, y + height, ex, ey, ex + ewidth, ey + eheight);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		if (runTime > 2.5f)
		{
			mode = 1;
			return;
		}
		runTime += delta;
		if (runTime >= 0.2f)
		{
			if (runUnitTime > 0.02f)
			{
				Mob user = this.user;
				if (user == null)
				{
					user = Mob.MOB;
					user.mode = 1;
				}
				Object[] mobs = game.mobs.list;
				int length = mobs.length;
				for (int i = 0; i < length; i ++)
				{
					Mob mob = (Mob) mobs[i];
					if (mob == user) continue;
					if (overlaps(mob))
					{
						user.attack(game, this, mob, 5, 0, 0);
					}
				}
				runUnitTime = 0;
			}
			runUnitTime += delta;
		}
		super.act(game, delta);
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		float width = this.width, height = this.height;
		float len = (float) Math.sqrt(width * width + height * height);
		float angle = (float) - (Math.atan2(width, height) * 180 / Math.PI);
		batch.setColor(1, 1, 1, Math.min(1, runTime));
		batch.draw(Textures.laser_gun, x - 0.1f, y - 0.1f, 0.1f, 0.1f, len + 0.15f, 0.2f, 1, 1, angle + 90, 0, 0, 1, 8, false, false);
	}
}
