package com.csqnew.nbwar.entity.mob;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.gaming.*;

public class Bird extends NewbeHuman implements Moster
{

	public Bird ()
	{
		width = height = 1.6f;
		speed = 8;
	}

	@Override
	public void draw(Batch batch) throws Exception
	{
		super.draw(batch);
		batch.draw(Textures.alan, x, y, width, height);
	}

	@Override
	public void setFocus(Mob mob)
	{
		focusMob = mob;
	}

	@Override
	public void onHurt(Gaming game, Mob by, float value) throws Exception
	{
		super.onHurt(game, by, value);
		if (by != focusMob)
		{
			health += value;
		}
	}

	@Override
	public Mob getFocus()
	{
		return focusMob;
	}
}
