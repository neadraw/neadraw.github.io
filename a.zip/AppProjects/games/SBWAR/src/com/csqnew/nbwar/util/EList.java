package com.csqnew.nbwar.util;
import java.util.*;
import java.io.*;

public class EList <E> implements Serializable {

	public Object[] list;

	public EList(Object[] list) {
		this.list = list;
	}

	public EList(int size) {
		this(new Object[size]);
	}

	public EList() {
		this(0);
	}

	public E get(int index) {
		return (E) list[index];
	}

	public void add(E e) {
		Object[] list = this.list;
		int length = list.length;
		Object[] newList = new Object[length + 1];
		System.arraycopy(list, 0, newList, 0, length);
		newList[length] = e;
		this.list = newList;
	}

	public void remove(int index) {
		Object[] list = this.list;
		int length = list.length;
		int newLength = length - 1;
		Object[] newList = new Object[newLength];
		System.arraycopy(list, 0, newList, 0, index);
		System.arraycopy(list, index + 1, newList, index, newLength - index);
		this.list = newList;
	}

	public void removeFirst() {
		Object[] list = this.list;
		int length = list.length;
		int newLength = length - 1;
		Object[] newList = new Object[newLength];
		System.arraycopy(list, 1, newList, 0, newLength);
		this.list = newList;
	}

	public int size() {
		return list.length;
	}
}
