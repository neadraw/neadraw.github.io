package com.csqnew.nbwar.item;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.mob.*;
import com.badlogic.gdx.utils.*;
import java.util.*;

public class Newber extends Item {

	public TextureEntity entity;

	public Newber () {
		duration = 2f;
		entity = new TextureEntity() {

			@Override
			public TextureRegion texture()
			{
				return texture(Textures.newber, 0, 0, 8, 8);
			}
		};
		entity.width = 1;
		entity.height = 1;
	}

	@Override
	public boolean call (Gaming game) throws Exception {
		Mover mover = new Mover(entity);
		mover.set(user.angle, (user.width + user.height) / 4 + 1.2f);
		entity.setX(user.getX());
		entity.setY(user.getY());
		mover.move(null, 1);
		Object[] mobs = game.mobs.list;
		Random random = Main.RANDOM;
		for (int i = 0; i < mobs.length; i ++) {
			Mob mob = (Mob) mobs[i];
			if (mob == user) continue;
			if (mob.overlaps(entity)) {
				Item item = new Bow();
				int count = 5;
				for (int j = 0; j < count; j ++) {
					MobHelper zombie = new MobHelper();
					zombie.mob = user;
					game.addEntity("mob", zombie);
					zombie.width = zombie.height = 0.6f;
					TimerMover mover2 = new TimerMover(zombie);
					mover2.set(random.nextInt(360), 20);
					mover2.maxTime = 0.4f;
					zombie.mover.add(mover2);
					zombie.mobFocus = mob;
					zombie.setX(mob.getX());
					zombie.setY(mob.getY());
					zombie.item = item;
					zombie.health = 128;
					zombie.speed = 0.2f;
				}
				return true;
			}
		}
		return false;
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		Mover mover = new Mover(entity);
		mover.set(user.angle, (user.width + user.height) / 4 + 1.2f);
		entity.setX(user.getX());
		entity.setY(user.getY());
		mover.move(null, 1);
		entity.draw(batch);
	}

	@Override
	public void drawBox(Batch batch) throws Exception {
		super.drawBox(batch);
		Mover mover = new Mover(entity);
		mover.set(user.angle, (user.width + user.height) / 4 + 1.2f);
		entity.setX(user.getX());
		entity.setY(user.getY());
		mover.move(null, 1);
		entity.drawBox(batch);
	}
}
