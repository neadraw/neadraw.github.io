package com.csqnew.nbwar.util;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.gaming.*;
import java.util.*;
import com.badlogic.gdx.utils.*;
import java.io.*;

public class Mover implements Serializable {

	public Entity entity;
	public Mover last, next;
	public float xSpeed, ySpeed;

	public Mover (Entity entity) {
		this.entity = entity;
	}

	public void move (Gaming game, float delta) throws Exception {
		Entity entity = this.entity;
		float deltaXSpeed = delta * getXSpeed(), deltaYSpeed = delta * getYSpeed();
		if (game == null) {
			entity.x += deltaXSpeed;
			entity.y += deltaYSpeed;
		} else {
			float rawX = entity.x, rawY = entity.y;
			Object[] blocks = game.blocks.list;
			int length = blocks.length;
			entity.x += deltaXSpeed;
			Entity collisionXBlock = null, collisionYBlock = null;
			float distance = 0.0002f;
			float blockSize = 128f;
			for (int i = 0; i < length; i ++) {
				Entity block = (Entity) blocks[i];
				if (block == null) continue;
				float rawBlockPosition = block.x, rawBlockSize = block.width;
				block.width = blockSize;
				if (rawX > rawBlockPosition) {
					block.x -= block.width - rawBlockSize;
				}
				if (entity.overlaps(block)) {
					if (deltaXSpeed > 0) {
						entity.x = rawBlockPosition - entity.width - distance;
					} else {
						entity.x = rawBlockPosition + rawBlockSize + distance;
					}
					collisionXBlock = block;
				}
				block.x = rawBlockPosition;
				block.width = rawBlockSize;
			}
			entity.y += deltaYSpeed;
			for (int i = 0; i < length; i ++) {
				Entity block = (Entity) blocks[i];
				if (block == null) continue;
				float rawBlockPosition = block.x, rawBlockSize = block.width;
				rawBlockPosition = block.y;
				rawBlockSize = block.height;
				block.height = blockSize;
				if (rawY > rawBlockPosition) {
					block.y -= block.height - rawBlockSize;
				}
				if (entity.overlaps(block)) {
					if (deltaYSpeed > 0) {
						entity.y = rawBlockPosition - entity.height - distance;
					} else {
						entity.y = rawBlockPosition + rawBlockSize + distance;
					}
					collisionYBlock = block;
				}
				block.y = rawBlockPosition;
				block.height = rawBlockSize;
			}
			if (collisionXBlock != null) {
				entity.onCollisionBlock(collisionXBlock, true);
			}
			if (collisionYBlock != null) {
				entity.onCollisionBlock(collisionYBlock, false);
			}
		}
		act(game, delta);
		Mover next = this;
		while ((next = next.next) != null) {
			next.act(game, delta);
		}
	}

	public void set (float angle, float speed) {
		angle = angle % 360f;
		float buff = (float) (angle * Math.PI / 180.0);
		xSpeed = (float) Math.sin(buff) * speed;
		ySpeed = (float) Math.cos(buff) * speed;
	}

	public float set (float x, float y, float speed) {
		float angle = (float) (Math.atan2(x, y) * 180 / Math.PI);
		set(angle, speed);
		return angle;
	}

	public void stop () {
		xSpeed = 0;
		ySpeed = 0;
	}

	public void act (Gaming game, float delta) {}

	public void del() {
		if (next != null) {
			next.last = last;
		}
		if (last != null) {
			last.next = next;
		}
	}

	public void add(Mover mover) {
		if (next != null) {
			next.last = mover;
		}
		mover.last = this;
		mover.next = next;
		next = mover;
	}

	public float getXSpeed() {
		float speed = 0;
		Mover mover = this;
		do {
			speed += mover.xSpeed;
		} while ((mover = mover.next) != null);
		return speed;
	}

	public float getYSpeed() {
		float speed = 0;
		Mover mover = this;
		do {
			speed += mover.ySpeed;
		} while ((mover = mover.next) != null);
		return speed;
	}
}
