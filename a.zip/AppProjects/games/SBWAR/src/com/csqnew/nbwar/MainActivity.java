package com.csqnew.nbwar;
import com.badlogic.gdx.backends.android.*;
import android.os.*;
import android.widget.*;
import android.content.pm.*;
import android.app.*;

public class MainActivity extends AndroidApplication {

	public static MainActivity SELF;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		SELF = this;
		new AlertDialog.Builder(this).setTitle("来自C.T. Dog's警告").setMessage("本游戏为测试版，第3大关未完善(每大关分为五小关)，如果有钱可以赞助作者。\n官方网站：https://neadraw.github.io/sbwar").setPositiveButton("关闭", null).show();
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
		initialize(new Main(), config);
	}
}
