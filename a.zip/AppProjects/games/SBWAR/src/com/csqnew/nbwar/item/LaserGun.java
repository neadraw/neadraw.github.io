package com.csqnew.nbwar.item;
import com.badlogic.gdx.graphics.Texture;
import com.csqnew.nbwar.Main;
import com.csqnew.nbwar.gaming.Gaming;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.csqnew.nbwar.entity.Laser;
import com.csqnew.nbwar.entity.mob.Human;
import com.csqnew.nbwar.*;

public class LaserGun extends Item
{

	public LaserGun ()
	{
		duration = 0.6f;
	}

	@Override
	public boolean call (Gaming game) throws Exception
	{
		Human user = this.user;
		Laser laser = new Laser();
		laser.user = user;
		laser.x = user.getX();
		laser.y = user.getY();
		double degrees = user.angle / 180 * Math.PI, len = 256;
		laser.width = (float) (Math.sin(degrees) * len);
		laser.height = (float) (Math.cos(degrees) * len);
		game.addEntity("laser", laser);
		return super.call(game);
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		Human user = this.user;
		float x = user.getX(), y = user.getY(), r = (user.width + user.height) / 4f;
		batch.draw(Textures.laser_gun, x + r, y - 0.5f, - r, 0.5f, 2, 1, 1, 1,90 - user.angle, 0, 8, 16, 8, false, false);
	}
}
