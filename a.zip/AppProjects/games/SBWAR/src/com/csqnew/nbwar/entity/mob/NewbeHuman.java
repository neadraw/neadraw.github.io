package com.csqnew.nbwar.entity.mob;

import com.csqnew.nbwar.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.item.*;
import com.csqnew.nbwar.util.*;
import java.util.*;
import com.csqnew.nbwar.entity.boss.*;

public class NewbeHuman extends Human {

	public Mob focusMob;
	public MoveAI ai;

	public NewbeHuman() {
		ai = new MoveAI(this);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception {
		super.act(game, delta);
		Random random = Main.RANDOM;
		if (focusMob != null) {
			if (focusMob.mode == 1) {
				focusMob = null;
			} else {
				float xx = focusMob.getX() - getX(), yy = focusMob.getY() - getY();
				ai.go(game, xx, yy, delta);
				angle = ai.angle;
				mover.set(angle, speed);
				float minDistance = 256;
				boolean isStop = true, focusUseItem = false;
				if (item instanceof Knife) {
					minDistance = 0.6f;
				} else if (item instanceof Gun || item instanceof Bow) {
					minDistance = 5;
					if (this instanceof MobHelper) {
						minDistance = 12;
					}
				} else if (item instanceof Newber) {
					minDistance = 1.4f;
				} else if (item instanceof TNTSummoner) {
					minDistance = 3;
				} else if (item instanceof Chainsaw) {
					Chainsaw item = (Chainsaw) this.item;
					minDistance = item.size * (this.width + this.height) / 2f + 1;
					isStop = false;
				} else if (item instanceof NBZombie.ZombieSummoner) {
					minDistance = 4;
					focusUseItem = true;
					isStop = false;
				} else if (item instanceof KunKun.KunBar) {
					minDistance = 8;
				} else if (item instanceof Balls) {
					minDistance = 6;
				} else if (item instanceof Throder) {
					minDistance = 20;
					isStop = false;
				} else if (item instanceof LaserGun) {
					minDistance = 32;
				} else if (item instanceof TNTBreaker) {
					minDistance = 10;
				}
				float distance = distance(focusMob);
				isUseItem = distance < minDistance;
				if (focusUseItem) {
					isUseItem = true;
				}
				if (distance < minDistance) {
					if (isStop) mover.stop();
					if (focusUseItem) mover.stop();
				}
				if (item instanceof Pickaxe) {
					Pickaxe pickaxe = (Pickaxe) item;
					if (pickaxe.focus != null) {
						mover.stop();
					}
					isUseItem = true;
				}
			}
		} else {
			isUseItem = false;
			if (random.nextInt(Math.round(16 / delta) + 1) == 0) {
				angle = random.nextInt(360);
				mover.set(angle, speed);
			}
		}
	}
}
