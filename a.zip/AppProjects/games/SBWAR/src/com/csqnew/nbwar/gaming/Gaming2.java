package com.csqnew.nbwar.gaming;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import java.util.*;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.boss.*;
import com.csqnew.nbwar.item.*;
import com.csqnew.nbwar.entity.mob.*;

public class Gaming2 extends PlayGaming
{

	byte[] mapData;
	int mapX, mapY, mapSize = 16;
	Alan alan;

	@Override
	public void create () throws Exception
	{
		super.create();
		
		Random random = Main.RANDOM;
		mapData = new byte[12];
		EList<Entity> blocks = new EList<>();
		LaserGun laserGun = new LaserGun();
		Gun gun = new Gun();
		Throder th = new Throder();
		TNTBreaker tnt = new TNTBreaker();
		byte lastData = 0;
		if (index == 4)
		{
			mapSize = 64;
		}
		for (int i = 0; i < mapData.length; i ++)
		{
			byte data = (byte) random.nextInt(3);
			switch (data)
			{
				case 1:
					if (lastData == 2)
					{
						data = random.nextBoolean() ? (byte) 0 : 2;
					}
					break;
				case 2:
					if (lastData == 1)
					{
						data = random.nextBoolean() ? (byte) 0 : 1;
					}
			}
			mapData[i] = data;
			Entity block = new Wall();
			blocks.add(block);
			block.x = mapX;
			block.y = mapY - 1;
			block.width = mapSize;
			block.height = 1;
			block = new Wall();
			blocks.add(block);
			block.x = mapX;
			block.y = mapY + mapSize;
			block.width = mapSize;
			block.height = 1;
			block = new Wall();
			blocks.add(block);
			block.x = mapX - 1;
			block.y = mapY;
			block.width = 1;
			block.height = mapSize;
			block = new Wall();
			blocks.add(block);
			block.x = mapX + mapSize;
			block.y = mapY;
			block.width = 1;
			block.height = mapSize;
			block = new TextureEntity() {

				@Override
				public TextureRegion texture()
				{
					return texture(Main.TEXTURE_BLACK, 0, 0, 1, 1);
				}
			};
			addEntity("block", block);
			if (random.nextBoolean())
			{
				block.width = mapSize - 4;
				block.height = 1;
			}
			else
			{
				block.height = mapSize - 4;
				block.width = 1;
			}
			block.setX(mapX + mapSize / 2);
			block.setY(mapY + mapSize / 2);
			loadMap(data);
			lastData = data;
		}
		mapX = 0;
		mapY = 0;
		Entity entity = new Entity();
		entity.width = mapSize;
		entity.height = mapSize;
		for (int i = 0; i < mapData.length; i ++)
		{
			byte data = mapData[i];
			entity.x = mapX;
			entity.y = mapY;
			for (int j = 0; j < blocks.size(); j ++)
			{
				Entity block = blocks.get(j);
				if (block.overlaps(entity))
				{
					blocks.remove(j);
					j --;
				}
			}
			NBCow cow = new NBCow();
			cow.health = 420 * (index / 5 + 1);
			cow.item = gun;
			if (index >= 3 && random.nextInt(5) == 1) cow.item = th;
			if (index >= 2 && random.nextInt(5) == 1) cow.item = tnt;
			if (index >= 1 && random.nextInt(5) == 1) cow.item = laserGun;
			cow.focusMob = player;
			cow.x = mapX + 2;
			cow.y = mapY + 2;
			addEntity("mob", cow);
			if (i == mapData.length - 1)
			{
				for (int j = 0; j < index; j ++)
				{
					ThreeHeader header = new ThreeHeader();
					header.x = mapX + 4;
					header.y = mapY + 4;
					header.focus = player;
					addEntity("mob", header);
				}
			}
			loadMap(data);
		}
		for (int i = 0; i < blocks.size(); i ++)
		{
			Entity block = blocks.get(i);
			addEntity("block", block);
		}
		if (index == 0)
		{
			player.addItem(new Newber());
		}
		if (index == 1)
		{
			player.addItem(new Throder());
		}
		if (index == 2)
		{
			player.addItem(new LaserGun());
		}
		if (index == 3)
		{
			player.findItemByClass(Bow.class).duration = 0.03f;
		}
		if (index == 4)
		{
			alan = new Alan();
			alan.focus = player;
			alan.x = 5;
			alan.y = 5;
			addEntity("mob", alan);
			player.addItem(new THMKSummoner());
		}
		player.x = player.y = 5;
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		Object[] mobs = this.mobs.list;
		int mostersCount = 0;
		Player player = this.player;
		for (int i = 0; i < mobs.length; i ++)
		{
			Mob mob = (Mob) mobs[i];
			if (mob instanceof Moster)
			{
				mostersCount ++;
				Moster moster = (Moster) mob;
				moster.setFocus(player);
			}
		}
		if (mostersCount == 0)
		{
			if (index == 4)
			{
				setGaming(new Gaming3(), false);
			}
			else
			{
				setGaming(new Gaming2());
			}
		}
		Main.TITLE = "2-" + (index + 1) + "    " + mostersCount + " left";
		super.act(game, delta);
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		byte[] mapData = this.mapData;
		mapX = 0;
		mapY = 0;
		Texture floorTexture = Textures.stone;
		batch.setColor(Color.WHITE);
		for (int i = 0; i < mapData.length; i ++)
		{
			byte data = mapData[i];
			batch.draw(floorTexture, mapX, mapY, mapSize, mapSize);
			loadMap(data);
		}
		super.draw(batch);
	}

	void loadMap (byte data)
	{
		switch (data)
		{
			case 0:
				mapX += mapSize;
				break;
			case 1:
				mapY += mapSize;
				break;
			case 2:
				mapY -= mapSize;
		}
	}
}
