package com.csqnew.nbwar.entity;
import com.csqnew.nbwar.entity.mob.*;
import java.util.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.graphics.*;

public class BloodEntity extends Entity {

	public float red, xSpeed, ySpeed;

	public BloodEntity() {
	}

	public Mob by;
	public float runTime;

	public void init(Mob from) {
		Random random = Main.RANDOM;
		width = (float) (random.nextInt(8) + 1) / 8f * from.width;
		height = (float) (random.nextInt(8) + 1) / 8f * from.height;
		setX(from.getX());
		setY(from.getY());
		float speed = (float) random.nextInt(1700) / 100f + 1f;
		double degrees = Math.atan2(by.getX() - from.getX(), by.getY() - from.getY()) + Math.random() * 1 - 0.5;
		xSpeed = (float) Math.sin(degrees) * speed;
		ySpeed = (float) Math.cos(degrees) * speed;
		runTime = (float) random.nextInt(17) / 8f + 2;
		red = (float) (random.nextInt(256) + 256) / 512f;
	}

	@Override
	public void act(Gaming game, float delta) throws Exception {
		super.act(game, delta);
		x += xSpeed * delta;
		y += ySpeed * delta;
		if (runTime >= 12) {
			mode = 1;
			return;
		}
		runTime += delta;
		if (by == null) return;
		if (by.mode == 1) {
			by = null;
			return;
		}
		if (runTime >= 8) {
			xSpeed = 0;
			ySpeed = 0;
			return;
		}
		if (overlaps(by)) {
			float health = 1;
			by.health += health;
			mode = 1;
		}
	}

	@Override
	public void draw(Batch batch) throws Exception {
		float width = this.width, height = this.height;
		float r = red, g = 0, b = 0;
		batch.setColor(r, g, b, 1 - runTime / 12f);
		batch.draw(Main.TEXTURE_WHITE, x, y, width / 2f, height / 2f, width, height, 1, 1, Math.min(runTime, 8f) * 180 * (hashCode() % 4 + 1), 0, 0, 1, 1, false, false);
	}
}
