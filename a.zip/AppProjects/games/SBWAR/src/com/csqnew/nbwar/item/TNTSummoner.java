 package com.csqnew.nbwar.item;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.mob.*;

public class TNTSummoner extends Item {

	public TNTSummoner () {
		duration = 0.8f;
	}

	@Override
	public boolean call(Gaming game) throws Exception {
		Trinitrotoluene tnt = new Trinitrotoluene();
		tnt.width = 0.75f;
		tnt.height = 0.75f;
		if (user instanceof Player)
		{
			tnt.width = 48;
			tnt.height = 48;
		}
		tnt.setX(user.getX());
		tnt.setY(user.getY());
		tnt.runTime = 2;
		Mover mover = tnt.mover;
		mover.set(user.angle, (user.width + user.height) / 4 + 0.5f);
		mover.move(game, 1);
		mover.set(0, 0);
		tnt.by = user;
		game.addEntity("tnt", tnt);
		return true;
	}

	@Override
	public void draw(Batch batch) throws Exception {
		super.draw(batch);
		Human user = this.user;
		batch.draw(Textures.tnt, user.x - user.width / 2f, user.y - user.height / 2f, user.width * 2f, user.height * 2f, 16, 8, 16, 16, false, false);
	}
}
