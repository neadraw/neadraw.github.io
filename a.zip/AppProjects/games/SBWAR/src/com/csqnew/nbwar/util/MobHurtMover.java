package com.csqnew.nbwar.util;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.gaming.*;

public class MobHurtMover extends TimerMover {

	public MobHurtMover (Entity entity) {
		super(entity);
	}

	@Override
	public void act (Gaming game, float delta) {
		super.act(game, delta);
		Mover last = this.last;
		if (last != null) {
			if (last instanceof MobHurtMover) {
				last = last.last;
				if (last != null) {
					if (last instanceof MobHurtMover) {
						last = last.last;
						if (last != null) {
							if (last instanceof MobHurtMover) {
								last = last.last;
								if (last != null) {
									if (last instanceof MobHurtMover) {
										del();
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
