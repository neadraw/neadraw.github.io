package com.csqnew.nbwar.item;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.entity.mob.*;
import com.badlogic.gdx.audio.*;

public class Chainsaw extends Item {

	public int size = 4;

	public Chainsaw() {
		duration = 0.04f;
	}

	@Override
	public boolean call(Gaming game) throws Exception {
		Entity entity = new Entity();
		entity.width = user.width;
		entity.height = user.height;
		entity.setX(user.getX());
		entity.setY(user.getY());
		float r = (user.width + user.height + entity.width + entity.height) / 4;
		Mover mover = new Mover(entity);
		mover.set(user.angle, r);
		mover.move(null, 1);
		mover.set(user.angle, (entity.width + entity.height) / 2f);
		Object[] mobs = game.mobs.list;
		float hp = 4;
		if (user instanceof Player)
		{
			hp = 5;
		}
		for (int i = 1; i < size; i ++) {
			mover.move(null, 1);
			for (int j = 0; j < mobs.length; j ++) {
				Mob mob = (Mob) mobs[j];
				if (mob == user) continue;
				if (entity.overlaps(mob)) {
					user.attack(game, user, mob, hp, 0.1f, 2);
				}
			}
		}
		Main.play(Sounds.chainsaw);
		return super.call(game);
	}

	@Override
	public void draw(Batch batch) throws Exception {
		super.draw(batch);
		Entity entity = new Entity();
		entity.width = user.width;
		entity.height = user.height;
		entity.setX(user.getX());
		entity.setY(user.getY());
		float r = (user.width + user.height + entity.width + entity.height) / 4;
		Mover mover = new Mover(entity);
		mover.set(user.angle, r);
		mover.move(null, 1);
		mover.set(user.angle, (entity.width + entity.height) / 2f);
		batch.draw(Textures.chainsaw, entity.x, entity.y, 0, 0, entity.width, entity.height, 1, 1, 0, 0, 8, 8, 8, false, false);
		for (int i = 1; i < size; i ++) {
			mover.move(null, 1);
			batch.draw(Textures.chainsaw, entity.x, entity.y, entity.width / 2, entity.height / 2, entity.height, entity.height, 1, 1, - user.angle + user.itemUsedTime / duration * 360, 0, 0, 8, 8, false, false);
		}
	}

	@Override
	public void drawBox(Batch batch) throws Exception {
		super.drawBox(batch);
		Entity entity = new Entity();
		entity.width = user.width;
		entity.height = user.height;
		entity.setX(user.getX());
		entity.setY(user.getY());
		float r = (user.width + user.height + entity.width + entity.height) / 4;
		Mover mover = new Mover(entity);
		mover.set(user.angle, r);
		mover.move(null, 1);
		mover.set(user.angle, (entity.width + entity.height) / 2f);
		for (int i = 1; i < size; i ++) {
			mover.move(null, 1);
			entity.drawBox(batch);
		}
	}
}
