package com.csqnew.nbwar.util;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.gaming.*;
import org.json.*;
import java.io.*;

public class Nilo implements Cloneable, Serializable {

	public Nilo () {
	}

	public void create () throws Exception {
	}

	public void act (Gaming game, float delta) throws Exception {
	}

	public void draw (Batch batch) throws Exception {
	}

	public void dead (Gaming game) throws Exception {
	}

	public void dispose () throws Exception {
	}

	public <T>T clone () {
		try {
			return (T) super.clone();
		} catch (Exception e) {}
		return null;
	}

	public void save (JSONObject object) throws Exception {
		object.put("class", getClass().getName());
	}

}
