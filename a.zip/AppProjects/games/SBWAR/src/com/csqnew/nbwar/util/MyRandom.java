package com.csqnew.nbwar.util;
import java.io.*;

public class MyRandom implements Serializable {

	public long seed0, seed1;

	public long nextLong () {
		long s1 = this.seed0;
		final long s0 = this.seed1;
		this.seed0 = s0;
		s1 ^= s1 << s1 &~ s0;
		return (this.seed1 = (s1 ^ s0 ^ (s1 >>> 17) ^ (s0 >>> 26))) + s0;
	}

	public long nextLong (long bound) {
		return Math.abs(nextLong()) % bound;
	}

	public int nextInt () {
		return (int) nextLong();
	}

	public int nextInt (int bound) {
		return (int) nextLong(bound);
	}

	public float nextFloat () {
		return Math.abs(Float.intBitsToFloat(nextInt())) % 1f;
	}

	public void setState (final long seed0, final long seed1) {
		this.seed0 = seed0;
		this.seed1 = seed1;
	}
}
