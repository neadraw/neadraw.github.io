package com.csqnew.nbwar.item;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.entity.mob.*;
import java.util.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.utils.*;

public class Knife extends Item {

	public Entity entity;
	public Mover mover;

	public Knife() {
		duration = 0.4f;
		entity = new Entity();
		entity.width = 0.8f;
		entity.height = 0.8f;
		mover = new Mover(entity);
	}

	@Override
	public boolean call (Gaming game) throws Exception {
		super.call(game);
		boolean returnValue = false;
		Entity entity = this.entity;
		Human user = this.user;
		entity.setX(user.getX());
		entity.setY(user.getY());
		Mover mover = new Mover(entity);
		mover.set(user.angle, (user.width + user.height + entity.width + entity.height) / 4f);
		mover.move(null, 1);
		Object[] mobs = game.mobs.list;
		for (int i = 0; i < mobs.length; i ++) {
			Mob mob = (Mob) mobs[i];
			if (mob == user) continue;
			if (mob.overlaps(entity)) {
				user.attack(game, entity, mob, 8, 0.24f, 24f);
				returnValue = true;
			}
		}
		return returnValue;
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		Human user = this.user;
		Entity entity = this.entity;
		entity.setX(user.getX());
		entity.setY(user.getY());
		Mover mover = new Mover(entity);
		mover.set(user.angle, (user.width + user.height + entity.width + entity.height) / 4f);
		mover.move(null, 1);
		batch.draw(new TextureRegion(Textures.knife), entity.x, entity.y, entity.width / 2, entity.height / 2, entity.width, entity.height, 1, 1, (- user.angle + 45) + (user.itemUsedTime / duration) * 360);
	}

	@Override
	public void drawBox (Batch batch) throws Exception {
		super.drawBox(batch);
		Entity entity = this.entity;
		entity.setX(user.getX());
		entity.setY(user.getY());
		Mover mover = new Mover(entity);
		mover.set(user.angle, (user.width + user.height + entity.width + entity.height) / 4f);
		mover.move(null, 1);
		entity.drawBox(batch);
	}
}
