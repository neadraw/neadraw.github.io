package com.csqnew.nbwar.item;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.utils.*;
import java.util.*;
import com.badlogic.gdx.graphics.*;

public class Bow extends Item {

	public EList balls;

	public Bow () {
		duration = 0.4f;
	}

	@Override
	public boolean call (Gaming game) throws Exception {
		Human user = this.user;
		balls = game.getList("ball");
		int count = 3;
		boolean isPlayer = user instanceof Player;
		if (isPlayer) {
			count = 9;
		}
		if (duration <= 0.04f)
		{
			for (int i = 0; i < count; i ++) {
				TNTBreaker.TNTBullet entity = new TNTBreaker.TNTBullet();
				entity.user = user;
				game.addEntity("tnt", entity);
				Mover mover = entity.mover;
				mover.set(user.angle + (float) (Math.random() * 60 - 30), 12 + (float) (Math.random() * 10));
			}
			return true;
		}
		for (int i = 0; i < count; i ++) {
			Arrow arrow = false ? new Arrow2(user): new Arrow(user);
			arrow.bow = this;
			game.addEntity("arrow", arrow);
		}
		return true;
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		Human user = this.user;
		float r = (user.width + user.height) / 4f + 0.25f;
		float arg = (float) (user.angle * Math.PI / 180);
		Texture texture = Textures.bow;
		int regionX = Math.round(user.itemUsedTime / duration * 3) * 16;
		batch.draw(texture, user.getX() + (float) Math.sin(arg) * r - 0.5f, user.getY() + (float) Math.cos(arg) * r - 0.5f, 0.5f, 0.5f, 1, 1, 1, 1, - user.angle - 45, regionX, 0, 16, 16, false, false);
	}

	public static class Arrow extends MoveableEntity {

		Human user;
		Bow bow;
		float runTime, runTime2 = - 1;

		public Arrow (Human user) {
			this.user = user;
			Random random = Main.RANDOM;
			width = height = 0.4f;
			setX(user.getX());
			setY(user.getY());
			int angle = 45;
			if (user instanceof Player) {
				angle = 45;
			}
			mover.set(user.angle + random.nextInt(angle) - angle / 2, 16);
		}

		@Override
		public void act (Gaming game, float delta) throws Exception {
			super.act(game, delta);
			runTime += delta;
			if (runTime >= 8) {
				mode = 1;
				return;
			}
			float lastX = x, lastY = y;
			if (runTime2 == - 1) {
				Object[] mobs = game.mobs.list;
				for (int i = 0; i < mobs.length; i ++) {
					Mob mob = (Mob) mobs[i];
					if (mob == user) continue;
					if (overlaps(mob)) {
						mover.move(null, - 1);
						user.attack(game, this, mob, 8);
						x = lastX;
						y = lastY;
						runTime2 = 0;
						if (runTime > 1f) mode = 1;
					}
				}
				Object[] balls = bow.balls.list;
				for (int i = 0; i < balls.length; i ++) {
					Entity ball = (Entity) balls[i];
					if (overlaps(ball)) {
						ball.mode = 1;
						Trinitrotoluene tnt = new Trinitrotoluene();
						game.addEntity("tnt", tnt);
						tnt.width = 0.4f;
						tnt.height = 0.4f;
						tnt.setX(ball.getX());
						tnt.setY(ball.getY());
						tnt.by = user;
						tnt.runTime = 4;
						mover.xSpeed = - mover.xSpeed;
						mover.ySpeed = - mover.ySpeed;
						user = Human.human;
						runTime2 = 0;
					}
				}
				return;
			}
			runTime2 += delta;
			if (runTime2 >= 0.1f) {
				runTime2 = -1;
			}
		}

		@Override
		public void draw (Batch batch) throws Exception {
			super.draw(batch);
			Mover mover = this.mover;
			float xSpeed = mover.xSpeed, ySpeed = mover.ySpeed;
			float angle = (float) (Math.atan2(xSpeed, ySpeed) * 180 / Math.PI);
			batch.draw(Textures.bow, x - 0.8f, y - 0.8f, 1, 1, 2, 2, 1, 1, - angle + 45, 64, 0, 16, 16, false, false);
		}
	}

	public static class Arrow2 extends Arrow
	{
		public Mob focus;
		public Arrow2 (Human user)
		{
			super(user);
		}

		@Override
		public void act(Gaming game, float delta) throws Exception {
			super.act(game, delta);
			/*Human user = this.user;
			if (focus == null || focus == user || focus.mode == 1)
			{
				Object[] mobs = game.mobs.list;
				int len = mobs.length;
				if (len > 1)
				{
					Random random = Main.RANDOM;
					Mob focus = null;
					while (true)
					{
						focus = (Mob) mobs[random.nextInt(len)];
						if (focus != user) break;
					}
					this.focus = focus;
					float focusDistance = 1024;
					for (int i = 0; i < mobs.length; i ++) {
						Object object = mobs[i];
						if (object == this) continue;
						if (object instanceof NewbeHuman) {
							NewbeHuman moster = (NewbeHuman) object;
							if (moster.focusMob != user) continue;
							float xx = moster.getX() - getX(), yy = moster.getY() - getY();
							float distance = Math.abs(xx) + Math.abs(yy);
							if (distance < focusDistance) {
								focusDistance = distance;
								this.focus = moster;
							}
							continue;
						}
					}
				} else return;
			}
			float ta = (float) (Math.atan2(focus.getX() - getX(), focus.getY() - getY()) * 180 / Math.PI + 360);
			float na = (float) (Math.atan2(mover.xSpeed, mover.ySpeed) * 180 / Math.PI % 180 + 360);
			na += (ta - na) * delta * 4;
			mover.set(na, 16);
			mover.xSpeed = (focus.getX() - getX()) * 2;
			mover.ySpeed = (focus.getY() - getY()) * 2;*/
		}
	}
}
