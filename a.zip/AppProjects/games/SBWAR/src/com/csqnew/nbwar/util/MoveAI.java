package com.csqnew.nbwar.util;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.*;
import java.util.*;
import java.io.*;

public class MoveAI implements Serializable {

	public float angle;
	public MoveableEntity entity;
	public Mob mob;
	public float time = -1;

	public MoveAI(Mob mob) {
		this.mob = mob;
		entity = new MoveableEntity();
	}

	public void go(Gaming game, float x, float y, float delta) throws Exception {
		/*Random random = Main.RANDOM;
		entity.x = mob.x;
		entity.y = mob.y;
		entity.width = mob.width;
		entity.height = mob.height;
		float rawX = entity.x, rawY = entity.y;
		entity.mover.set(x, y, 1);
		entity.mover.move(game, 1);
		if (rawX == entity.x || rawY == entity.y) {
			if (random.nextInt((int) (16f / delta) + 1) == 0) {
				angle = random.nextInt(360);
				time = 0;
			}
		}
		if (rawX == entity.x && rawY == entity.y) {
			angle = random.nextInt(360);
			time = 0;
		} else if (time == -1) {
			angle = (float) (Math.atan2(x, y) * 180 / Math.PI);
		}
		if (time >= 0) {
			time += delta;
			if (time >= 2f) {
				time = - 1;
			}
		}*/
		angle = (float) (Math.atan2(x, y) * 180D / Math.PI);
	}
}
