package com.csqnew.nbwar.gaming;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import java.util.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.item.*;
import com.badlogic.gdx.audio.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.utils.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.boss.*;
import com.badlogic.gdx.*;

public class Gaming1 extends PlayGaming
{

	public final int LAST_INDEX = 4;
	public int width, height, summonedZombiesCount;
	public AnimationEntity nextGamingEntity;
	Knife knife;
	Gun gun;
	Bow bow;
	Newber newber;
	Chainsaw chainsaw;
	TNTSummoner tntSummoner;
	Balls balls;

	NBZombie boss;

	public Gaming1 ()
	{
	}

	@Override
	public void create () throws Exception
	{
		super.create();
		knife = new Knife();
		gun = new Gun();
		bow = new Bow();
		newber = new Newber();
		tntSummoner = new TNTSummoner();
		chainsaw = new Chainsaw();
		chainsaw.size = 3;
		balls = new Balls();
		Random random = Main.RANDOM_2;
		TextureEntity entity = null;
		if (index >= LAST_INDEX)
		{
			width = 0;
			height = 0;
			NBZombie boss = new NBZombie();
			addEntity("mob", boss);
			boss.x = boss.y = 20;
			this.boss = boss;
		}
		else
		{
			width = 40 + random.nextInt(21) * 2;
			height = 40 + random.nextInt(21) * 2;
			Wall wall = new Wall();
			addEntity("block", wall);
			wall.x = - 1;
			wall.y = 0;
			wall.width = 1;
			wall.height = height;
			wall = new Wall();
			addEntity("block", wall);
			wall.x = 0;
			wall.y = - 1;
			wall.width = width;
			wall.height = 1;
			wall = new Wall();
			addEntity("block", wall);
			wall.x = width;
			wall.y = 0;
			wall.width = 1;
			wall.height = height;
			wall = new Wall();
			addEntity("block", wall);
			wall.x = 0;
			wall.y = height;
			wall.width = width;
			wall.height = 1;
		}
		int size = index >= LAST_INDEX ? 0 :  random.nextInt(17) + 16;
		for (int x = 0; x < width; x += 2)
		{
			if (index >= LAST_INDEX)
			{
				break;
			}
			for (int y = 0; y < height; y += 2)
			{
				if (random.nextInt(64) > 0 || x == 0 || x == width - 1 || y == 0 || y == height - 1)
				{
					continue;
				}
				entity = new TextureEntity() {

					@Override
					public TextureRegion texture()
					{
						return texture(Textures.bedrock,0, 0, 8, 8);
					}
				};
				entity.x = x;
				entity.y = y;
				int blockWidth = 2, blockHeight = blockWidth;
				if (random.nextBoolean())
				{
					blockWidth += random.nextInt(16) * 2;
					blockHeight += random.nextInt(2) * 2;
				}
				else
				{
					blockWidth += random.nextInt(2) * 2;
					blockHeight += random.nextInt(16) * 2;
				}
				if (entity.x >= width - blockWidth) entity.x = width - blockWidth - 2;
				if (entity.y >= height - blockHeight) entity.y = height - blockHeight - 2;
				entity.width = blockWidth;
				entity.height = blockHeight;
				addEntity("block", entity);
			}
		}
		for (int i = 0; i < size; i ++)
		{
			Zombie zombie = newZombie();
			zombie.x = random.nextInt(width);
			zombie.y = random.nextInt(height);
		}
		nextGamingEntity = new AnimationEntity() {

			@Override
			public Texture texture()
			{
				return Textures.portal;
			}
		};
		nextGamingEntity.set(4, 0, 0, 16, 16, 32, true, true);
		nextGamingEntity.x = - 999999999;
		nextGamingEntity.y = height - 1;
		nextGamingEntity.width = nextGamingEntity.height = 1;
		addEntity("stage", nextGamingEntity);
		if (index == 0)
		{
			addPlayerItems(player);
			player.health = 500;
		}
		if (index == 1)
		{
			player.addItem(new Balls());
		}
		if (index == 2)
		{
			player.addItem(new KunKun.KunBar());
		}
		if (index == 3)
		{
			player.addItem(new TNTBreaker());
		}
	}

	public static void addPlayerItems (Player player)
	{
		Bow bow = new Bow();
		//bow.duration = 0.02f;
		player.addItem(bow);
		player.addItem(new Pickaxe());
		Chainsaw chainsaw2 = new Chainsaw();
		chainsaw2.size = 5;
		player.addItem(chainsaw2);
		Gun gun2 = new Gun();
		gun2.duration = 0.082f;
		player.addItem(gun2);
		/*KunKun.KunBar kunbar = new KunKun.KunBar();
		 kunbar.duration = 0.5f;
		 player.addItem(kunbar);*/
		//player.addItem(new Throder());
		/*LaserGun laser = new LaserGun();
		 laser.duration = 0.1f;
		 player.addItem(laser);*/
		player.checkItem();
	}

	float time1 = 0;

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		super.act(game, delta);
		Random random = Main.RANDOM;
		float width = this.width, height = this.height;
		time1 += delta;
		boolean canSummonZombie = false;
		if (time1 >= 2)
		{
			canSummonZombie = true;
			time1 = 0;
		}
		if (index == 0)
		{
			canSummonZombie = false;
		}
		if (index >= LAST_INDEX)
		{
			canSummonZombie = false;
			boss.focusMob = player;
			Object[] bloods = this.bloods.list;
			for (int i = 0; i < bloods.length; i ++)
			{
				BloodEntity blood = (BloodEntity) bloods[i];
				if (blood.by instanceof NBZombie)
				{
					blood.mode = 1;
				}
			}
		}
		if (nextGamingEntity.overlaps(player))
		{
			if (index >= LAST_INDEX)
			{
				Gaming2 newGame = new Gaming2();
				setGaming(newGame, false);
				newGame.index = 0;
				player.x = 0;
				player.y = 0;
			}
			else
			{
				Gaming1 newGame = new Gaming1();
				setGaming(newGame);
				player.x = 0;
				player.y = 0;
			}
		}
		boolean hasZombie = false;
		Object[] mobs = this.mobs.list;
		int mosterCount = 0;
		for (int i = 0; i < mobs.length; i ++)
		{
			Mob mob = (Mob) mobs[i];
			if (index < LAST_INDEX)
			{
				float mx = mob.getX(), my = mob.getY();
				if (mx <= 0)
				{
					mob.x = 0.1f;
				}
				if (my <= 0)
				{
					mob.y = 0.1f;
				}
				if (mx >= width)
				{
					mob.x = width - mob.width - 4f;
				}
				if (my >= height)
				{
					mob.y = height - mob.height - 4f;
				}
			}
			if (mob instanceof Moster)
			{
				mosterCount ++;
				hasZombie = true;
				Moster moster = (Moster) mob;
				moster.setFocus(player);
			}
		}
		for (int i = 0; i < 20 - mosterCount; i ++)
		{
			if (!canSummonZombie) break;
			if (summonedZombiesCount >= index * 25) break;
			summonedZombiesCount ++;
			Zombie zombie = newZombie();
			Mob mob = (Mob) mobs[random.nextInt(mobs.length)];
			zombie.setX(mob.getX());
			zombie.setY(mob.getY());
			TimerMover mover = new TimerMover(zombie);
			mover.set(random.nextInt(360), 16);
			mover.maxTime = 0.2f;
			zombie.mover.add(mover);
		}
		Main.TITLE = "1-" + (index + 1) + "    " + mosterCount + " left";
		if (hasZombie) return;
		if (index < LAST_INDEX)
		{
			nextGamingEntity.x = player.x;
			nextGamingEntity.y = player.y;
		}
		else if (boss.mode == 1 && nextGamingEntity.distance(player) > 8)
		{
			nextGamingEntity.x = player.x + (random.nextBoolean() ? 1 : - 1) * (random.nextInt(8) + 2);
			nextGamingEntity.y = player.y + (random.nextBoolean() ? 1 : - 1) * (random.nextInt(8) + 2);
		}
	}

	Zombie newZombie () throws Exception
	{
		Random random = Main.RANDOM;
		Zombie zombie = new Zombie();
		addEntity("mob", zombie);
		zombie.health = random.nextInt(257);
		zombie.speed = (float) random.nextInt(32) / 8f + 4;
		zombie.item = newZombieItem();
		//zombie.speed = random.nextInt(32) + 16; player.speed = 64;
		return zombie;
	}

	Item newZombieItem ()
	{
		int bound = 10;
		if (index == 1)
		{
			bound = 30;
		}
		else if (index == 2)
		{
			bound = 50;
		}
		else if (index == 3)
		{
			bound = 70;
		}
		int value = Main.RANDOM.nextInt(bound);
		Item zombieItem = null;
		if (value < 10)
		{
			zombieItem = knife;
		}
		else if (value < 20)
		{
			zombieItem = chainsaw;
		}
		else if (value < 30)
		{
			zombieItem = tntSummoner;
		}
		else if (value < 40)
		{
			zombieItem = gun;
		}
		else if (value < 50)
		{
			zombieItem = balls;
		}
		else if (value < 60)
		{
			zombieItem = newber;
		}
		else
		{
			zombieItem = new KunKun.KunBar();
		}
		return zombieItem;
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		Gdx.gl.glClearColor(0, 0, 0, 1);
		batch.setColor(1, 1, 1, 1);
		Texture floorTexture = Textures.stone;
		if (index < LAST_INDEX)
		{
			for (int x = 0; x < width; x ++)
			{
				for (int y = 0; y < height; y ++)
				{
					batch.draw(floorTexture, x, y, 1, 1);
				}
			}
			//batch.draw(Main.getTexture("sb.png"), 0, 0, width, height);
		}
		else
		{
			Utils.draw(batch, floorTexture);
		}
		super.draw(batch);
	}
}
