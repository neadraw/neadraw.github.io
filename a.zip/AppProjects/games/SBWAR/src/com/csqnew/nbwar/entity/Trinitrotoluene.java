package com.csqnew.nbwar.entity;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.entity.mob.*;
import com.badlogic.gdx.audio.*;

public class Trinitrotoluene extends MoveableEntity
{

	public float runTime;
	public Mob by;

	public Trinitrotoluene()
	{
		width = height = 1;
	}

	@Override
	public void act(Gaming game, float delta) throws Exception
	{
		super.act(game, delta);
		if (runTime >= 4)
		{
			AnimationEntity box = new AnimationEntity() {

				@Override
				public Texture texture()
				{
					return Textures.tnt;
				}
			};
			box.width = width * 16;
			box.height = height * 16;
			box.setX(getX());
			box.setY(getY());
			box.set(0.4f, 0, 0, 8, 8, 16, false, false);
			Mob by = this.by;
			if (by == null)
			{
				by = new Mob();
				by.mode = 1;
			}
			boolean ata = true;
			if (by instanceof Moster)
			{
				Mob focus = ((Moster) by).getFocus();
				if (focus != null)
				{
					ata = false;
					if (box.overlaps(focus))
					{
						by.attack(game, box, focus, box.width * box.height, 0.14f, 36);
					}
				}
			}
			if (ata)
			{
				Object[] mobs = game.mobs.list;
				for (int i = 0; i < mobs.length; i ++)
				{
					Mob mob = (Mob) mobs[i];
					if (mob == by) continue;
					if (box.overlaps(mob))
					{
						by.attack(game, box, mob, box.width * box.height, 0.14f, 36);
					}
				}
			}
			game.addEntity("anim", box);
			mode = 1;
			Main.play(Sounds.tnt);
		}
		runTime += delta;
	}

	@Override
	public void draw(Batch batch) throws Exception
	{
		super.draw(batch);
		float width = this.width, height = this.height, x = this.x, y = this.y, runTime = this.runTime;
		Texture texture = Textures.tnt;
		boolean b1 = runTime < 3f;	
		float scale = b1 ? 1 : 1 + (runTime - 3f) / 2f;
		float ox = width / 2f, oy = height / 2f;
		batch.draw(texture, x, y, ox, oy, width, height, scale, scale, 0, 0, 8, 16, 16, false, false);
		batch.setColor(1, 1, 1, b1 ? (float) (Math.max(0, Math.sin(runTime * 9))) : 1);
		batch.draw(texture, x, y, ox, oy, width, height, scale, scale, 0, 0, 13, 1, 1, false, false);
	}
}
