package com.csqnew.nbwar.item;
import com.csqnew.nbwar.gaming.Gaming;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.Texture;
import com.csqnew.nbwar.Main;
import com.csqnew.nbwar.entity.mob.Human;
import com.csqnew.nbwar.entity.ThreeHeaderMosterKiller;
import com.csqnew.nbwar.*;

public class THMKSummoner extends Item
{

	public THMKSummoner ()
	{
		duration = 0.6f;
	}

	@Override
	public boolean call (Gaming game) throws Exception
	{
		Human user = this.user;
		ThreeHeaderMosterKiller killer = new ThreeHeaderMosterKiller();
		killer.setX(user.getX());
		killer.setY(user.getY());
		killer.targetX = killer.getX();
		killer.targetY = killer.getY();
		game.addEntity("mob", killer);
		killer.user = user;
		return super.call(game);
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		Human user = this.user;
		float x = user.getX(), y = user.getY(), r = (user.width + user.height + 1) / 4f;
		batch.draw(Textures.three_header, x - 0.5f, y + r, 0.5f, -r, 1, 2, 1, 1, - user.angle, 0, 0, 8, 16, false, false);
	}
}
