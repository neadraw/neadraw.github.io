package com.csqnew.nbwar.entity.mob;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.gaming.*;
import java.util.*;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.audio.*;

public class Zombie extends NewbeHuman implements Moster {

	public Zombie() {
		speed = 5;
		width = height = 1f;
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		float w = width, h = height;
		batch.draw(Textures.zombie, x, y, w, h, Math.abs(hashCode() % 4) * 8, 0, 8, 8, false, false);
		//batch.draw(texture, x - 0.3f, y - 0.3f, w + 0.4f, h + 0.4f);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception {
		super.act(game, delta);
	}

	@Override
	public void onHurt (Gaming game, Mob by, float value) throws Exception {
		super.onHurt(game, by, value);
		if (by != this) focusMob = by;
		Main.play(Sounds.zombie_hurt);
	}

	@Override
	public void setFocus (Mob mob)
	{
		focusMob = mob;
	}

	@Override
	public Mob getFocus ()
	{
		return focusMob;
	}
}
