package com.csqnew.nbwar.gaming;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.graphics.*;
import java.util.*;
import org.json.*;
import com.badlogic.gdx.audio.*;

public class Gaming extends Nilo {

	public TreeMap<String, EList<Entity>> entities;
	public EList<Entity> blocks, mobs, bloods;
	public Player player;
	public int entitiesCount;

	public Gaming () {
		entities = new TreeMap<>();
		getList("background");
		bloods = getList("blood");
		blocks = getList("block");
		mobs = getList("mob");
		getList("anim");
		player = new Player();
	}

	@Override
	public void create () throws Exception {
		addEntity("mob", player);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception {
		Gaming rawGaming = Main.GAMING;
		Main.GAMING = this;
		entitiesCount = 0;
		for (EList<Entity> list : entities.values()) {
			for (int i = 0; i < list.size(); i ++) {
				Entity entity = list.get(i);
				byte mode = entity.mode;
				try {
					if (mode == 0 || mode == 2) {
						entity.act(this, delta);
					}
					if (mode == 1) {
						list.remove(i);
						i --;
						entity.dead(this);
					}
				} catch (Exception e) {}
			}
			entitiesCount += list.size();
		}
		Main.GAMING = rawGaming;
		if (player.mode == 1) {
			Main.setGaming(new MainGaming());
		}
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		for (EList<Entity> list: entities.values()) {
			for (int i = 0; i < list.size(); i ++) {
				Entity entity = list.get(i);
				byte mode = entity.mode;
				switch (mode) {
					case 0: case 3:
						batch.setColor(Color.WHITE);
						entity.draw(batch);
						break;
					case 1:
						break;
					case 2:
						break;
				}
			}
		}
		if (Main.showBox) {
			for (EList<Entity> list: entities.values()) {
				for (int i = 0; i < list.size(); i ++) {
					Entity entity = list.get(i);
					entity.drawBox(batch);
				}
			}
		}
	}

	public EList<Entity> getList (String family) {
		EList<Entity> list = entities.get(family);
		if (list == null) {
			list = new EList<>();
			entities.put(family, list);
		}
		return list;
	}

	public void addEntity (String family, Entity entity) throws Exception {
		EList<Entity> list = getList(family);
		list.add(entity);
		entity.create();
	}

	@Override
	public void dispose () throws Exception {
		super.dispose();
	}
}
