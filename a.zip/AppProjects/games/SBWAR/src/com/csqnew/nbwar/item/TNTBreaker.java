package com.csqnew.nbwar.item;
import com.csqnew.nbwar.gaming.Gaming;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.csqnew.nbwar.entity.Trinitrotoluene;
import com.csqnew.nbwar.entity.mob.Human;
import com.csqnew.nbwar.util.Mover;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.*;

public class TNTBreaker extends TNTSummoner
{

	public TNTBreaker ()
	{
		duration = 0.3f;
	}

	@Override
	public boolean call (Gaming game) throws Exception
	{
		Human user = this.user;
		TNTBullet entity = new TNTBullet();
		entity.user = user;
		game.addEntity("tnt", entity);
		Mover mover = entity.mover;
		mover.set(user.angle, 20);
		return true;
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		batch.setColor(0.8f, 0.4f, 0.1f, 1);
		super.draw(batch);
		batch.setColor(1, 1, 1, 1);
	}

	public static class TNTBullet extends Gun.Bullet
	{

		@Override
		public void draw (Batch batch) throws Exception
		{
			float width = this.width + 0.4f, height = this.height + 0.4f, x = this.x - 0.2f, y = this.y - 0.2f, runTime = this.runTime;
			Texture texture = Textures.tnt;
			float scale = 1;
			float ox = width / 2f, oy = height / 2f;
			batch.draw(texture, x, y, ox, oy, width, height, scale, scale, 0, 0, 8, 16, 16, false, false);
			batch.setColor(1, 1, 1, (float) Math.max(0, Math.sin(runTime * 9)));
			batch.draw(texture, x, y, ox, oy, width, height, scale, scale, 0, 0, 13, 1, 1, false, false);
		}

		@Override
		public void dead (Gaming game) throws Exception
		{
			Trinitrotoluene tnt = new Trinitrotoluene();
			tnt.width = 0.6f;
			tnt.height = 0.6f;
			tnt.setX(getX());
			tnt.setY(getY());
			tnt.by = user;
			tnt.runTime = 4f;
			game.addEntity("tnt", tnt);
		}
	}
}
