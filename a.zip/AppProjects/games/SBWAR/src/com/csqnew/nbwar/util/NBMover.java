package com.csqnew.nbwar.util;
import com.csqnew.nbwar.entity.Entity;
import com.csqnew.nbwar.gaming.Gaming;

public class NBMover extends Mover
{

	public NBMover (Entity entity)
	{
		super(entity);
	}

	@Override
	public void move (Gaming game, float delta) throws Exception
	{
		super.move(null, delta);
	}
}
