package com.csqnew.nbwar.util;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.gaming.*;
import org.json.*;
import java.io.*;

public class GamingUI {

	public static Stage STAGE;
	public static Touchpad TOUCHPAD_PLAYER_MOVE, TOUCHPAD_PLAYER_FACING;
	public static Button BUTTON_DO, BUTTON_CHECK_ITEM, BUTTON_MENU, BUTTON_ENTER;
	public static TextButton BUTTON_HOME;
	public static Label LABEL;
	public static Group MENU;
	public static Runnable ENTER_EVENT;
	public static boolean HAS_ENTER_EVENT;
	public static TextureRegionDrawable DRAWABLE_MENU, DRAWABLE_CLOSE;

	public static void create () {
		DRAWABLE_MENU = new TextureRegionDrawable(new TextureRegion(new Texture("gui.png"), 7, 0, 7, 7));
		DRAWABLE_CLOSE = new TextureRegionDrawable(new TextureRegion(new Texture("gui.png"), 0, 0, 7, 7));
		Graphics graphics = Gdx.graphics;
		BitmapFont font = Main.FONT;
		float width = graphics.getWidth(), height = graphics.getHeight();
		float size = Math.min(width, height), unit = size / 8;
		Stage stage = new Stage();
		TextureRegionDrawable pad = new TextureRegionDrawable(new TextureRegion(Main.newColorTexture(0xffffffa0)));
		TextureRegionDrawable pad2 = new TextureRegionDrawable(new TextureRegion(Main.newColorTexture(0x00000080)));
		TextureRegionDrawable alpha0 = new TextureRegionDrawable(new TextureRegion(Main.newColorTexture(0)));
		Touchpad.TouchpadStyle playerMoveTouchpadStyle = new Touchpad.TouchpadStyle(pad, pad2);
		playerMoveTouchpadStyle.knob.setMinWidth(unit);
		playerMoveTouchpadStyle.knob.setMinHeight(unit);
		Touchpad playerMoveTouchpad = new Touchpad(0, playerMoveTouchpadStyle);
		playerMoveTouchpad.setPosition(unit, unit);
		playerMoveTouchpad.setSize(unit * 2, unit * 2);
		stage.addActor(playerMoveTouchpad);
		TOUCHPAD_PLAYER_MOVE = playerMoveTouchpad;
		Button.ButtonStyle buttonStyle = new Button.ButtonStyle();
		buttonStyle.up = pad;
		buttonStyle.down = alpha0;
		Button doButton = new Button(buttonStyle);
		doButton.setPosition(width - unit * 3, unit * 5);
		doButton.setSize(unit * 2, unit * 2);
		stage.addActor(doButton);
		BUTTON_DO = doButton;
		Button.ButtonStyle buttonStyle2 = new Button.ButtonStyle();
		buttonStyle2.up = pad2;
		buttonStyle2.down = alpha0;
		Button checkItemButton = new Button(buttonStyle2);
		checkItemButton.setPosition(doButton.getX(), doButton.getY());
		checkItemButton.setSize(unit, unit);
		checkItemButton.addListener(new ClickListener() {
				public void clicked (InputEvent event, float x, float y) {
					Main.GAMING.player.checkItem();
				}
			});
		stage.addActor(checkItemButton);
		BUTTON_CHECK_ITEM = checkItemButton;
		Label.LabelStyle labelStyle = new Label.LabelStyle();
		labelStyle.font = font;
		labelStyle.fontColor = Color.BLACK;
		labelStyle.background = pad;
		Label label = new Label("Loading", labelStyle);
		label.setBounds(0, height - unit, unit * 3, unit);
		label.setFontScale(unit / 64f);
		label.setAlignment(Align.center);
		stage.addActor(label);
		LABEL = label;
		TextButton.TextButtonStyle textButtonStyle = new TextButton.TextButtonStyle();
		textButtonStyle.up = pad2;
		textButtonStyle.down = alpha0;
		textButtonStyle.font = font;
		textButtonStyle.fontColor = Color.WHITE;
		textButtonStyle.downFontColor = Color.BLACK;
		TextButton homeButton = new TextButton("HOME", textButtonStyle);
		homeButton.setBounds(unit, unit, unit * 2, unit);
		homeButton.getLabel().setAlignment(Align.center);
		homeButton.getLabel().setFontScale(unit / 32f);
		homeButton.addListener(new ClickListener() {
				public void clicked (InputEvent event, float x, float y) {
					Gaming gaming = Main.GAMING;
					if (gaming instanceof PlayGaming) {
						try
						{
							Utils.saveGameData((PlayGaming) gaming);
						}
						catch (IOException e)
						{}
					}
					Main.setGaming(new MainGaming());
				}
			});
		BUTTON_HOME = homeButton;
		buttonStyle = new Button.ButtonStyle();
		buttonStyle.up = DRAWABLE_MENU;
		buttonStyle.down = alpha0;
		Button menuButton = new Button(buttonStyle);
		menuButton.setBounds(width - unit, height - unit, unit, unit);
		menuButton.addListener(new ClickListener() {
				public void clicked (InputEvent event, float x, float y) {
					Group menu = GamingUI.MENU;
					menu.setVisible(! menu.isVisible());
					BUTTON_MENU.getStyle().up = menu.isVisible() ? DRAWABLE_CLOSE : DRAWABLE_MENU;
				}
			});
		BUTTON_MENU = menuButton;
		stage.addActor(menuButton);
		Group menu = new Group();
		menu.setBounds(0, 0, width, height - unit);
		menu.addActor(homeButton);
		menu.setVisible(false);
		menu.addActor(homeButton);
		MENU = menu;
		stage.addActor(menu);
		Button enterButton = new Button(buttonStyle);
		enterButton.setSize(unit, unit);
		enterButton.setPosition(width / 2 - unit / 2, unit);
		enterButton.addListener(new ClickListener() {
				public void clicked (InputEvent event, float x, float y) {
					if (ENTER_EVENT == null) return;
					ENTER_EVENT.run();
				}
			});
		stage.addActor(enterButton);
		BUTTON_ENTER = enterButton;
		Touchpad playerFacingTouchpad = new Touchpad(0, playerMoveTouchpadStyle);
		playerFacingTouchpad.setSize(unit * 2, unit * 2);
		playerFacingTouchpad.setPosition(width - playerFacingTouchpad.getWidth() - unit, unit);
		stage.addActor(playerFacingTouchpad);
		TOUCHPAD_PLAYER_FACING = playerFacingTouchpad;
		Gdx.input.setInputProcessor(stage);
		STAGE = stage;
		menu.addListener(new InputListener() {

			float lastX, lastY;

			public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
				lastX = x;
				lastY = y;
				return true;
			}

			public void touchDragged (InputEvent event, float x, float y, int pointer) {
				float tranX = x - lastX, tranY = y - lastY;
				float min = Math.min(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
				Main.MATRIX_X -= tranX / min * Main.SCREEN_SIZE;
				Main.MATRIX_Y -= tranY / min * Main.SCREEN_SIZE;
				lastX = x;
				lastY = y;
			}

			public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
			}
		});
	}

	public static void setEnterEvent (Runnable event) {
		ENTER_EVENT = event;
		HAS_ENTER_EVENT = true;
	}
}
