package com.csqnew.nbwar.item;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.mob.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.graphics.*;

public class Pickaxe extends Item {

	public MyEntity entity;
	public Entity focus;
	public float runTime;

	public Pickaxe () {
		duration = 0.4f;
		MyEntity entity = new MyEntity();
		entity.width = 0.2f;
		entity.height = 0.2f;
		this.entity = entity;
	}

	@Override
	public void act (Gaming game, float delta) throws Exception {
		super.act(game, delta);
		if (focus != null) {
			Human user = this.user;
			MyEntity entity = this.entity;
			entity.setX(user.getX());
			entity.setY(user.getY());
			Mover mover = entity.mover;
			mover.set(user.angle, (user.width + user.height) / 4 + 0.8f);
			mover.move(null, 1);
			if (! entity.overlaps(focus) || focus.mode == 1) {
				focus = null;
				runTime = 0;
				return;
			}
			runTime += delta;
			if (runTime >= focus.hard()) {
				focus.mode = 1;
				focus = null;
		 		runTime = 0;
			}
		}
	}

	@Override
	public boolean call (Gaming game) throws Exception {
		Human user = this.user;
		MyEntity entity = this.entity;
		entity.setX(user.getX());
		entity.setY(user.getY());
		Mover mover = entity.mover;
		mover.set(user.angle, (user.width + user.height) / 4 + 0.8f);
		mover.move(game, 1);
		return false;
	}

	@Override
	public void draw (Batch batch) throws Exception {
		super.draw(batch);
		Human user = this.user;
		MyEntity entity = this.entity;
		entity.setX(user.getX());
		entity.setY(user.getY());
		Mover mover = entity.mover;
		mover.set(user.angle, (user.width + user.height) / 4 + 0.5f);
		mover.move(null, 1);
		float runTime = this.runTime;
		batch.draw(Textures.pickaxe, entity.x - 0.5f, entity.y - 0.5f, 0.5f, 0.5f, 1, 1, 1, 1, - user.angle + 45 + (float) Math.sin(runTime * 20) * 45, 0, 0, 8, 8, false, false);
		Entity focus = this.focus;
		if (focus != null) {
			Color rawColor = batch.getColor();
			batch.setColor(1, 1, 1, runTime / focus.hard());
			batch.draw(Main.TEXTURE_WHITE, focus.x, focus.y, focus.width, focus.height);
			batch.setColor(rawColor);
		}
	}

	boolean isDrawBox;

	@Override
	public void drawBox(Batch batch) throws Exception {
		super.drawBox(batch);
		isDrawBox = true;
		Human user = this.user;
		MyEntity entity = this.entity;
		entity.setX(user.getX());
		entity.setY(user.getY());
		Mover mover = entity.mover;
		mover.set(user.angle, (user.width + user.height) / 4 + 0.8f);
		mover.move(Main.GAMING, 1);
		entity.drawBox(batch);
		isDrawBox = false;
	}

	class MyEntity extends MoveableEntity {

		public MyEntity () {
			width = height = 0f;
		}

		@Override
		public void onCollisionBlock (Entity block, boolean is) throws Exception {
			super.onCollisionBlock(block, is);
			if (!isDrawBox) focus = block;
		}
	}
}
