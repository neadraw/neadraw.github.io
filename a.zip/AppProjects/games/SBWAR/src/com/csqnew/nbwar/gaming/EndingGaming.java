package com.csqnew.nbwar.gaming;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;

public class EndingGaming extends PlayGaming {

	@Override
	public void act(Gaming game, float delta) throws Exception {
		super.act(game, delta);
		Main.TITLE = "Ending";
	}

	@Override
	public void draw(Batch batch) throws Exception {
		BitmapFont font = Main.FONT;
		font.setColor(1, 1, 1, 1);
		font.setScale(0.3f);
		font.draw(batch, "BY CHENG SHIQUAN", 0, 1);
		super.draw(batch);
	}
}
