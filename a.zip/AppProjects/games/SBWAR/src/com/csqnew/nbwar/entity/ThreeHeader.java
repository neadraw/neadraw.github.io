package com.csqnew.nbwar.entity;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.item.*;
import com.badlogic.gdx.graphics.Texture;
import com.csqnew.nbwar.util.Mover;
import com.csqnew.nbwar.util.NBMover;

public class ThreeHeader extends Mob
{
	public Human user;
	public float angle, itemUsedTime, targetX, targetY;
	public Mob focus;
	public boolean hasTarget;

	public ThreeHeader ()
	{
		width = height = 3;
		user = new Human();
		user.mode = 1;
		health = 2000;
		mover = new NBMover(this);
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		float x = this.x, y = this.y, width = this.width, height = this.height;
		Texture texture = Textures.three_header;
		batch.draw(texture, x + width / 3f, y, 0.5f, 0.5f, width / 3f, height / 3f, 1, 1, 0, 0, 8, 8, 8, false, false);
		float angle = this.angle;
		float centerX = getX(), centerY = getY();
		batch.draw(texture, centerX - 0.5f, centerY - 0.5f, 0.5f, 0.5f, 1, 1, 1, 1, 180 - angle, 0, 0, 8, 8, false, false);
		batch.draw(texture, centerX - 1.5f, centerY - 0.5f, 1.5f, 0.5f, 1, 1, 1, 1, 180 - angle, 0, 0, 8, 8, false, false);
		batch.draw(texture, centerX + 0.5f, centerY - 0.5f, - 0.5f, 0.5f, 1, 1, 1, 1, 180 - angle, 0, 0, 8, 8, false, false);
	}

	@Override
	public void onBreakBlood (Gaming game, BloodEntity blood)
	{
		super.onBreakBlood(game, blood);
		blood.red = 0;
		blood.width = blood.height = 0.2f;
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		super.act(game, delta);
		width = height = 3;
		Mob focus = this.focus;
		setX(getX() + (targetX - getX()) * (Math.abs(targetX - getX()) < 6f ? 5 : 1) * delta);
		setY(getY() + (targetY - getY()) * (Math.abs(targetY - getY()) < 6f ? 5 : 1) * delta);
		if (focus != null)
		{
			if (focus.mode == 1)
			{
				focus = null;
			}
			else
			{
				if ((Math.abs(targetX - getX()) <= 1f && Math.abs(targetY - getY()) <= 1f))
				{
					targetX = focus.getX() + (int) (Math.random() * 16) - 8;
					targetY = focus.getY() + (int) (Math.random() * 16) - 8;
				}
				if (focus.distance(this) < 10)
				{
					angle = (float) (Math.atan2(focus.getX() - getX(), focus.getY() - getY()) * 180 / Math.PI);
					if (itemUsedTime >= 0.04f)
					{
						breakBullets(game);
						itemUsedTime = 0;
					}
					itemUsedTime += delta;
				}
			}
		}
		this.focus = focus;
	}

	public void breakBullets (Gaming game) throws Exception
	{
		Human user = this.user;
		float userX = user.x, userY = user.y;
		user.setX(getX());
		user.setY(getY());
		game.addEntity("bullet", newBullet());
		user.mover.set(angle - 90, 1);
		user.mover.move(null, 1);
		game.addEntity("bullet", newBullet());
		user.mover.move(null, - 2);
		game.addEntity("bullet", newBullet());
		user.x = userX;
		user.y = userY;
	}

	public Bullet newBullet ()
	{
		Bullet bullet = new Bullet();
		bullet.initBullet(this);
		return bullet;
	}

	@Override
	public void onHurt (Gaming game, Mob by, float value) throws Exception
	{
		if (focus == null) focus = by;
		super.onHurt(game, by, value);
	}

	public static class Bullet extends MoveableEntity
	{

		public float runTime;
		public ThreeHeader from;

		public void initBullet (ThreeHeader from) {
			this.from = from;
			width = height = 0.4f;
			Human user = from.user;
			setX(user.getX());
			setY(user.getY());
			mover.set(from.angle, 20);
		}

		@Override
		public void act (Gaming game, float delta) throws Exception
		{
			if (runTime >= 1.5f) {
				mode = 1;
				return;
			}
			runTime += delta;
			ThreeHeader from = this.from;
			Human user = from.user;
			Mob focus = from.focus;
			Mover mover = this.mover;
			if (focus != null) {
				if (overlaps(focus)) {
					mover.move(null, - 1);
					user.attack(game, this, focus, 4, 0.1f, 2);
					mode = 1;
				}
			}
			mover.move(null, delta);
		}

		@Override
		public void draw (Batch batch) throws Exception
		{
			batch.draw(Textures.three_header, x, y, 0.5f, 0.5f, width, height, 1, 1, 0, 8, 0, 8, 8, false, false);
		}
	}
}
