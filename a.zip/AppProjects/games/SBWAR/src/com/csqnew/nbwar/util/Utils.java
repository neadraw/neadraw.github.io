package com.csqnew.nbwar.util;
import com.csqnew.nbwar.gaming.PlayGaming;
import com.csqnew.nbwar.gaming.Gaming;
import java.io.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;

public class Utils
{

    public static boolean isLineIntersectRectangle (float linePointX1, float linePointY1, float linePointX2, float linePointY2, float rectangleLeftTopX, float rectangleLeftTopY, float rectangleRightBottomX, float rectangleRightBottomY)
	{
		float lineHeight = linePointY1 - linePointY2;
		float lineWidth = linePointX2 - linePointX1;
		float t1 = lineHeight * rectangleLeftTopX + lineWidth * rectangleLeftTopY;
		float t2 = lineHeight * rectangleRightBottomX + lineWidth * rectangleRightBottomY;
		float t3 = lineHeight * rectangleLeftTopX + lineWidth * rectangleRightBottomY;
		float t4 = lineHeight * rectangleRightBottomX + lineWidth * rectangleLeftTopY;
		float c = linePointX1 * linePointY2 - linePointX2 * linePointY1;
		if ((t1 + c >= 0 && t2 + c <= 0)
			|| (t1 + c <= 0 && t2 + c >= 0)
			|| (t3 + c >= 0 && t4 + c <= 0)
			|| (t3 + c <= 0 && t4 + c >= 0))
		{
			if (rectangleLeftTopX > rectangleRightBottomX)
			{
				float temp = rectangleLeftTopX;
				rectangleLeftTopX = rectangleRightBottomX;
				rectangleRightBottomX = temp;
			}
			if (rectangleLeftTopY < rectangleRightBottomY)
			{
				float temp1 = rectangleLeftTopY;
				rectangleLeftTopY = rectangleRightBottomY;
				rectangleRightBottomY = temp1;
			}
			if ((linePointX1 < rectangleLeftTopX && linePointX2 < rectangleLeftTopX)
				|| (linePointX1 > rectangleRightBottomX && linePointX2 > rectangleRightBottomX)
				|| (linePointY1 > rectangleLeftTopY && linePointY2 > rectangleLeftTopY)
				|| (linePointY1 < rectangleRightBottomY && linePointY2 < rectangleRightBottomY))
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return false;
		}
    }

	public static void saveGameData (PlayGaming gaming) throws IOException
	{
		ObjectOutputStream out = new ObjectOutputStream(Gdx.files.external("sbwar.ser").write(false));
		out.writeObject(gaming);
		out.flush();
		out.close();
	}

	public static PlayGaming readGameData () throws Exception
	{
		ObjectInputStream in = new ObjectInputStream(Gdx.files.external("sbwar.ser").read());
		Object data = in.readObject();
		in.close();
		return (PlayGaming) data;
	}

	public static void draw (Batch batch, Texture texture)
	{
		if (Main.SCREEN_SIZE >= 32) return;
		float width = Main.SCREEN_WIDTH, height = Main.SCREEN_HEIGHT;
		float startX = (float) Math.floor(Main.MATRIX_X) - width / 2f - 1, endX = startX + width + 2;
		float startY = (float) Math.floor(Main.MATRIX_Y) - height / 2f - 1, endY = startY + height + 2;
		for (float nowX = startX; nowX <= endX; nowX += 1) {
			for (float nowY = startY; nowY <= endY; nowY += 1) {
				batch.draw(texture, nowX, nowY, 1, 1);
			}
		}
	}
}
