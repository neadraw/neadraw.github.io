package com.csqnew.nbwar.entity.boss;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.item.*;
import com.csqnew.nbwar.util.*;
import java.util.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.entity.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;

public class NBZombie extends Zombie {

	public Chainsaw chainsaw;
	public Gun gun;
	public KunKun.KunBar kunbar;
	public float canSummonHelperTime;

	public NBZombie() {
		width = height = 8;
		health = 4096;
		item = new ZombieSummoner();
		chainsaw = new Chainsaw();
		chainsaw.duration = 0.3f;
		chainsaw.size = 4;
		speed = 16f;
		gun = new Gun();
		kunbar = new KunKun.KunBar();
	}

	@Override
	public void create() throws Exception {
		super.create();
	}

	@Override
	public void act(Gaming game, float delta) throws Exception {
		if (focusMob != null) if (distance(focusMob) < 12) isUseItem = true;else isUseItem = false;
		canSummonHelperTime += delta;
		if (canSummonHelperTime >= 10) canSummonHelperTime = 10;
		super.act(game, delta);
	}

	@Override
	public void onHurt(Gaming game, Mob by, float value) throws Exception {
		//super.onHurt(game, by, value);
		if (focusMob == null) focusMob = by;
		if (focusMob instanceof Player) health += by == focusMob ? value / 5f : value;
		Random random = Main.RANDOM;
		if (overlaps(by)) {
			MobHurtMover byMover = new MobHurtMover(by);
			byMover.maxTime = 0.5f;
			byMover.set(by.getX() - getX(), by.getY() - getY(), 6 * (by.width + by.height));
			by.mover.add(byMover);
		} else if (distance(by) >= 1.6f) {
			if (random.nextInt(4) == 0) {
				MyBlock block = new MyBlock();
				if (random.nextBoolean()) {
					if (by.x > x) {
						block.x = x + width;
					} else {
						block.x = x - 1;
					}
					block.y = y;
					block.width = 1;
					block.height = 8;
				} else {
					block.x = x;
					if (by.y > y) {
						block.y = y + height;
					} else {
						block.y = y - 1;
					}
					block.width = 8;
					block.height = 1;
				}
				game.addEntity("block", block);
			}
		}
		if (random.nextInt(16) > 0) {
			return;
		}
		if (random.nextInt(16) == 0) {
			Trinitrotoluene tnt = new Trinitrotoluene();
			tnt.by = this;
			tnt.width = tnt.height = 3;
			tnt.setX(getX());
			tnt.setY(getY());
			game.addEntity("tnt", tnt);
			return;
		}
		boolean isTnt = random.nextBoolean();
		for (float angle = 0; angle < 360  && canSummonHelperTime >= 2; angle += isTnt ? 12: 36) {
			TimerMover mover = new TimerMover(null);
			mover.maxTime = 0.6f;
			mover.set(angle, 16);
			if (isTnt) {
				Trinitrotoluene tnt = new Trinitrotoluene();
				mover.entity = tnt;
				tnt.by = this;
				tnt.mover.add(mover);
				tnt.width = tnt.height = 1.2f;
				tnt.setX(getX());
				tnt.setY(getY());
				tnt.runTime = 2;
				game.addEntity("tnt", tnt);
			} else {
				MobHelper helper = new MobHelper();
				mover.entity = helper;
				game.addEntity("mob", helper);
				helper.health = 256;
				helper.speed = 8;
				helper.item = random.nextInt(32) > 0 ? gun : kunbar;
				helper.mob = this;
				helper.width = helper.height = 1.6f;
				helper.mobFocus = focusMob;
				helper.setX(getX());
				helper.setY(getY());
				helper.mover.add(mover);
			}
		}
		canSummonHelperTime = 0;
	}

	@Override
	public void breakBloods (Gaming game, int count, Mob by) throws Exception
	{
		if (by == focusMob) super.breakBloods(game, count, by);
	}

	public static class ZombieSummoner extends Item {

		public ZombieSummoner() {
			duration = 0.24f;
		}

		@Override
		public boolean call(Gaming game) throws Exception {
			Random random = Main.RANDOM;
			Human user = this.user;
			boolean isNB = user instanceof NBZombie;
			if (isNB) {
				Chainsaw chainsaw = ((NBZombie) user).chainsaw;
				Zombie zombie = new Zombie();
				game.addEntity("mob", zombie);
				zombie.item = random.nextInt(4) == 0 ? chainsaw : this;
				zombie.setX(user.getX());
				zombie.setY(user.getY());
				zombie.speed = 10;
				zombie.focusMob = ((NBZombie) user).focusMob;
				if (zombie.item == chainsaw) {
					zombie.speed = 5;
				}
				zombie.health = random.nextInt(33);
				TimerMover mover = new TimerMover(zombie);
				mover.maxTime = 0.4f;
				mover.set(user.angle, 24);
				zombie.mover.add(mover);
				user.health += random.nextInt(16);
				AfterEffect effect = new AfterEffect(zombie);
				game.addEntity("background", effect);
			}
			if (random.nextInt(isNB ? 4 : 16) == 0) {
				for (int i = 0; i < 4; i ++) {
					Trinitrotoluene tnt = new Trinitrotoluene();
					tnt.by = user;
					TimerMover mover = new TimerMover(tnt);
					mover.maxTime = 0.6f;
					mover.set(user.angle + random.nextInt(45) - 22, random.nextInt(17) + 12);
					tnt.mover.add(mover);
					tnt.width = tnt.height = 0.8f;
					tnt.setX(user.getX());
					tnt.setY(user.getY());
					game.addEntity("gun", tnt);
				}
			}
			return true;
		}
	}

	@Override
	public void draw (Batch batch) throws Exception {
		//batch.draw(Textures.chenjihao, x, y, width, height, 0, 0, 679, 679, false, false);
		/*BitmapFont font = Main.FONT;
		font.setScale(0.2f);
		font.setColor(1, 0, 0, 0.75f);
		String str = String.valueOf(health);
		BitmapFont.TextBounds bounds = font.getBounds(str);
		float boundsWidth = bounds.width;
		Color rawColor = batch.getColor();
		batch.setColor(1, 1, 1, 0.6f);
		batch.draw(Main.TEXTURE_WHITE, getX() - boundsWidth / 2 - 0.05f, y + height + 0.05f, boundsWidth + 0.1f, 0.6f);
		font.draw(batch, str, getX() - boundsWidth / 2, y + height + 0.6f);
		batch.setColor(rawColor);*/
		super.draw(batch);
	}

	public static class AfterEffect extends AnimationEntity {

		public Zombie zombie;
		public Mob focus;

		public AfterEffect(Zombie zombie) {
			this.zombie = zombie;
			focus = zombie.focusMob;
			width = zombie.width + 0.4f;
			height = zombie.height + 0.4f;
			set(4, 0, 0, 16, 16, 32, true, true);
		}

		@Override
		public Texture texture()
		{
			return Textures.portal;
		}

		@Override
		public void act(Gaming game, float delta) throws Exception {
			super.act(game, delta);
			setX(zombie.getX());
			setY(zombie.getY());
			mode = zombie.mode;
			zombie.focusMob = focus;
		}
	}

	public static class MyBlock extends Entity {

		float runTime;

		@Override
		public void act(Gaming game, float delta) throws Exception {
			super.act(game, delta);
			if (runTime >= 0.4f) {
				mode = 1;
				return;
			}
			runTime += delta;
		}

		@Override
		public void draw(Batch batch) throws Exception {
			super.draw(batch);
			batch.draw(Main.TEXTURE_GREEN, x, y, width, height);
		}
	}
}
