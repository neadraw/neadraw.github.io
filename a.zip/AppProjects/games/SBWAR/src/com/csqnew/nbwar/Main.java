package com.csqnew.nbwar;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.entity.mob.*;
import java.util.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.audio.*;
import java.io.*;
import java.nio.*;
import com.badlogic.gdx.utils.*;
import com.csqnew.nbwar.entity.*;

public class Main implements ApplicationListener {

	public static boolean showBox = false;
	public static Matrix4 SCREEN_MATRIX;
	public static Batch GAME_BATCH;
	public static float SCREEN_SIZE = 8, MATRIX_TARGET_SIZE = 8, TIME, ACT_DELTA_X = 1f;
	public static int FPS;
	public static float SCREEN_WIDTH, SCREEN_HEIGHT;
	public static Gaming GAMING;
	public static BitmapFont FONT;
	public static Random RANDOM, RANDOM_2;
	public static MyRandom RANDOM_BACKGROUND;
	public static Texture TEXTURE_GREEN, TEXTURE_RED, TEXTURE_WHITE, TEXTURE_BLACK;
	public static String EXCEPTION_MESSAGE = "", TITLE;
	public static float MATRIX_X, MATRIX_Y, PLAYER_WANT_ANGLE;
	public static boolean PLAYER_AUTO_FOCUS = false, AUTO_GC = false, CAN_PLAY_SOUND = true;

	@Override
	public void create () {
		Textures.create();
		Sounds.create();
		SCREEN_MATRIX = new Matrix4();
		GAME_BATCH = new SpriteBatch();
		RANDOM = new Random();
		RANDOM_2 = new Random();
		RANDOM_BACKGROUND = new MyRandom();
		TEXTURE_GREEN = newColorTexture(0x00ff00ff);
		TEXTURE_RED = newColorTexture(0xff0000ff);
		TEXTURE_WHITE = newColorTexture(0xffffffff);
		TEXTURE_BLACK = newColorTexture(0x000000ff);
		MainGaming gaming = new MainGaming();
		setGaming(gaming);
		Files files = Gdx.files;
		BitmapFont font = new BitmapFont(files.internal("font.fnt"), files.internal("font.png"), false);
		font.setUseIntegerPositions(false);
		FONT = font;
		GamingUI.create();
	}

	@Override
	public void resize (int p1, int p2) {
		Graphics graphics = Gdx.graphics;
		float size = SCREEN_SIZE;
		float width = graphics.getWidth(), height = graphics.getHeight();
		if (width > height) {
			width = size * width / height;
			height = size;
		} else {
			height = size * height / width;
			width = size;
		}
		SCREEN_WIDTH = width;
		SCREEN_HEIGHT = height;
	}

	public static long LAST_HEAP, HEAP;
	public static float REHEAP_TIME;

	@Override
	public void render () {
		final Matrix4 matrix = SCREEN_MATRIX;
		matrix.setTranslation(0, 0, 0);
		resize(0, 0);
		GL20 gl = Gdx.gl;
		gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		gl.glClearColor(0, 0, 0, 1);
		boolean playerAutoFocus = PLAYER_AUTO_FOCUS;
		Graphics graphics = Gdx.graphics;
		float delta = graphics.getDeltaTime();
		float width = SCREEN_WIDTH, height = SCREEN_HEIGHT;
		Batch batch = GAME_BATCH;
		BitmapFont font = FONT;
		Gaming gaming = GAMING;
		Touchpad touchpad = GamingUI.TOUCHPAD_PLAYER_MOVE, touchpad2 = GamingUI.TOUCHPAD_PLAYER_FACING;
		Player player = gaming.player;
		FPS = Gdx.graphics.getFramesPerSecond();
		try {
			TIME += delta;
			float myDelta = 0.0167f;
			int actCount = 0;
			while (TIME >= myDelta) {
				TIME -= myDelta;
				actCount ++;
				if (! GamingUI.MENU.isVisible() && actCount <= 2) {
					player.angle = PLAYER_WANT_ANGLE;
					for (int i = 0; i < 1; i ++) {
						gaming.act(gaming, myDelta * ACT_DELTA_X);
						SCREEN_SIZE += (MATRIX_TARGET_SIZE - SCREEN_SIZE) * myDelta * 0;
					}
				} else {
					TIME %= myDelta;
					break;
				}
			}
		} catch (Exception e) {
			EXCEPTION_MESSAGE = e.toString();
		}
		long heap = Gdx.app.getJavaHeap();
		REHEAP_TIME += delta;
		if (REHEAP_TIME >= 1) {
			REHEAP_TIME = 0;
		}
		if (REHEAP_TIME == 0) {
			HEAP = heap;
			if (AUTO_GC) {
				new Thread() {
					public void run () {
						Runtime runtime = Runtime.getRuntime();
						synchronized (matrix) {
							synchronized (runtime) {
								runtime.gc();
							}
						}
					}
				}.start();
			}
		}
		GamingUI.LABEL.setText("FPS: " + FPS + String.format("  Heap: %.2fMB", (float) HEAP / 1024f / 1024f) + "\nPosition: " + (long) (player.x) + ", " + (long) (player.y) + "  HP: " + player.health);
		LAST_HEAP = heap;
		float matrixScale = 1f;
		matrix.setToOrtho2D((- width / 2) * matrixScale + MATRIX_X, (- height / 2) * matrixScale + MATRIX_Y, width * matrixScale, height * matrixScale);
		batch.setProjectionMatrix(matrix);
		batch.begin();
		try {
			gaming.draw(batch);
			String title = TITLE;
			if (title != null) {
				font.setColor(Color.WHITE);
				font.setScale(Math.min(width, height) / 192);
				BitmapFont.TextBounds bounds = font.getBounds(title);
				font.draw(batch, title, MATRIX_X - bounds.width / 2, MATRIX_Y + height / 2 - height / 8f);
			}
		} catch (Exception e) {
		}
		batch.end();
		Stage stage = GamingUI.STAGE;
		Group menu = GamingUI.MENU;
		stage.act(delta);
		Mover mover = player.mover;
		float speed = player.speed;
		player.autoFocus = playerAutoFocus;
		if (touchpad.isTouched()) {
			float knobX = touchpad.getKnobPercentX(), knobY = touchpad.getKnobPercentY();
			mover.xSpeed = knobX * speed;
			mover.ySpeed = knobY * speed;
		} else {
			mover.stop();
		}
		if (touchpad2.isTouched()) {
			player.autoFocus = false;
			if (menu.isVisible()) {
				SCREEN_SIZE += touchpad2.getKnobPercentX() * delta * SCREEN_SIZE;
				if (SCREEN_SIZE < 0) SCREEN_SIZE = 0;
			} else {
				double degress = Math.atan2(touchpad2.getKnobPercentX(), touchpad2.getKnobPercentY());
				float angle = (float) (degress * 180 / Math.PI);
				PLAYER_WANT_ANGLE = angle;
			}
		} else if (playerAutoFocus) {
			try {
				java.lang.reflect.Field field = Touchpad.class.getDeclaredField("knobPosition");
				field.setAccessible(true);
				Vector2 knobPosition = (Vector2) field.get(touchpad2);
				float r = touchpad2.getWidth() / 2F;
				double degrees = player.angle / 180d * Math.PI;
				float targetX = r + (float) (Math.sin(degrees) * r / 2f);
				float targetY = r + (float) (Math.cos(degrees) * r / 2f);
				float touchpad2Speed = delta * touchpad2.getWidth() / 16F;
				knobPosition.x += (targetX - knobPosition.x) * touchpad2Speed;
				knobPosition.y += (targetY - knobPosition.y) * touchpad2Speed;
			} catch (Throwable e) {}
		}
		if (GamingUI.BUTTON_DO.isPressed()) {
			player.isUseItem = true;
		} else {
			player.isUseItem = false;
		}
		Label label = GamingUI.LABEL;
		if (! menu.isVisible()) {
			float minSize = Math.min(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
			label.setSize(minSize / 2f, minSize / 8f);
			label.setPosition(0, Gdx.graphics.getHeight() - label.getHeight());
		} else {
			label.setBounds(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
			com.badlogic.gdx.utils.StringBuilder builder = label.getText();
			TreeMap<String, EList<Entity>> entities = gaming.entities;
			builder.append("\nMatrix size: " + SCREEN_SIZE);
			builder.append("\nEntities:");
			int count = 0;
			for (String key: entities.keySet()) {
				builder.append("\n");
				builder.append(key);
				builder.append(": ");
				EList list = entities.get(key);
				builder.append(list.size());
				count += list.size();
			}
			builder.append("\nETC: " + count);
		}
		stage.draw();
		Button enterButton = GamingUI.BUTTON_ENTER;
		if (GamingUI.HAS_ENTER_EVENT) {
			if (! enterButton.isVisible()) {
				enterButton.setVisible(true);
			}
		} else {
			if (enterButton.isVisible()) {
				enterButton.setVisible(false);
			}
		}
		GamingUI.HAS_ENTER_EVENT = false;
	}

	public static void setGaming (Gaming gaming) {
		try {
			if (GAMING != null) {
				GAMING.dead(GAMING);
			}
			GAMING = gaming;
			gaming.create();
			Player player = gaming.player;
			MATRIX_X = player.getX();
			MATRIX_Y = player.getY();
		} catch (Exception e) {}
	}

	public static Texture newColorTexture (int color) {
		Pixmap pixmap = new Pixmap(1, 1, Pixmap.Format.RGBA4444);
		pixmap.drawPixel(0, 0, color);
		Texture texture = new Texture(pixmap);
		pixmap.dispose();
		return texture;
	}

	public static void sleep (long millis) {
		try {
			Thread.sleep(millis);
		} catch (Exception e) {}
	}

	public static void play (final Sound sound, final boolean isStop, final float volume) {
		if (CAN_PLAY_SOUND)
		new Thread() {
			public void run () {
				synchronized (sound) {
					if (isStop) sound.stop();
					sound.play(volume);
				}
			}
		}.start();
	}

	public static void play (Sound sound) {
		play(sound, true, 1);
	}

	@Override
	public void pause () {
	}

	@Override
	public void resume () {
	}

	@Override
	public void dispose () {
		Textures.dispose();
		Sounds.dispose();
		GAME_BATCH.dispose();
		GamingUI.STAGE.dispose();
		TEXTURE_WHITE.dispose();
		TEXTURE_GREEN.dispose();
		TEXTURE_BLACK.dispose();
		TEXTURE_RED.dispose();
		if (GAMING != null) {
			try {
				GAMING.dispose();
			} catch (Exception e) {}
		}
	}
}
