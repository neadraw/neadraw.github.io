package com.csqnew.nbwar;
import com.badlogic.gdx.graphics.*;
import java.lang.reflect.*;

public class Textures
{
	public static Texture alan, ball, bedrock, bow,
	chainsaw, flower, gun, health, helper,
	knife, kunbar, laser_gun, nb_cow, newber, pickaxe,
	play, player, portal, red_bedrock, stone, three_header, tnt,
	wandering_trader, wangxiaowu, zombie, clock;//, chenjihao, qianqingwei, chengshiquan;

	public static void create ()
	{
		try
		{
			Field[] fields = Textures.class.getFields();
			for (Field field: fields)
			{
				field.set(null, new Texture("image/" + field.getName() + ".png"));
			}
		}
		catch (Exception e)
		{}
	}

	public static void dispose()
	{
		try
		{
			Field[] fields = Textures.class.getFields();
			for (Field field: fields)
			{
				((Texture)field.get(null)).dispose();
			}
		}
		catch (Exception e)
		{}
	}
}
