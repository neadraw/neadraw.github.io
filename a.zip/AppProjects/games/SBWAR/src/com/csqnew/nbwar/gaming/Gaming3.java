package com.csqnew.nbwar.gaming;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.boss.*;
import com.csqnew.nbwar.entity.mob.*;
import java.util.*;
import com.csqnew.nbwar.item.*;

public class Gaming3 extends PlayGaming
{

	public Wondree boss;
	public int width, height;

	@Override
	public void create() throws Exception
	{
		super.create();
		if (index >= 4)
		{
			boss = new Wondree();
			boss.x = boss.y = 50;
			boss.focus = player;
			addEntity("mob", boss);
			/*NBZombie zb = new NBZombie ();
			zb.x = zb.y = - 50;
			zb.focusMob = boss;
			addEntity("mob", zb);
			boss.focus = zb;
			zb.health = boss.health;*/
		}
		else
		{
			Random random = Main.RANDOM;
			Item[] items = new Item[] {
				new Gun(),
				new Bow(),
				new TNTBreaker(),
				new Throder(),
				new Balls(),
				new TNTSummoner(),
				new Knife(),
				new Chainsaw(),
				new KunKun.KunBar(),
				new Newber(),
			};
			for (int i = 0; i < 24; i ++)
			{
				Bird bird = new Bird();
				bird.health = 256;
				bird.setX(random.nextInt(100) - 50);
				bird.setY(random.nextInt(100) - 50);
				bird.item = items[random.nextInt(items.length)];
				bird.focusMob = player;
				addEntity("mob", bird);
			}
		}
	}

	@Override
	public void act(Gaming game, float delta) throws Exception
	{
		super.act(game, delta);
		Object[] mobs = this.mobs.list;
		int mosterCount = 0;
		for (int i = 0; i < mobs.length; i ++)
		{
			Mob mob = (Mob) mobs[i];
			if (mob instanceof Moster)
			{
				mosterCount ++;
				Moster moster = (Moster) mob;
				moster.setFocus(player);
			}
		}
		if (mosterCount == 0)
		{
			if (index >= 4)
			{
				setGaming(new EndingGaming());
			}
			else
			{
				setGaming(new Gaming3());
			}
		}
		Main.TITLE = "3-" + (index + 1) + "    " + mosterCount + " left";
	}
 
	@Override
	public void draw(Batch batch) throws Exception
	{
		batch.setColor(1, 1, 1, 1);
		Utils.draw(batch, Textures.red_bedrock);
		super.draw(batch);
	}
}
