package com.csqnew.nbwar.entity.mob;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.badlogic.gdx.audio.*;
import com.csqnew.nbwar.gaming.*;
import com.badlogic.gdx.utils.*;
import com.csqnew.nbwar.item.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.entity.*;
import com.badlogic.gdx.*;
import java.util.*;

public class Player extends Human
{

	public EList<Item> items;
	public int itemsIndex = 0, actCount;
	public boolean autoFocus = false;

	public Player ()
	{
		width = height = 0.8f;
		speed = 9f;
		items = new EList<>();
		Main.PLAYER_AUTO_FOCUS = false;
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		if (autoFocus)
		{
			Object[] mobs = game.mobs.list;
			float focusDistance = 1024;
			for (int i = 0; i < mobs.length; i ++)
			{
				Object object = mobs[i];
				if (object == this) continue;
				if (object instanceof NewbeHuman)
				{
					NewbeHuman moster = (NewbeHuman) object;
					if (moster.focusMob != this) continue;
					float xx = moster.getX() - getX(), yy = moster.getY() - getY();
					float distance = Math.abs(xx) + Math.abs(yy);
					if (distance < focusDistance)
					{
						focusDistance = distance;
						angle = (float) (Math.atan2(xx, yy) * 180 / Math.PI);
					}
					continue;
				}
			}
		}
		Entity entity = new Entity();
		entity.width = 0.04f;
		entity.height = 0.04f;
		Mover mover = new Mover(entity);
		entity.setX(getX());
		entity.setY(getY());
		mover.set(0, 14);
		mover.move(game, 1);
		float y1 = entity.getY();
		entity.setX(getX());
		entity.setY(getY());
		mover.set(180, 14);
		mover.move(game, 1);
		float y2 = entity.getY();
		entity.setX(getX());
		entity.setY(getY());
		mover.set(90, 14);
		mover.move(game, 1);
		float x1 = entity.getX();
		entity.setX(getX());
		entity.setY(getY());
		mover.set(270, 14);
		mover.move(game, 1);
		float x2 = entity.getX();
		float angle = this.angle % 360;
		if (angle < 0) angle = 360 + angle;
		Main.MATRIX_TARGET_SIZE = Math.min(8f, Math.max(3, Math.abs((angle > 315) || (angle < 45) || (angle > 135 && angle < 225) ? (y1 - y2) : (x1 - x2))));
		float MATRIX_TARGET_X = getX();
		float MATRIX_TARGET_Y = getY();
		float matrixTranslation = speed / 2f * delta / Math.max(1f, Main.SCREEN_SIZE) * 8f;
		Main.MATRIX_X += (MATRIX_TARGET_X - Main.MATRIX_X) * matrixTranslation;
		Main.MATRIX_Y += (MATRIX_TARGET_Y - Main.MATRIX_Y) * matrixTranslation;
		super.act(game, delta);
		actCount ++;
		if (actCount >= 0)
		{
			actCount = 0;
		}
		else
		{
			act(game, delta);
		}
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		/*BitmapFont font = Main.FONT;
		font.setScale(0.04f);
		font.setColor(0, 0.75f, 0, 0.75f);
		String str = String.valueOf(health);
		BitmapFont.TextBounds bounds = font.getBounds(str);
		float boundsWidth = bounds.width;
		Color rawColor = batch.getColor();
		batch.setColor(1, 1, 1, 0.6f);
		batch.draw(Main.TEXTURE_WHITE, getX() - boundsWidth / 2 - 0.05f, y + height + 0.05f, boundsWidth + 0.1f, 0.6f);
		font.draw(batch, str, getX() - boundsWidth / 2, y + height + 0.6f);
		batch.setColor(rawColor);*/
		batch.draw(Textures.player, x, y, width, height);
	}

	@Override
	public void onHurt (Gaming game, Mob by, float value) throws Exception
	{
		super.onHurt(game, by, value);
		Main.play(Sounds.player_hurt);
	}

	public Item getItem (int index)
	{
		if (index >= items.size()) return null;
		return items.get(index);
	}

	public Item getItem ()
	{
		return getItem(itemsIndex);
	}

	public void addItem (Item item)
	{
		items.add(item);
	}

	public void checkItem ()
	{
		itemsIndex ++;
		if (itemsIndex >= items.size())
		{
			itemsIndex = 0;
		}
		item = getItem();
	}

	public Item findItemByClass (Class<?> cla)
	{
		for (int i = 0; i < items.size(); i ++)
		{
			Item item = items.get(i);
			if (cla.isInstance(item))
			{
				return item;
			}
		}
		return null;
	}

	@Override
	public void attack (Gaming game, Entity from, Mob focus, float value, float maxTime, float speed) throws Exception
	{
		super.attack(game, from, focus, value, maxTime, speed);
		//focus.mode = 1;
	}
}
