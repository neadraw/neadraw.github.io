package com.csqnew.nbwar.entity.boss;
import com.csqnew.nbwar.entity.mob.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.util.*;
import com.csqnew.nbwar.item.*;
import com.csqnew.nbwar.entity.*;

public class Wondree extends Human implements Moster
{

	public Mob focus;
	public EList<Zombie> zombies;

	public Wondree ()
	{
		health = 10000;
		width = height = 8;
		speed = 8;
		zombies = new EList<>();
		Chainsaw knife = new Chainsaw();
		knife.size = 3;
		for (int i = 0; i < 24; i ++)
		{
			Zombie zombie = new Zombie();
			zombie.item = knife;
			zombie.speed = 0;
			zombies.add(zombie);
		}
	}

	@Override
	public void create() throws Exception
	{
		super.create();
		Gaming game = Main.GAMING;
		EList<Zombie> zombies = this.zombies;
		for (int i = 0; i < zombies.size(); i ++)
		{
			Zombie zombie = zombies.get(i);
			zombie.health = 10000;
			game.addEntity("mob", zombie);
		}
	}

	@Override
	public void act(Gaming game, float delta) throws Exception
	{
		if (focus == null)
		{
			super.act(game, delta);
			return;
		}
		float angle = (float) (Math.atan2(focus.getX() - getX(), focus.getY() - getY()) * 180 / Math.PI);
		Mover mover = this.mover;
		mover.set(angle, speed);
		this.angle += 120 * delta;
		this.angle %= 360;
		angle = this.angle;
		EList<Zombie> zombies = this.zombies;
		float zan = angle, zanadd = 360f / zombies.size();
		float dist = (float) (24 + Math.sin(angle / 180 * Math.PI) * 6);
		for (int i = 0; i < zombies.size(); i ++)
		{
			float zand = (float) (zan / 180f * Math.PI);
			Zombie zombie = zombies.get(i);
			zombie.width = zombie.height = dist / 5f;
			zombie.setX(getX() + (float) Math.sin(zand) * dist);
			zombie.setY(getY() + (float) Math.cos(zand) * dist);
			zombie.focusMob = focus;
			zan += zanadd;
		}
		if (overlaps(focus))
		{
			Trinitrotoluene tnt = new Trinitrotoluene();
			tnt.by = this;
			tnt.runTime = 4f;
			tnt.width = tnt.height = 3;
			tnt.setX(getX());
			tnt.setY(getY());
			game.addEntity("tnt", tnt);
		}
		super.act(game, delta);
	}

	@Override
	public void draw(Batch batch) throws Exception
	{
		batch.draw(Textures.wangxiaowu, x, y, width, height);
	}

	@Override
	public void dead(Gaming game) throws Exception
	{
		super.dead(game);
		Object[] list = zombies.list;
		for (Object obj: list)
		{
			((Mob) obj).mode = 1;
		}
	}

	@Override
	public void setFocus(Mob mob)
	{
		focus = mob;
	}

	@Override
	public Mob getFocus()
	{
		return focus;
	}
}
