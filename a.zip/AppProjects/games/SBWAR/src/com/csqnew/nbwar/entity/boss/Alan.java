package com.csqnew.nbwar.entity.boss;
import com.csqnew.nbwar.entity.mob.Human;
import com.csqnew.nbwar.entity.mob.Mob;
import com.csqnew.nbwar.gaming.Gaming;
import com.csqnew.nbwar.entity.mob.Player;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.csqnew.nbwar.entity.mob.NewbeHuman;
import com.badlogic.gdx.graphics.Texture;
import com.csqnew.nbwar.item.Throder;
import com.csqnew.nbwar.entity.Laser;
import com.csqnew.nbwar.entity.ThreeHeader;
import com.csqnew.nbwar.entity.mob.Moster;
import com.csqnew.nbwar.item.TNTBreaker;
import com.csqnew.nbwar.*;

public class Alan extends Human implements Moster
{

	public Mob focus;
	public float time1;
	public ThreeHeader th1;
	public boolean ride = true;

	public Alan ()
	{
		width = height = 8;
		health = 100000;
		speed = 16;
		item = new TNTBreaker();
		item.duration = 0.2f;
		th1 = new ThreeHeader();
	}

	@Override
	public void create () throws Exception
	{
		super.create();
		th1.setX(getX());
		th1.setY(getY());
		th1.targetX = getX();
		th1.targetY = getY();
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		super.draw(batch);
		//batch.draw(Textures.qianqingwei, x, y, width, height, 0, 100, 594, 594, false, false);
		batch.draw(Textures.alan, x, y, width, height);
		th1.draw(batch);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		super.act(game, delta);
		th1.health = 1000;
		th1.mode = 1;
		Mob focus = this.focus;
		th1.focus = focus;
		th1.act(game, delta);
		if (ride)
		{
			setX(th1.getX());
			setY(th1.getY());
		}
		if (focus == null) return;
		if (focus.mode == 1)
		{this.focus = null; isUseItem = false; mover.stop(); return;}
		angle = (float) (Math.atan2(focus.getX() - getX(), focus.getY() - getY()) * 180 / Math.PI);
		if (distance(focus) > 20)
		{
			mover.set(angle, speed);
		}
		if (distance(focus) > (ride ? 5 : 15))
		{

			if (time1 > 3)
			{
				switch ((int) (Math.random() * 2))
				{
					case 0:
						float sX = focus.getX() - 5.5f, sY = focus.getY() - 5.5f;
						for (int i = 0; i < 12; i ++)
						{
							Laser laser = new Laser();
							laser.x = sX;
							laser.y = sY;
							laser.width = 0;
							laser.height = 11;
							game.addEntity("laser", laser);
							sX ++;
						}
						sX = focus.getX() - 5.5f;
						for (int i = 0; i < 12; i ++)
						{
							Laser laser = new Laser();
							laser.user = this;
							laser.x = sX;
							laser.y = sY;
							laser.width = 11;
							laser.height = 0;
							game.addEntity("laser", laser);
							sY ++;
						}
						time1 = 0;
						break;
					case 1:
						for (int i = 0; i < 24; i ++) {
							Laser laser = new Laser();
							laser.user = this;
							laser.width = (float) (Math.random() * 1000) - 500;
							laser.height = (float) (Math.random() * 1000) - 500;
							laser.setX(focus.getX());
							laser.setY(focus.getY());
							game.addEntity("laser", laser);
						}
						time1 = - 1.5f;
						break;
				}
			}
		}
		else
		{
			if (distance(focus) < (ride ? 2 : 6))
			{
				mover.stop();
				if (time1 > 3)
				{
					for (int i = 0; i < 24; i ++)
					{
						Laser laser = new Laser();
						laser.user = this;
						laser.x = getX();
						laser.y = getY();
						laser.width = (float) (Math.random() * 600) - 300;
						laser.height = (float) (Math.random() * 600) - 300;
						game.addEntity("laser", laser);
					}
					time1 = 0;
				}
			}
			if (distance(focus) < 9)
			{
				isUseItem = true;
			}
			else
			{
				isUseItem = false;
			}
		}
		time1 += delta;
	}

	@Override
	public void onHurt (Gaming game, Mob by, float value) throws Exception
	{
		super.onHurt(game, by, value);
		if (focus == null) focus = by;
	}

	@Override
	public void breakBloods (Gaming game, int count, Mob by) throws Exception
	{
		if (by == focus) super.breakBloods(game, count, by);
	}

	@Override
	public Mob getFocus ()
	{
		return focus;
	}

	@Override
	public void setFocus (Mob mob)
	{
		focus = mob;
	}
}
