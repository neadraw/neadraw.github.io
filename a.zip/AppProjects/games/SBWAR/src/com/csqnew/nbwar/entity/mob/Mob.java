package com.csqnew.nbwar.entity.mob;
import com.csqnew.nbwar.entity.*;
import com.csqnew.nbwar.gaming.*;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.utils.*;

public class Mob extends MoveableEntity {

	public static Mob MOB = new Mob();
	public int health;
	public float speed, angle;

	@Override
	public void act (Gaming game, float delta) throws Exception {
		super.act(game, delta);
		if (health < 0) {
			mode = 1;
		}
	}

	public void attack(Gaming game, Entity from, Mob focus, float value, float maxTime, float speed) throws Exception {
		focus.health -= value;
		MobHurtMover mover = new MobHurtMover(focus);
		mover.maxTime = maxTime;
		mover.set(focus.getX() - from.getX(), focus.getY() - from.getY(), speed);
		Mover focusMover = focus.mover;
		focusMover.add(mover);
		int bloodCount = Math.min(Math.round(value), 256);
		Mob by = this;
		if (focus == this) {
			by = null;
		}
		focus.breakBloods(game, bloodCount, by);
		focus.onHurt(game, this, value);
	}

	public void breakBloods (Gaming game, int count, Mob by) throws Exception {
		EList<Entity> bloods = game.bloods;
		Object[] bloodsList = bloods.list;
		Object[] bloodsNewList = new Object[bloodsList.length + count];
		System.arraycopy(bloodsList, 0, bloodsNewList, 0, bloodsList.length);
		for (int i = bloodsList.length; i < bloodsNewList.length; i ++) {
			BloodEntity blood = new BloodEntity();
			blood.by = by;
			blood.init(this);
			onBreakBlood(game, blood);
			bloodsNewList[i] = blood;
			if (bloods.size() > 4096) bloods.removeFirst();
		}
		bloods.list = bloodsNewList;
		while (bloods.size() > 4096) {
			bloods.removeFirst();
		}
	}

	public void onBreakBlood (Gaming game, BloodEntity blood)
	{
	}

	public void attack(Gaming game, Entity from, Mob focus, float value) throws Exception {
		attack(game, from, focus, value, 0.2f, 8);
	}

	public void attack(Gaming game, Mob focus, float value) throws Exception {
		attack(game, this, focus, value);
	}

	public void onHurt(Gaming game, Mob by, float value) throws Exception {
	}
}
