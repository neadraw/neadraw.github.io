package com.csqnew.nbwar.entity;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.csqnew.nbwar.gaming.Gaming;
import com.csqnew.nbwar.entity.mob.Mob;
import com.csqnew.nbwar.entity.mob.Moster;
import com.csqnew.nbwar.util.EList;
import com.csqnew.nbwar.entity.ThreeHeader.Bullet;
import com.csqnew.nbwar.entity.mob.Human;
import com.csqnew.nbwar.util.Mover;
import com.csqnew.nbwar.Main;

public class ThreeHeaderMosterKiller extends ThreeHeader
{

	public ThreeHeaderMosterKiller ()
	{
		health = 4000;
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		batch.setColor(0, 1, 0, 1);
		super.draw(batch);
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		Mob focus = this.focus;
		EList<Mob> mosters = new EList<>();
		if (focus == null)
		{
			Object[] mobs = game.mobs.list;
			Class<?> thClass = ThreeHeader.class;
			for (int i = 0; i < mobs.length; i ++)
			{
				Mob mob = (Mob) mobs[i];
				if (mob instanceof Moster || mob.getClass() == thClass)
				{
					mosters.add(mob);
				}
			}
			Object[] mostersList = mosters.list;
			if (mostersList.length > 0)
			{
				focus = (Mob) mostersList[(int)(Math.random() * mostersList.length)];
			}
		}
		else
		{
			if (! (focus instanceof Moster))
			{
				focus = null;
			}
		}
		this.focus = focus;
		super.act(game, delta);
	}

	@Override
	public ThreeHeader.Bullet newBullet ()
	{
		KMBullet bullet = new KMBullet();
		bullet.initBullet(this);
		return bullet;
	}

	public static class KMBullet extends ThreeHeader.Bullet
	{

		@Override
		public void act (Gaming game, float delta) throws Exception
		{
			if (runTime >= 1.5f)
			{
				mode = 1;
				return;
			}
			runTime += delta;
			ThreeHeader from = this.from;
			Human user = from.user;
			Mover mover = this.mover;
			Object[] mobs = game.mobs.list;
			Class<?> thclass = ThreeHeader.class;
			for (int i = 0; i < mobs.length; i ++)
			{
				Mob mob = (Mob) mobs[i];
				if (mob instanceof Moster || mob.getClass() == thclass)
				{
					if (overlaps(mob))
					{
						mover.move(null, - 1);
						user.attack(game, this, mob, 20, 0.1f, 2);
						mode = 1;
					}
				}
			}
			mover.move(null, delta);
		}

		@Override
		public void draw (Batch batch) throws Exception
		{
			batch.setColor(0, 1, 0, 1);
			super.draw(batch);
		}
	}
}
