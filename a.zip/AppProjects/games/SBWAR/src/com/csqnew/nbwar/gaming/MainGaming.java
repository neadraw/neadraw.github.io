package com.csqnew.nbwar.gaming;
import java.util.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.util.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.entity.*;
import com.badlogic.gdx.audio.*;
import com.csqnew.nbwar.item.*;
import com.badlogic.gdx.graphics.*;
import com.csqnew.nbwar.entity.boss.*;
import com.badlogic.gdx.*;

public class MainGaming extends Gaming
{

	public AnimationEntity playEntity;
	public TextureEntity showBoxEntity, hideBoxEntity;
	public float flowersAngle, flowersRotaionSpeed = 1.6f;
	public Zombie lover, wdog;
	public EList<float[]> loverLoves;
	public MyRandom randomx;
	public Entity focus;

	@Override
	public void create () throws Exception
	{
		super.create();
		lover = new Zombie();
		lover.item = new Gun();
		loverLoves = new EList<>();
		wdog = new Zombie();
		wdog.item = new Gun();
		wdog.width = wdog.height = 6;
		wdog.setX(0);
		wdog.setY(12);
		wdog.health = 114514;
		addEntity("mob", wdog);
		AnimationEntity entity = new AnimationEntity() {

			@Override
			public Texture texture()
			{
				return Textures.portal;
			}
		};
		addEntity("stage", entity);
		entity.set(4, 0, 0, 16, 16, 32, true, true);
		entity.x = - 1;
		entity.y = 2;
		entity.width = entity.height = 3;
		playEntity = entity;
		TextureEntity entity2 = new TextureEntity() {

			@Override
			public TextureRegion texture()
			{
				return texture(Textures.player, 0, 0, 8, 8);
			}
		};
		addEntity("stage", entity2);
		entity2.x = - 10f;
		entity2.y = 12;
		entity2.width = entity2.height = 1;
		showBoxEntity = entity2;
		entity2 = new TextureEntity() {

			@Override
			public TextureRegion texture()
			{
				return texture(Textures.play, 0, 0, 8, 8);
			}
		};
		addEntity("stage", entity2);
		entity2.x = 0.5f;
		entity2.y = 12;
		entity2.width = entity2.height = 1;
		hideBoxEntity = entity2;
		player.health = 5201314;
		player.addItem(new Newber());
		player.addItem(new Gun());
		player.addItem(new TNTSummoner());
		player.addItem(new KunKun.KunBar());
		Bow bow = new Bow();
		bow.duration = 0.02f;
		player.addItem(bow);
		player.addItem(new Chainsaw());
		player.addItem(new Balls());
		player.addItem(new Knife());
		player.addItem(new Pickaxe());
		player.addItem(new THMKSummoner());
		player.addItem(new Throder());
		player.addItem(new LaserGun());
		player.addItem(new TNTBreaker());
		player.addItem(new Clock());
		player.checkItem();
		lover.width = lover.height = 4;
		lover.x = - 2;
		lover.y = - 24;
		addEntity("mob", lover);
		randomx = new MyRandom();
	}

	@Override
	public void act (Gaming game, float delta) throws Exception
	{
		Random random = Main.RANDOM;
		if (lover.health < 5201314)
		{
			for (int i = 0; i < 520; i += 9)
			{
				float[] love = new float[4];
				love[0] = lover.getX();
				love[1] = lover.getY();
				love[2] = (float) Math.atan2(random.nextInt(), random.nextInt());
				loverLoves.add(love);
			}
			flowersRotaionSpeed += 0.3f;
			lover.health = 5201314;
		}
		lover.mode = 0;
		super.act(game, delta);
		Main.TITLE = String.format("MAIN    %.2f", Math.sqrt(Math.pow(lover.getX() - player.getX(), 2) + Math.pow(lover.getY() - player.getY(), 2)));
		if (playEntity.overlaps(player))
		{
			if (false)
			{
				PlayGaming gaming = new Gaming3();
				gaming.player.health = 10000;
				gaming.index = 4;
				Main.setGaming(gaming);
			} else
			try
			{
				Main.GAMING = Utils.readGameData();
				return;
			} catch (Exception e) {
				PlayGaming gaming = new Gaming1();
				Main.setGaming(gaming);
			}
			
		}
		if (showBoxEntity.overlaps(player))
		{
			Main.showBox = true;
		}
		if (hideBoxEntity.overlaps(player))
		{
			Main.showBox = false;
		}
		EList<float[]> loves = loverLoves;
		for (int i = 0; i < loves.size(); i ++)
		{
			float[] love = loves.get(i);
			float degrees = love[2];
			love[0] += Math.sin(degrees) * delta * 4;
			love[1] += Math.cos(degrees) * delta * 4;
			love[3] += delta;
			if (love[3] >= 4)
			{
				loverLoves.remove(i);
				i --;
			}
		}
		flowersAngle += delta * flowersRotaionSpeed / 2f;
		Main.MATRIX_TARGET_SIZE = 8;
		if (focus != null)
		{
			player.setX(focus.getX());
			player.setY(focus.getY());
		}
	}

	@Override
	public void draw (Batch batch) throws Exception
	{
		Gdx.gl.glClearColor(0.2f, 0.7f, 0.2f, 1f);
		Texture flowersTexture = Textures.flower;
		float flowersAngle = this.flowersAngle;
		float width = Main.SCREEN_WIDTH, height = Main.SCREEN_HEIGHT;
		MyRandom randomx = this.randomx;
		if (Math.min(width, height) < 8.2)
		{
			int startX = (int) Math.floor(Main.MATRIX_X - width / 2f) - 2;
			int endX = (int) (startX + width + 5f);
			int startY = (int) Math.floor(Main.MATRIX_Y - height / 2f) - 2;
			int endY = (int) (startY + height + 5f);
			for (int x = startX; x <= endX; x += 1f)
			{
				for (int y = endY; y >= startY; y -= 1f)
				{
					randomx.setState(x, y);
					for (int i = 0; i < 3; i ++)
					{
						randomx.setState(randomx.nextLong(), randomx.nextLong());
					}
					for (int i = 0; i < 4; i ++)
					{
						batch.draw(flowersTexture, x - 1 + (randomx.nextInt(50) - 25) / 50f, y - 1 + (randomx.nextInt(50) - 25) / 50f, 1, 0, 2, 2, 1, 1, (float) Math.sin(flowersAngle + randomx.nextInt(32)) * (randomx.nextInt(16) + 4), randomx.nextInt(14) * 16, 0, 16, 16, randomx.nextLong() % 2 == 0, false);
					}
				}
			}
		}
		Object[] loverLoves = this.loverLoves.list;
		super.draw(batch);
		batch.setColor(Color.WHITE);
		Texture healthTexture = Textures.health;
		for (int i = 0; i < loverLoves.length; i ++)
		{
			float[] love = (float[]) loverLoves[i];
			batch.draw(healthTexture, love[0] - 0.4f, love[1] - 0.4f, 0.8f, 0.8f);
		}
		batch.draw(Textures.wangxiaowu, lover.x, lover.y, 4, 4);
		batch.draw(Textures.wangxiaowu, wdog.x, wdog.y, 6, 6);
		if (true) return;
		Object[] mobs = this.mobs.list;
		for (int i = 0; i < mobs.length; i ++)
		{
			Mob mob = (Mob) mobs[i];
			if (mob instanceof ThreeHeader)
			{
				batch.draw(Main.TEXTURE_BLACK, mob.getX() - 25, mob.getY() - 25, 50, 50);
			}
		}
	}
}
