package com.csqnew.nbwar.item;
import com.badlogic.gdx.graphics.g2d.*;
import com.csqnew.nbwar.*;
import com.csqnew.nbwar.entity.mob.*;
import com.csqnew.nbwar.gaming.*;

public class Clock extends Item
{

	public Clock ()
	{
		duration = 0;
	}

	@Override
	public void draw(Batch batch) throws Exception
	{
		super.draw(batch);
		Human user = this.user;
		float ux = user.x, uy = user.y, uw = user.width, uh = user.height;
		batch.draw(Textures.clock, ux - uw, uy - uh, uw * 3, uh * 3);
		batch.setColor(0, 0, 0, 0.4f);
		batch.draw(Main.TEXTURE_BLACK, ux, uy + uh, uw / 2, - uh / 2, uw, uh, 1, 1, - user.angle, 0, 0, 1, 1, false, false);
		batch.setColor(1, 1, 1, 1);
	}

	@Override
	public boolean call(Gaming game) throws Exception
	{
		float angle = user.angle % 180, delta = 1;
		if (angle > - 45 && angle < 45)
		{
			delta = 1;
		}
		else if (angle > 45 && angle < 135)
		{
			delta = 0.5f;
		}
		else if (angle < 0)
		{
			angle = 360 + angle;
		}
		if (angle > 135 && angle < 225)
		{
			delta = 0.2f;
		}
		else if (angle > 225  && angle < 315)
		{
			delta = 0.1f;
		}
		Main.ACT_DELTA_X = delta;
		return super.call(game);
	}
}
