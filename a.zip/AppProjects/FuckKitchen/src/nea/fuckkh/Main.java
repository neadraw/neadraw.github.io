package nea.fuckkh;
import com.badlogic.gdx.*;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.utils.*;
import com.badlogic.gdx.graphics.g3d.attributes.*;
import com.badlogic.gdx.graphics.g3d.environment.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.assets.loaders.*;
import com.badlogic.gdx.graphics.g3d.loader.*;
import com.badlogic.gdx.graphics.VertexAttributes.Usage;

public class Main implements ApplicationListener
{

	PerspectiveCamera cam;
	Model modelHead, modelDick;
	ModelInstance instanceHead, instanceDick;
	ModelBatch batch;
	CameraInputController con;
	Environment env;

	Texture textureHead;

	float time;

	@Override
	public void create ()
	{
		textureHead = new Texture("chenjihao.png");
		cam = new PerspectiveCamera(67, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		cam.near = 1f;
		cam.far = 300f;
		cam.position.set(10, 10, 10);
		cam.lookAt(0, 0, 0);
		cam.update();
		ModelBuilder builder = new ModelBuilder();
		builder.begin();
		Material materialHead = new Material(TextureAttribute.createDiffuse(textureHead));
		Material materialBodyColor = new Material(ColorAttribute.createDiffuse(new Color(0xeeddccff)));
		MeshPartBuilder mpb = builder.part("1", GL20.GL_TRIANGLES, Usage.Position | Usage.Normal | Usage.TextureCoordinates, materialHead);
		mpb.setColor(Color.WHITE);
		mpb.rect(- 2, - 2, 2.1f, 2, - 2, 2.1f, 2, 2, 2.1f, - 2, 2, 2.1f, 2, 2, 2);
		mpb = builder.part("2", GL20.GL_TRIANGLES, Usage.Position | Usage.Normal, materialBodyColor);
		mpb.box(0, 0, 0, 4, 4, 4);
		modelHead = builder.end();
		instanceHead = new ModelInstance(modelHead);
		builder = new ModelBuilder();
		builder.begin();
		mpb = builder.part("1", GL20.GL_TRIANGLES, Usage.Position | Usage.Normal, materialBodyColor);
		mpb.box(0, 0, 0, 2, 2, 8);
		modelDick = builder.end();
		instanceDick = new ModelInstance(modelDick);
		batch = new ModelBatch();
		con = new CameraInputController(cam);
		Gdx.input.setInputProcessor(con);
		env = new Environment();
		env.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.8f, 0.8f, 0.8f, 1));
		env.add(new DirectionalLight().set(0.2f, 0.2f, 0.2f, -5f, -5f, -5f));
	}

	@Override
	public void resize (int p1, int p2)
	{
	}

	@Override
	public void render ()
	{
		Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
		con.target.set(0, 0, 0);
		con.update();
		cam.update();
		batch.begin(cam);
		instanceHead.transform.setTranslation(0, 0, 0);
		batch.render(instanceHead, env);
		instanceDick.transform.setTranslation(0, 0, (float) (Math.sin(time) * 4) - 5);
		batch.render(instanceDick, env);
		batch.end();
		if (Gdx.input.isTouched())
		{
			time += Gdx.graphics.getDeltaTime() * 4;
			if (time >= Math.PI * 16)
			{
				time = 0;
			}
		}
	}

	@Override
	public void pause ()
	{
	}

	@Override
	public void resume ()
	{
	}

	@Override
	public void dispose ()
	{
		textureHead.dispose();
		modelHead.dispose();
		modelDick.dispose();
	}
}
