package nea.fuckkh;
import android.os.*;
import com.badlogic.gdx.backends.android.*;

public class MainActivity extends AndroidApplication {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initialize(new Main());
	}
}