/** Automatically generated file. DO NOT MODIFY */
package nea.fuckkh;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}