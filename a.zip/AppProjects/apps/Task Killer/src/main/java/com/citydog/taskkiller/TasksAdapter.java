package com.citydog.taskkiller;
import android.content.pm.*;
import android.widget.*;
import android.content.*;
import android.view.*;
import android.graphics.drawable.*;
import android.app.*;
import android.content.pm.PackageManager.*;

public class TasksAdapter extends BaseAdapter
{

	@Override
	public int getCount()
	{
		return items.length;
	}

	@Override
	public Object getItem(int p1)
	{
		return items[p1];
	}

	@Override
	public long getItemId(int p1)
	{
		return 0;
	}
	

	MainActivity context;
	Object[] items;
	
	public TasksAdapter (MainActivity context, Object[] items)
	{
		this.context = context;
		this.items = items;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		Activity activity = context;
		PackageManager manager = activity.getPackageManager();
		String item = getItem(position).toString();
		String packageName = item.substring(1);
		char type = item.charAt(0);
		if (convertView == null)
		{
			convertView = activity.getLayoutInflater().inflate(R.layout.list_item_task, parent, false);
		}
		LinearLayout layout = (LinearLayout) convertView;
		View iconView = layout.getChildAt(0);
		TextView nameView = (TextView) layout.getChildAt(1);
		if (type == '%')
		{
			layout.setBackgroundColor(0x30008577);
		}
		else
		{
			layout.setBackground(null);
		}
		try
		{
			ApplicationInfo info = manager.getApplicationInfo(packageName, 0);
			iconView.setBackground(manager.getApplicationIcon(info));
			nameView.setText(manager.getApplicationLabel(info));
		}
		catch (Exception e)
		{}
		return convertView;
	}
}
