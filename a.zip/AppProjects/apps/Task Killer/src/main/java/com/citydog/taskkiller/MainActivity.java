package com.citydog.taskkiller;
 
import android.app.*;
import android.os.*;
import android.widget.*;
import android.content.pm.*;
import android.view.*;
import android.graphics.drawable.*;
import java.util.*;
import android.content.pm.PackageManager.*;

public class MainActivity extends Activity
implements AdapterView.OnItemClickListener
{

	GridView listView;
	TasksAdapter tasksAdapter;
	Object[] packages;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		listView = new GridView(this);
		listView.setNumColumns(3);
		listView.setOnItemClickListener(this);
		setContentView(listView);
		reload();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		menu.add(0, 0, 0, "Kill").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		menu.add(0, 1, 0, "Reload").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item)
	{
		switch (item.getItemId())
		{
			case 0:
				Object[] packages = this.packages;
				ActivityManager manager = getSystemService(ActivityManager.class);
				for (Object object: packages)
				{
					String itemString = object.toString();
					if (itemString.charAt(0) == '%')
					{
						String packageName = itemString.substring(1);
						manager.killBackgroundProcesses(packageName);
					}
				}
				break;
			case 1:
				reload();
				break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		String item = packages[position].toString();
		String packageName = item.substring(1);
		char type = (item.charAt(0) == '%') ? '?': '%';
		packages[position] = type + packageName;
		view.setBackgroundColor(type == '%'? 0x30008577: 0x0);
	}

	public void reload ()
	{
		PackageManager manager = getPackageManager();
		List<ApplicationInfo> apps = manager.getInstalledApplications(PackageManager.GET_META_DATA);
		List<String> packagesList = new ArrayList<>();
		for (ApplicationInfo app: apps)
		{
			if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
			String packageName = app.packageName;
			if (packageName.equals("com.citydog.taskkiller")) continue;
			packagesList.add('%' + packageName);
		}
		packages = packagesList.toArray();
		tasksAdapter = new TasksAdapter(this, packages);
		listView.setAdapter(tasksAdapter);
	}
}
