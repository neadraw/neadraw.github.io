package com.csqnew.pixmap;

import android.view.*;
import android.content.*;
import android.graphics.*;
import com.csqnew.pixmap.pixt.*;

public class PixmapView extends View
{
	public Bitmap bitmap;
	public Paint paint;
	public Rect bitmapRect;
	public float x, y, scale, lastMinSize;
	public Pixt[] pixts;
	public Pixt pixt;

	public PixmapView (Context context)
	{
		super (context);
		bitmapRect = new Rect();
		setBitmap(10, 10);
		resetPosition();
		setBackgroundColor(0xffa0a0a0);
		setLongClickable(true);
		paint = new Paint();
		pixts = new Pixt[] {
			pixt = new MovePixt(this)
		};
	}

	@Override
	protected void onDraw (Canvas canvas)
	{
		super.onDraw(canvas);
		float minSize = lastMinSize = Math.min(canvas.getWidth(), canvas.getHeight());
		Paint paint = this.paint;
		Bitmap bitmap = this.bitmap;
		paint.setColor(0xffffffff);
		RectF dstRect = new RectF(x, y, x + minSize * scale, y + minSize * scale);
		canvas.drawRect(dstRect, paint);
		canvas.drawBitmap(bitmap, bitmapRect, dstRect, paint);
	}

	@Override
	public boolean onTouchEvent (MotionEvent event)
	{
		pixt.onTouchEvent(event);
		return super.onTouchEvent(event);
	}

	public void setBitmap (Bitmap bitmap)
	{
		this.bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
		bitmapRect.set(0, 0, bitmap.getWidth(), bitmap.getHeight());
	}

	public void setBitmap (int width, int height)
	{
		Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		this.bitmap = bitmap;
		bitmapRect.set(0, 0, width, height);
	}

	public void resetPosition ()
	{
		scale = 1;
		x = y = 0;
	}
}
