package com.csqnew.pixmap.pixt;
import com.csqnew.pixmap.*;
import android.view.*;

public class MovePixt extends Pixt
{
	public float lastX, lastY, lastDistance;
	public boolean isMoving;

	public MovePixt (PixmapView pixmap)
	{
		super (pixmap);
	}

	@Override
	public boolean onTouchEvent (MotionEvent event)
	{
		int action = event.getAction();
		PixmapView pixmap = this.pixmap;
		float nowX = event.getX(), nowY = event.getY();
		int pointerCount = event.getPointerCount();
		switch (action)
		{
			case MotionEvent.ACTION_DOWN:
				lastX = nowX;
				lastY = nowY;
				isMoving = true;
				break;
			case MotionEvent.ACTION_MOVE:
				switch (pointerCount)
				{
					case 1:
						if (!isMoving)
						{
							lastX = nowX;
							lastY = nowY;
						}
						isMoving = true;
						pixmap.x += (nowX - lastX);
						pixmap.y += (nowY - lastY);
						lastX = nowX;
						lastY = nowY;
						pixmap.invalidate();
						break;
					case 2:
						float nowX2 = event.getX(1), nowY2 = event.getY(1),
						nowCenterX = (nowX + nowX2) / 2F, nowCenterY = (nowY + nowY2) / 2F,
						nowXDistance = nowX2 - nowX, nowYDistance = nowY2 - nowY,
						nowDistance = (float) Math.sqrt(nowXDistance * nowXDistance + nowYDistance * nowYDistance);
						if (isMoving)
						{
							isMoving = false;
							lastDistance = nowDistance;
						}
						try
						{
							pixmap.scale *= nowDistance / lastDistance;
							pixmap.x -= nowDistance / lastDistance * 2 / pixmap.scale;
							pixmap.y -= 0;
							lastDistance = nowDistance;
							pixmap.invalidate();
						} catch (Exception e) {}
						break;
				}
				break;
			case MotionEvent.ACTION_UP:
				((MainActivity) pixmap.getContext()).setTitle(nowX + " " + nowY);
				break;
		}
		return super.onTouchEvent(event);
	}
}
