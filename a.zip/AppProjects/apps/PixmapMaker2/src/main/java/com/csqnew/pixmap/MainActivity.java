package com.csqnew.pixmap;
 
import android.app.*;
import android.os.*;

public class MainActivity extends Activity
{

	public PixmapView view;

	@Override
	protected void onCreate (Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		view = new PixmapView(this);
		setContentView(view);
	}
} 
