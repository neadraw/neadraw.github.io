package com.csqnew.pixmap.pixt;
import android.view.*;
import com.csqnew.pixmap.*;

public class Pixt
{

	public PixmapView pixmap;

	public Pixt (PixmapView pixmap)
	{
		this.pixmap = pixmap;
	}

	public boolean onTouchEvent (MotionEvent event)
	{
		return false;
	}
}
