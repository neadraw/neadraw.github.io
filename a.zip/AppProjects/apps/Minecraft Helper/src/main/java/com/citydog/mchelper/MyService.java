package com.citydog.mchelper;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.WindowManager.LayoutParams;
import android.graphics.*;
import android.widget.*;
import android.hardware.input.*;
import android.inputmethodservice.*;
import android.view.inputmethod.*;
import java.util.*;

public class MyService extends InputMethodService
{

	public static MyService self;
	public WindowManager windowManager;
	public List<View> views;
	public boolean isShowing;

	@Override
	public void onCreate()
	{
		super.onCreate();
		self = this;
		views = new ArrayList<>();
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
		addButton("F5", KeyEvent.KEYCODE_F5, false, 6, 6, 48, 48, Gravity.LEFT + Gravity.BOTTOM);
		addButton("L", KeyEvent.KEYCODE_L, true, 120, 60, 48, 48, Gravity.RIGHT + Gravity.TOP);
		addButton("R", KeyEvent.KEYCODE_R, true, 60, 60, 48, 48, Gravity.RIGHT + Gravity.TOP);
		showViews();
	}

	public void showViews ()
	{
		if (isShowing) return;
		for (View view: views)
		{
			windowManager.addView(view, view.getLayoutParams());
		}
		isShowing = true;
	}

	public void hideViews ()
	{
		if (!isShowing) return;
		for (View view: views)
		{
			windowManager.removeView(view);
		}
		isShowing = false;
	}

	public LayoutParams newLayoutParams (float x, float y, float width, float height, int gravity)
	{
		LayoutParams params = new LayoutParams();
		params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_SPLIT_TOUCH | LayoutParams.FLAG_NOT_FOCUSABLE;
		params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;
		params.format = PixelFormat.TRANSPARENT;
		float dp = getResources().getDisplayMetrics().density;
		params.gravity = gravity;
		params.x = (int) (x * dp);
		params.y = (int) (y * dp);
		params.width = (int) (width * dp);
		params.height = (int) (height * dp);
		return params;
	}

	public Button newButton (String text, final int keyCode, boolean isLoop, float x, float y, float width, float height, int gravity)
	{
		Button button = new Button(this);
		button.setText(text);
		button.setBackgroundColor(0x80ffffff);
		button.setTextColor(0xff000000);
		if (isLoop)
		{
			button.setOnTouchListener(new View.OnTouchListener() {

					@Override
					public boolean onTouch(View p1, MotionEvent p2)
					{
						sendKeyEvent(keyCode);
						return false;
					}
				});
		}
		else
		{
			button.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1)
					{
						sendKeyEvent(keyCode);
					}
				});
		}
		button.setLayoutParams(newLayoutParams(x, y, width, height, gravity));
		return button;
	}

	public void addButton (String text, final int keyCode, boolean isLoop, float x, float y, float width, float height, int gravity)
	{
		Button button = newButton(text, keyCode, isLoop, x, y, width, height, gravity);
		views.add(button);
	}

	public void sendKeyEvent (int keyCode)
	{
		InputConnection input = getCurrentInputConnection();
		input.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
		input.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
		{
			if(isShowing)
				hideViews();
			else
				showViews();
		}
		return super.onKeyDown(keyCode, event);
	}
}
