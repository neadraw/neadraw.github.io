package com.citydog.mchelper;
 
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.view.inputmethod.*;

public class MainActivity extends Activity implements View.OnClickListener
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Button button = new Button(this);
		button.setText("选择输入法");
		setContentView(button);
		button.setOnClickListener(this);
	}

	@Override
	public void onClick(View p1)
	{
		InputMethodManager manager = getSystemService(InputMethodManager.class);
		manager.showInputMethodPicker();
	}
}
