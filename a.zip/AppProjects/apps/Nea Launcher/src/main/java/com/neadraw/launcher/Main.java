package com.neadraw.launcher;
import android.app.*;
import android.widget.*;
import android.os.*;
import android.view.*;
import android.graphics.*;
import android.content.pm.*;
import java.util.*;
import android.content.*;
import android.net.*;
import android.graphics.drawable.*;

public class Main extends Activity
implements AdapterView.OnItemClickListener,
AdapterView.OnItemLongClickListener
{

	Object[] packs, icons;
	boolean showSystemApp;
	GridView view;

	@Override
	protected void onCreate (Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setTitle("SB_LAUNCHER");
		GridView view = this.view = new GridView(this);
		view.setNumColumns(3);
		view.setFastScrollEnabled(true);
		view.setOnItemClickListener(this);
		view.setOnItemLongClickListener(this);
		view.setBackgroundColor(0xff212121);
		setContentView(view);
		reload();
	}

	public void reload ()
	{
		PackageManager pm = getPackageManager();
		List<ResolveInfo> resolves = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER), 0);
		int size = resolves.size();
		List<Object> packs = new ArrayList<>(), labels = new ArrayList<>(), icons = new ArrayList<>();;
		boolean showSystemApp = this.showSystemApp;
		for (int i = 0; i < size; i ++)
		{
			ResolveInfo resolve = resolves.get(i);
			ActivityInfo ai = resolve.activityInfo;
			String packageName = ai.packageName;
			if (! showSystemApp && ((resolve.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0)) continue;
			icons.add(ai.loadIcon(pm));
			packs.add(packageName);
			labels.add(resolve.loadLabel(pm));
		}
		this.packs = packs.toArray();
		this.icons = icons.toArray();
		view.setAdapter(new LAdapter(labels.toArray()));
	}

	@Override
	public void onItemClick (AdapterView<?> parent, View view, int position, long p4)
	{
		startActivity(getPackageManager().getLaunchIntentForPackage(packs[position].toString()));
	}

	@Override
	public void startActivity (Intent intent)
	{
		try
		{
			super.startActivity(intent);
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		} catch (Throwable e) {}
	}

	@Override
	public boolean onItemLongClick (AdapterView<?> parent, View view, int position, long p4)
	{
		startActivity(new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).setAction("android.settings.APPLICATION_DETAILS_SETTINGS").setData(Uri.parse("package:" + packs[position])));
		return false;
	}

	@Override
	public boolean onCreateOptionsMenu (Menu menu)
	{
		getMenuInflater().inflate(R.layout.menu_main, menu);
		MenuItem hideOrShowMenuItem = menu.getItem(3);
		hideOrShowMenuItem.setTitle(showSystemApp ? R.string.hide_system_app : R.string.show_system_app);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected (MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.menu_reload:
				reload();
				break;
			case R.id.menu_manage:
				startActivity(new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).setClassName("com.android.settings", "com.android.settings.ManageApplications"));
				break;
			case R.id.menu_system_settings:
				startActivity(getPackageManager().getLaunchIntentForPackage("com.android.settings"));
				break;
			case R.id.menu_hide_or_show_system_app:
				showSystemApp =! showSystemApp;
				item.setTitle(showSystemApp ? R.string.hide_system_app : R.string.show_system_app);
				reload();
				break;
		}
		return false;
	}

	@Override
	public void onBackPressed ()
	{
	}

	class LAdapter extends ArrayAdapter<Object>
	{
		public LAdapter (Object[] labels)
		{
			super(Main.this, R.layout.list_launcher, labels);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			LinearLayout layout = (LinearLayout) (convertView == null ? getLayoutInflater().inflate(R.layout.list_launcher, parent, false) : convertView);
			layout.getChildAt(0).setBackground((Drawable) icons[position]);
			TextView text = ((TextView) layout.getChildAt(1));
			text.setText(getItem(position).toString());
			return layout;
		}
	}
} 

