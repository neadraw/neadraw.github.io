package nea.aihelper;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import java.io.*;
import java.net.*;
import org.json.*;
import android.content.*;

public class MainActivity extends Activity
implements Runnable, DialogInterface.OnClickListener
{

	EditText editYou;
	AIHandler aiHandler;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		aiHandler = new AIHandler();
		float dp = getResources().getDisplayMetrics().density;
		int padding = (int) (dp * 24);
		editYou = new EditText(this);
		editYou.setGravity(Gravity.TOP);
		editYou.setPadding(padding, padding, padding, padding);
		setContentView(editYou);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		menu.add(0, 0, 0, android.R.string.yes).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		menu.add(0, 1, 0, android.R.string.cancel).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item)
	{
		switch (item.getItemId())
		{
			case 0:
				message = editYou.getText().toString();
				progress = new ProgressDialog(this);
				progress.setMessage("Loading...");
				progress.show();
				new Thread(this).start();
				break;
			case 1:
				editYou.getText().clear();
				break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	ProgressDialog progress;
	AlertDialog aiDialog;
	String message;

	@Override
	public void run()
	{
		try
		{
			BufferedReader reader = new BufferedReader(new InputStreamReader(new URL("https://api.uutool.cn/aiModel/helper/?text=" + URLEncoder.encode(message, "UTF-8")).openStream()));
			String line = reader.readLine();
			reader.close();
			JSONObject object = new JSONObject(line);
			message = object.getJSONObject("data").getString("result")/*
				.replace("UU在线工具办公助手", "智能AI助手汪孝武")
				.replace("UU助手", "汪狗")
				.replace("阿里云", "Neadraw Studio(内内工作室)")
				.replace("通义千问", "汪孝武")*/;
			message += "\n\n";
			reader = new BufferedReader(new InputStreamReader(new URL("https://api.vvhan.com/api/text/sexy").openStream()));
			while ((line = reader.readLine()) != null)
			{
				message += "\n" + line;
			}
		}
		catch (Exception e)
		{
			message = e.toString();
		}
		Message msg = Message.obtain();
		msg.obj = this;
		aiHandler.sendMessage(msg);
	}

	@Override
	public void onClick(DialogInterface p1, int p2)
	{
		ClipboardManager cliper = getSystemService(ClipboardManager.class);
		cliper.setText(message);
	}
}

class AIHandler extends Handler
{

	@Override
	public void handleMessage(Message msg)
	{
		super.handleMessage(msg);
		MainActivity activity = (MainActivity) msg.obj;
		if (activity.progress != null) activity.progress.dismiss();
		new AlertDialog.Builder(activity).setTitle("AI").setMessage(activity.message).setPositiveButton(android.R.string.ok, null).setNegativeButton(android.R.string.copy, activity).show();
		activity.progress = null;
	}
}
