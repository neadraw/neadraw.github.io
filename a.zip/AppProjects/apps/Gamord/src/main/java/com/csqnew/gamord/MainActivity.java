package com.csqnew.gamord;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.hardware.input.*;
import android.view.inputmethod.*;

public class MainActivity extends Activity
implements AdapterView.OnItemClickListener {

	public ListView listView;

	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ListView listView = new ListView(this);
		this.listView = listView;
		setContentView(listView);
		listView.setOnItemClickListener(this);
		int[] textsId = new int[] {
			R.string.set_input_method,
		};
		int length = textsId.length;
		String[] texts = new String[length];
		for (int i = 0; i < length; i ++) {
			texts[i] = getString(textsId[i]);
		}
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, texts);
		listView.setAdapter(adapter);
	}

	@Override
	public void onItemClick (AdapterView<?> parent, View view, int position, long itemId) {
		switch (position) {
			case 0:
				InputMethodManager manager = getSystemService(InputMethodManager.class);
				manager.showInputMethodPicker();
				break;
		}
	}
}
