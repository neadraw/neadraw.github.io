package com.csqnew.gamord.event;
import com.csqnew.gamord.*;
import android.view.*;
import android.view.inputmethod.*;
import org.w3c.dom.*;
import android.widget.*;

public class KeyEventOuter extends BoardEvent
{

	@Override
	public boolean onTouch (View view, Object[] arguments, MotionEvent event)
	{
		int action = event.getAction();
		IMEService ime = IMEService.self;
		int[] keyCodes = (int[]) arguments[0];
		switch (action)
		{
			case MotionEvent.ACTION_DOWN:
				for (int i = 0; i < keyCodes.length; i ++)
				{
					int keyCode = keyCodes[i];
					ime.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
				}
				break;
			case MotionEvent.ACTION_UP:
				for (int i = 0; i < keyCodes.length; i ++)
				{
					int keyCode = keyCodes[i];
					ime.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
				}
		}
		return false;
	}

	@Override
	public Object[] parseArguments (Node element) throws Exception
	{
		NamedNodeMap attributes = element.getAttributes();
		String[] split = attributes.getNamedItem("codes").getNodeValue().split(",");
		int[] keyCodes = new int[split.length];
		for (int i = 0; i < keyCodes.length; i ++)
		{
			String str = split[i];
			try
			{
				int keyCode = Integer.parseInt(str);
				keyCodes[i] = keyCode;
			}
			catch (NumberFormatException e)
			{
				int keyCode = KeyEvent.class.getField("KEYCODE" + str).getInt(null);
				keyCodes[i] = keyCode;
			}
		}
		return new Object[] {keyCodes};
	}
}
