package com.csqnew.gamord.util;
import android.os.*;
import java.io.*;

public class MyFileUtils {

	public static String getExternalPath () {
		return Environment.getExternalStorageDirectory().getPath() + "/";
	}

	public static String getMyDataPath () {
		return getExternalPath() + "New/gamord/";
	}

	public static File newFile (String path) {
		File file = new File(path);
		if (! file.canRead()) {
			file.getParentFile().mkdirs();
			try {
				file.createNewFile();
			} catch (IOException e) {}
		}
		return file;
	}
}
