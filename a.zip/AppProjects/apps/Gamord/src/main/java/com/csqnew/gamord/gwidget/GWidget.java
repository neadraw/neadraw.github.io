package com.csqnew.gamord.gwidget;
import com.csqnew.gamord.event.BoardEvent;
import org.w3c.dom.Node;

public interface GWidget
{
	public BoardEvent event;
	public Object[] arguments;

	public void init (Node node)
}
