package com.csqnew.gamord.event;
import com.csqnew.gamord.*;
import android.view.*;
import org.w3c.dom.*;

public class BoardEvent {

	public boolean onTouch (View view, Object[] arguments, MotionEvent event) throws Exception {
		return false;
	}

	public Object[] parseArguments (Node element) throws Exception {
		return new Object[0];
	}
}
