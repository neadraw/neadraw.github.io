package com.csqnew.gamord;
import android.inputmethodservice.*;
import android.view.inputmethod.*;
import java.util.*;
import android.view.*;
import android.widget.*;
import android.view.WindowManager.LayoutParams;
import android.graphics.*;
import android.content.*;
import android.app.*;
import android.graphics.drawable.*;
import android.util.*;
import com.csqnew.gamord.event.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import com.csqnew.gamord.util.*;
import android.os.*;
import java.io.*;
import android.text.*;
import com.csqnew.gamord.gwidget.*;

public class IMEService extends InputMethodService
implements View.OnTouchListener {

	public List<View> views;
	public boolean isShowing = false;
	public static IMEService self;

	public IMEService () {
		self = this;
	}

	@Override
	public void onCreate () {
		super.onCreate();
		List<View> views = new ArrayList<View>();
		this.views = views;
		reloadKeyboard();
	}

	public void showKeyboard () {
		List<View> views = this.views;
		int size = views.size();
		WindowManager windowManager = getSystemService(WindowManager.class);
		for (int i = 0; i < size; i ++) {
			View view = views.get(i);
			windowManager.addView(view, view.getLayoutParams());
		}
		isShowing = true;
	}

	public void hideKeyboard () {
		List<View> views = this.views;
		int size = views.size();
		WindowManager windowManager = getSystemService(WindowManager.class);
		for (int i = 0; i < size; i ++) {
			View view = views.get(i);
			windowManager.removeView(view);
		}
		isShowing = false;
	}

	public void showOrHideKeyboard () {
		if (isShowing) {
			hideKeyboard();
		} else {
			showKeyboard();
		}
	}

	@Override
	public boolean onTouch (View p1, MotionEvent p2) {
		return false;
	}

	@Override
	public boolean onKeyDown (int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
			showOrHideKeyboard();
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onDestroy () {
		super.onDestroy();
		hideKeyboard();
	}

	public void reloadKeyboard () {
		try {
			List<View> views = this.views;
			views.clear();
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(MyFileUtils.newFile(MyFileUtils.getMyDataPath() + "board.xml"));
			NodeList list = document.getChildNodes();
			float dp = getResources().getDisplayMetrics().density;
			int textColor = 0xff000000;
			float elevation = 4;
			float textSize = 4;
			GradientDrawable background = new GradientDrawable();
			background.setColor(0xffffffff);
			Map<String, BoardEvent> events = new HashMap<>();
			events.put("keyout", new KeyEventOuter());
			BoardEvent event = null;
			Object[] arguments = null;
			for (int i = 0; i < list.getLength(); i ++) {
				Node item = list.item(i);
				NamedNodeMap attributes = item.getAttributes();
				String name = item.getNodeName();
				if ("button".equals(name)) {
					KeyButton button = new KeyButton(this);
					button.setText(attributes.getNamedItem("text").getNodeValue());
					button.setTextColor(textColor);
					button.setBackground(background);
					button.setTextSize(textSize);
					button.setElevation(elevation * dp);
					button.arguments = arguments;
					button.event = event;
					LayoutParams params = new LayoutParams();
					button.setLayoutParams(params);
					params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_SPLIT_TOUCH | LayoutParams.FLAG_NOT_FOCUSABLE;
					params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;
					params.format = PixelFormat.TRANSPARENT;
					params.width = (int) (Float.parseFloat(attributes.getNamedItem("width").getNodeValue()) * dp);
					params.height = (int) (Float.parseFloat(attributes.getNamedItem("height").getNodeValue()) * dp);
					params.x = (int) (Float.parseFloat(attributes.getNamedItem("x").getNodeValue()) * dp);
					params.y = (int) (Float.parseFloat(attributes.getNamedItem("y").getNodeValue()) * dp);
					String[] gravitySplit = attributes.getNamedItem("gravity").getNodeValue().split(",");
					params.gravity = 0;
					for (String splitItem : gravitySplit) {
						if ("left".equals(splitItem)) {
							params.gravity |= Gravity.LEFT;
						} else if ("right".equals(splitItem)) {
							params.gravity |= Gravity.RIGHT;
						} else if ("top".equals(splitItem)) {
							params.gravity |= Gravity.TOP;
						} else if ("bottom".equals(splitItem)) {
							params.gravity |= Gravity.BOTTOM;
						} else if ("center".equals(splitItem)) {
							params.gravity |= Gravity.CENTER;
						} 
					}
					views.add(button);
				} else if ("event".equals(name)){
					String className = attributes.getNamedItem("class").getNodeValue();
					event = events.get(className);
					arguments = event.parseArguments(item);
				} else if ("style".equals(name)) {
					textColor = Color.parseColor(attributes.getNamedItem("color").getNodeValue());
					textSize = Float.parseFloat(attributes.getNamedItem("text_size").getNodeValue());
					elevation = Float.parseFloat(attributes.getNamedItem("elevation").getNodeValue());
					background = new GradientDrawable();
					background.setColor(Color.parseColor(attributes.getNamedItem("background").getNodeValue()));
					background.setCornerRadius(Float.parseFloat(attributes.getNamedItem("radius").getNodeValue()) * dp);
				}
			}
		} catch (Exception e) {
			Toast.makeText(getApplication(), e.toString(), Toast.LENGTH_LONG).show();
		}
	};

	public void sendKeyEvent (KeyEvent event) {
		getCurrentInputConnection().sendKeyEvent(event);
	}
}
