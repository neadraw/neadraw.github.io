package com.csqnew.gamord.gwidget;

import android.widget.*;
import android.content.*;
import android.view.*;
import android.graphics.drawable.*;
import com.csqnew.gamord.event.*;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class KeyButton extends TextView
implements GWidget
{

	public KeyButton (Context context)
	{
		super(context);
		float dp = getResources().getDisplayMetrics().density;
		setLongClickable(true);
		setGravity(Gravity.CENTER);
		int padding = (int) (dp * 4F);
		setPadding(padding, padding, padding, padding);
	}

	@Override
	public void init (Node node)
	{
	}

	@Override
	public boolean onTouchEvent (MotionEvent event)
	{
		try
		{
			BoardEvent bevent = this.event;
			bevent.onTouch(this, arguments, event);
		}
		catch (Exception e)
		{
		}
		return super.onTouchEvent(event);
	}
}
