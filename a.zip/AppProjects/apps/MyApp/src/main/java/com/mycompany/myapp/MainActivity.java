package com.mycompany.myapp;
 
import android.app.*;
import android.os.*;

public class MainActivity extends Activity
{
}
