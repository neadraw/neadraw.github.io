package com.csqnew.cbtimer;
import android.widget.*;
import android.view.*;
public class M extends android.app.Activity implements View.OnClickListener {
	long beginTime;
	protected void onCreate (android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		TextView view = new TextView(this);
		view.setTextSize(72);
		view.setTextColor(0xff008577);
		view.setText("CBTIMER");
		view.setGravity(Gravity.CENTER);
		view.setOnClickListener(this);
		setContentView(view);
	}
	public void onClick(View view) {
		TextView text = (TextView) view;
		if ("C:::B".equals(text.getText())) {
			double value = (double) (System.currentTimeMillis() - beginTime) / 1000d;
			setTitle(String.format("CBTimer: %.3fs", value));
			text.setText(String.format("%.2f", value));
		} else { 
			beginTime = System.currentTimeMillis();
			text.setText("C:::B");
		}
	}
}
