package com.neadraw.charim;
import android.inputmethodservice.*;
import android.view.inputmethod.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.view.WindowManager.*;
import android.graphics.*;

public class IMEService extends InputMethodService
implements AdapterView.OnItemClickListener
{

	GridView board;

	@Override
	public void onCreate()
	{
		super.onCreate();
		board = (GridView) getLayoutInflater().inflate(R.xml.board, null);
		board.setAdapter(new MyAdapter(this));
		board.setOnItemClickListener(this);
		board.setBackgroundColor(0xfffffffe);
		LayoutParams params = new LayoutParams();
		params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_SPLIT_TOUCH | LayoutParams.FLAG_NOT_FOCUSABLE;
		params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;
		params.format = PixelFormat.TRANSPARENT;
		params.gravity = Gravity.LEFT + Gravity.BOTTOM;
		params.x = 0;
		params.y = 0;
		params.width = LayoutParams.MATCH_PARENT;
		float dp = getResources().getDisplayMetrics().density;
		params.height = (int) (240 * dp);
		getWindow().setContentView(board, params);
	}

	@Override
	public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
	{
		InputConnection con = getCurrentInputConnection();
		con.commitText(String.valueOf((char) p3), 0);
	}

	public static class MyAdapter extends BaseAdapter
	{

		Context context;
		@Override
		public Object getItem(int p1)
		{
			return null;
		}

		@Override
		public long getItemId(int p1)
		{
			return 0;
		}

		public MyAdapter (Context context)
		{
			this.context = context;
		}

		@Override
		public int getCount()
		{
			return Character.MAX_VALUE;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			TextView view = (TextView) convertView;
			if (view == null)
			{
				convertView = view = new TextView(context.getApplicationContext());
				view.setGravity(Gravity.CENTER);
				float dp = context.getResources().getDisplayMetrics().density;
				view.setMinHeight((int) (dp * 48));
				view.setTextColor(0xff212121);
				view.setTextSize(18);
			}
			view.setText(String.valueOf((char) position));
			return view;
		}
	}
}
