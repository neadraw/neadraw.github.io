package com.neadraw.charim;
 
import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity
{
} 