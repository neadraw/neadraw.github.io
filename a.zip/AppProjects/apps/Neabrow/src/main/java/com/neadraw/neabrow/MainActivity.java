package com.neadraw.neabrow;
import android.os.*;

public class MainActivity extends BrowserActivity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
	}
}
