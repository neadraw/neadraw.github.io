package com.neadraw.neabrow;
 
import android.app.*;
import android.os.*;
import java.util.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.*;

public class BrowserActivity extends Activity
{
	NeaWebView tab;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		if (NeaWebView.client == null) NeaWebView.client = new NeaWebView.Client();
		if (NeaWebView.chrome == null) NeaWebView.chrome = new NeaWebView.Chrome();
		tab = new NeaWebView(this);
		setContentView(tab);
		Intent it = getIntent();
		if (Intent.ACTION_VIEW.equals(it.getAction()))
		{
			tab.loadUrl(it.getDataString());
		}
	}

	@Override
	protected void onStart()
	{
		super.onStart();
		NeaWebView.client.webView = NeaWebView.chrome.webView = tab;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.edit_url:
				final EditText edit = new EditText(this);
				edit.setText(tab.getUrl());
				new AlertDialog.Builder(this).setTitle(R.string.edit_url).setView(edit).setNegativeButton(android.R.string.cancel, null)
					.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener () {
						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							tab.loadUrl(NeaWebView.converKeywordLoadOrSearch(edit.getText().toString()));
						}
					}).show();
				break;
			case R.id.manage_tab:
				Intent intent = new Intent(this, BrowserActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK + Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
				startActivity(intent);
				break;
			case R.id.finish_activity:
				finishAndRemoveTask();
				break;
			case R.id.reload:
				tab.reload();
				break;
			case R.id.go_forward:
				if (tab.canGoForward())
				{
					tab.goForward();
				}
				break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	@Override
	public void onBackPressed()
	{
		if (tab.canGoBack())
		{
			tab.goBack();
			return;
		}
		super.onBackPressed();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 0x33) {
			NeaWebView.chrome.onActivityResultFileChooser(requestCode, resultCode, data);
		}
	}
}
