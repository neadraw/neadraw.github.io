package com.neadraw.neabrow;
import android.webkit.*;
import android.content.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import android.os.*;
import android.app.*;
import android.webkit.WebChromeClient.*;
import android.net.*;
import android.text.*;
import android.graphics.*;
import android.view.*;

public class NeaWebView extends WebView implements DownloadListener
{
	public static Client client;
	public static Chrome chrome;
	public BrowserActivity main;

	public NeaWebView (BrowserActivity context)
	{
		super(context);
		main = context;
		setWebViewClient(client);
		setWebChromeClient(chrome);
		freeMemory();
		
		WebSettings settings = getSettings();
		settings.setAppCacheEnabled(true);
		settings.setDatabaseEnabled(true);
		settings.setJavaScriptEnabled(true);
		settings.setSavePassword(true);
		settings.setEnableSmoothTransition(true);
		settings.setAllowFileAccessFromFileURLs(true);
		settings.setDomStorageEnabled(true);
		settings.setLoadWithOverviewMode(true);
		settings.setUseWideViewPort(true);
		settings.setMediaPlaybackRequiresUserGesture(true);
		settings.setSafeBrowsingEnabled(true);
		settings.setAllowContentAccess(true);
		settings.setSupportMultipleWindows(true);
		settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
		settings.setRenderPriority(WebSettings.RenderPriority.HIGH);
		settings.setCacheMode(WebSettings.LOAD_DEFAULT);
		setDownloadListener(this);
	}

	public void onTab ()
	{
		main.setTitle(getTitle());
	}

	@Override
	public void onDownloadStart(final String url, String userAgent, String p3, String p4, long p5)
	{
		Context context = getContext();
		final EditText edit = new EditText(context);
		File dir = new File(Environment.getExternalStorageDirectory() + "/Download");
		dir.mkdirs();
		edit.setText(dir + url.substring(url.lastIndexOf("/")));
		new AlertDialog.Builder(context).setTitle(R.string.download)
			.setView(edit)
			.setNegativeButton(android.R.string.cancel, null)
			.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener () {
				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					new Thread () {
						public void run ()
						{
							try
							{
								InputStream in = new URL(url).openStream();
								OutputStream out = new FileOutputStream(edit.getText().toString());
								byte[] buffer = new byte[1024];
								int len;
								while ((len = in.read(buffer)) != - 1)
								{
									out.write(buffer, 0, len);
								}
								out.flush();
								out.close();
								in.close();
							}
							catch (Exception e)
							{
							}
						}
					}.start();
				}
			})
			.show();
	}

	public static class Client extends WebViewClient
	{

		public NeaWebView webView;

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url)
		{
			view.loadUrl(url);
			return super.shouldOverrideUrlLoading(view, url);
		}

		@Override
		public void onPageFinished(WebView view, String url)
		{
			super.onPageFinished(view, url);
			if (webView == view)
			{
				webView.onTab();
			}
		}
	}

	public static class Chrome extends WebChromeClient
	{

		public NeaWebView webView;

		@Override
		public void onProgressChanged(WebView view, int newProgress)
		{
			super.onProgressChanged(view, newProgress);
			if (webView != view) return;
			BrowserActivity main = webView.main;
			if (newProgress == 100)
			{
				main.setTitle(view.getTitle());
				return;
			}
			main.setTitle(newProgress + "% " + view.getTitle());
		}

		private ValueCallback<Uri[]> uploadFiles;

		@Override
		public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback,
										 FileChooserParams fileChooserParams)
		{
			uploadFiles = filePathCallback;
			Intent i = fileChooserParams.createIntent();
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
			webView.main.startActivityForResult(Intent.createChooser(i, "Image Chooser"), 0x33);
			return true;
		}

		public void onActivityResultFileChooser(int requestCode, int resultCode, Intent intent)
		{
			if (requestCode != 0x33 || uploadFiles == null)
				return;
			Uri[] results = null;
			if (resultCode == Activity.RESULT_OK)
			{
				if (intent != null)
				{
					String dataString = intent.getDataString();
					ClipData clipData = intent.getClipData();
					if (clipData != null)
					{
						results = new Uri[clipData.getItemCount()];
						for (int i = 0; i < clipData.getItemCount(); i++)
						{
							ClipData.Item item = clipData.getItemAt(i);
							results[i] = item.getUri();
						}
					}
					if (dataString != null)
						results = new Uri[]{Uri.parse(dataString)};
				}
			}
			uploadFiles.onReceiveValue(results);
			uploadFiles = null;
		}

	}

	public static String converKeywordLoadOrSearch(String keyword)
	{
		String HTTP = "http://", HTTPS ="https://", FILE ="file://";
		keyword = keyword.trim();
		if (keyword.startsWith("www.")) keyword = HTTP + keyword;
		else if (keyword.startsWith("ftp.")) keyword = "ftp://" + keyword;
		boolean containsPeriod = keyword.contains("."); boolean isIPAddress = (TextUtils.isDigitsOnly(keyword.replace(".", "")) && (keyword.replace(".", "").length() >= 4) && keyword.contains("."));
		boolean aboutScheme = keyword.contains("about:");
		boolean validURL = (keyword.startsWith("ftp://") || keyword.startsWith(HTTP) || keyword.startsWith(FILE) || keyword.startsWith(HTTPS)) || isIPAddress; boolean isSearch = ((keyword.contains(" ") || !containsPeriod) && !aboutScheme); if (isIPAddress && (!keyword.startsWith(HTTP) || !keyword.startsWith(HTTPS)))
		{
			keyword = HTTP + keyword;
		}
		String converUrl;
		if (isSearch)
		{
			try
			{
				keyword = URLEncoder.encode(keyword, "UTF-8");
			}
			catch (UnsupportedEncodingException e)
			{}
			converUrl = "http://www.baidu.com/s?wd=" + keyword + "&ie=UTF-8";
		}
		else if (!validURL) converUrl = HTTP + keyword;
		else converUrl = keyword;
		return converUrl;
	}

}
