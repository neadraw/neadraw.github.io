package com.neadraw.neachat;
 
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;

public class MainActivity extends Activity
{

	EditText editMessage;
	TextView listMessage;
	Neachat chat;
	SharedPreferences preference;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		preference = getSharedPreferences("db", MODE_PRIVATE);
		setContentView(R.layout.main);
		editMessage = findViewById(R.id.main_edit_message);
		listMessage = findViewById(R.id.main_list_message);
		chat = new Neachat();
		chat.context = this;
		chat.userName = preference.getString("user_name", "SB");
		chat.into(preference.getString("last_group", "NEACHAT"), false);
		new Handler().post(chat);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.edit_user_name:
				final EditText edit = new EditText(this);
				edit.setText(preference.getString("user_name", "SB"));
				new AlertDialog.Builder(this).setTitle(R.string.edit_user_name)
				.setView(edit)
				.setNegativeButton(android.R.string.cancel, null)
				.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener () {

					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						chat.userName = edit.getText().toString();
						preference.edit().putString("user_name", chat.userName).commit();
					}
				}).show();
				break;
			case R.id.create_group:
				final EditText edit2 = new EditText(this);
				new AlertDialog.Builder(this).setTitle(R.string.create_group)
					.setView(edit2)
					.setNegativeButton(android.R.string.cancel, null)
					.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener () {

						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							chat.create(edit2.getText().toString());
						}
					}).show();
				break;
			case R.id.about_show:
				new AlertDialog.Builder(this).setTitle("About")
				.setMessage("Developer:\n  Chen Jihao\nWebsite:\n  https://neadraw.github.io\nDatabase:\n  TextDB (https://textdb.online)")
				.setPositiveButton(android.R.string.cancel, null).show();
				break;
		}
		return super.onOptionsItemSelected(item);
	}

	public void sendMessage (View view)
	{
		EditText edit = editMessage;
		String str = edit.getText().toString();
		chat.send(str);
		edit.setText("");
	}

	public void intoGroup (View view)
	{
		EditText edit = editMessage;
		String str = edit.getText().toString();
		chat.into(str);
		edit.setText("");
	}
}
