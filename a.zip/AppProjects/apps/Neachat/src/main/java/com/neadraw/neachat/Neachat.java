package com.neadraw.neachat;
import android.widget.*;
import android.os.*;
import java.net.*;
import java.io.*;

public class Neachat implements Runnable
{
	public static final String READ_URL = "https://textdb.online/neachat(", WRITE_URL = "https://api.textdb.online/update/?key=neachat(";
	public String group, message, userName;
	public boolean shouldReload;
	public MainActivity context;

	public Neachat ()
	{
		new Thread ()
		{
			@Override
			public void run ()
			{
				try
				{
					if (group != null) {
						String messagesData = readMessage(group);
						if (! messagesData.equals(message))
						{
							message = messagesData;
							shouldReload = true;
						}
					}
				}
				catch (Exception e)
				{} 
				try
				{
					run();
				}
				catch (Exception e)
				{}
			}
		}.start();
	}

	public void into (String name, boolean save)
	{
		group = name;
		context.setTitle(name);
		if (save) context.preference.edit().putString("last_group", name).commit();
	}

	public void into (String name)
	{
		into(name, true);
	}

	public void create (final String name)
	{
		new Thread()
		{
			public void run ()
			{
				try
				{
					writeMessage(name, "{{{}}}");
					into(name);
				}
				catch (Exception e)
				{}
			}
		}.start();
	}

	public void send (final String message)
	{
		if (group == null) return;
		new Thread()
		{
			public void run ()
			{
				try
				{
					writeMessage(group, readMessage(group) + String.format("\n\n%s:\n", userName) + message + "\n");
				} catch (Exception e) {}
			}
		}.start();
	}

	public void reload ()
	{
		context.listMessage.setText(message);
		shouldReload = false;
	}

	@Override
	public void run ()
	{
		synchronized (this)
		{
			try
			{
				if (group != null) 
				{
					if (shouldReload)
					{
						reload();
					}
				}
			}
			catch (Exception e)
			{}
			new Handler().postDelayed(this, 20);
		}
	}

	public static String readURL (String url) throws Exception
	{
		URL u = new URL(url);
		BufferedReader reader = new BufferedReader(new InputStreamReader(u.openStream()));
		String line;
		StringBuilder str = new StringBuilder();
		while ((line = reader.readLine()) != null)
		{
			str.append("\n");
			str.append(line);
		}
		if (str.length() > 0)
		{
			str.delete(0, 1);
		}
		reader.close();
		return str.toString();
	}
	public static String readMessage (String key) throws Exception
	{
		return readURL(READ_URL + URLEncoder.encode(key, "UTF-8"));
	}

	public static void writeMessage (String key, String value) throws Exception
	{
		new URL(WRITE_URL + URLEncoder.encode(key, "UTF-8") + "&value=" + URLEncoder.encode(value, "UTF-8")).openStream().close();
	}
}
