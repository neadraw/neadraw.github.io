package com.csqnew.pixmapmaker.widget;
import android.widget.*;
import android.content.*;
import android.util.*;
import android.view.*;
import com.csqnew.pixmapmaker.*;

public class MainLayout extends LinearLayout {

    public MainLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MainLayout(Context context) {
		this(context, null);
	}

	@Override
	protected void onMeasure (int widthMeasureSpec, int heightMeasureSpec) {
		View child = getChildAt(0);
		LayoutParams params = (LinearLayout.LayoutParams) child.getLayoutParams();
		int dp = (int) getResources().getDimension(R.dimen.dp);
		if (widthMeasureSpec < heightMeasureSpec) {
			setOrientation(VERTICAL);
			params.width = LayoutParams.MATCH_PARENT;
			params.height = LayoutParams.WRAP_CONTENT;
			child.setElevation(dp * 4);
		} else {
			setOrientation(HORIZONTAL);
			params.width = LayoutParams.WRAP_CONTENT;
			params.height = LayoutParams.MATCH_PARENT;
			child.setElevation(dp * 24);
		}
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}
}
