package com.csqnew.pixmapmaker.moreutil;
import android.graphics.*;
import android.view.*;

public class Bucket implements DrawingUtil {

	@Override
	public void onDraw(Canvas canvas) {
	}

	@Override
	public void callPixel(int x, int y) {
	}

	@Override
	public void onTouch(MotionEvent event) {
	}
}
