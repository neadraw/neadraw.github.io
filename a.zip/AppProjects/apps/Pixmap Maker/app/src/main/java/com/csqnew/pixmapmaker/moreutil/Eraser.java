package com.csqnew.pixmapmaker.moreutil;
import android.graphics.*;
import android.view.*;

public class Eraser extends PaintUtil {

	@Override
	public void callPixel (int x, int y) {
		callPixel(x, y, 0);
	}
}
