package com.csqnew.pixmapmaker.moreutil;
import android.graphics.*;
import com.csqnew.pixmapmaker.*;
import android.view.*;

public interface DrawingUtil {

	public PixmapView pixmap;

	public void onDraw(Canvas canvas)

	public void callPixel(int x, int y)

	public void onTouch(MotionEvent event)
}
