package com.csqnew.pixmapmaker;
import android.view.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.content.*;
import android.util.*;
import android.widget.*;
import java.io.*;
import com.csqnew.pixmapmaker.moreutil.*;

public class PixmapView extends View {

	public MainActivity main;
	public Bitmap map;
	public Canvas canvas;
	public Paint paint;
	public float x, y, size, scale;
	public int color = 0xffff4481, drawType;
	public DrawingUtil[] utils;
	public DrawingUtil util;

	public PixmapView (Context context, AttributeSet attrs) {
		super(context, attrs);
		this.main = (MainActivity) context;
		setLongClickable(true);
		paint = new Paint();
		setBitmap(Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888));
		utils = new DrawingUtil[] {new ReposUtil(), new PaintUtil(), new Eraser()};
		util = utils[0];
	}

	public PixmapView (Context context) {
		this(context, null);
	}

	@Override
	protected void onDraw (Canvas canvas) {
		this.canvas = canvas;
		setSize(size);
		paint.setColor(0xffaaaaaa);
		canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), paint);
		if (map != null) {
			Rect src = new Rect(0, 0, map.getWidth(), map.getHeight());
			RectF dst = new RectF(x, y, x + map.getWidth() * scale, y + map.getHeight() * scale);
			paint.setColor(- 1);
			canvas.drawRect(dst, paint);
			canvas.drawBitmap(map, src, dst, paint);
		}
		util.pixmap = this;
		util.onDraw(canvas);
	}

	@Override
	public boolean onTouchEvent (MotionEvent event) {
		float touchedX = event.getX(), touchedY = event.getY();
		int action = event.getAction();
		try {
			Bitmap map = this.map;
			util.pixmap = this;
			util.onTouch(event);
			if (action == MotionEvent.ACTION_DOWN) {
			} else if (action == MotionEvent.ACTION_MOVE) {
				float x = (touchedX - this.x) / scale, y = (touchedY - this.y) / scale;
				if (x >= 0 && x < map.getWidth() && y >= 0 && y < map.getHeight()) {
					callPixel((int) x, (int) y);
					if (lastPixelX != -1 && lastPixelY != - 1) {
						float xSpeed = 0, ySpeed = 0;
						float xx = x - lastPixelX, yy = y - lastPixelY;
						float distance = (float) Math.sqrt(xx * xx + yy * yy);
						xSpeed = xx / distance;
						ySpeed = yy / distance;
						for (float dx = lastPixelX, dy = lastPixelY; (x > lastPixelX ? dx < x : dx > x) || (y > lastPixelY ? dy < y : dy > y); dx += xSpeed, dy += ySpeed) {
							if (dx >= 0 && dx < map.getWidth() && dy >= 0 && dy < map.getHeight()) {
								callPixel((int) dx, (int) dy);
							}
						}
					}
					lastPixelX = x;
					lastPixelY = y;
				}
			} else if (action == MotionEvent.ACTION_UP) {
				lastPixelX = - 1;
				lastPixelY = - 1;
			}
			invalidate();
		} catch (Exception e) {
			try {
				e.printStackTrace(new PrintStream(new FileOutputStream("/sdcard/exce.txt")));
			} catch (Exception e2) {}
		}
		return super.onTouchEvent(event);
	}

	float lastPixelX = - 1, lastPixelY = - 1;

	void callPixel (int x, int y) {
		util.pixmap = this;
		util.callPixel(x, y);
	}

	void setPosition (float x, float y) {
		this.x = x;
		this.y = y;
	}

	void setBitmap (Bitmap map) {
		this.map = map.copy(Bitmap.Config.ARGB_8888, true);
		size = map.getWidth();
	}

	void setSize (float size) {
		float min = Math.min(canvas.getWidth(), canvas.getHeight());
		scale = min / size;
	}
}
