package com.csqnew.pixmapmaker.moreutil;
import android.graphics.*;
import android.view.*;
import com.csqnew.pixmapmaker.*;

public class PaintUtil implements DrawingUtil {

	@Override
	public void onDraw (Canvas canvas) {
	}

	@Override
	public void callPixel (int x, int y) {
		callPixel(x, y, pixmap.color);
	}

	public void callPixel (int x, int y, int color) {
		PixmapView pixmap = this.pixmap;
		pixmap.map.setPixel(x, y, color);
	}

	@Override
	public void onTouch (MotionEvent event) {
	}
}
