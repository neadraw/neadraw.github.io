package com.csqnew.pixmapmaker.moreutil;
import android.graphics.*;
import android.view.*;
import com.csqnew.pixmapmaker.*;

public class ReposUtil implements DrawingUtil {

	@Override
	public void onDraw(Canvas canvas) {
	}

	@Override
	public void callPixel(int x, int y) {
	}

	boolean isMove;
	float lastX, lastY, lastDistance;

	@Override
	public void onTouch(MotionEvent event) {
		float touchedX = event.getX(), touchedY = event.getY();
		int action = event.getAction();
		PixmapView pixmap = this.pixmap;
		if (action == MotionEvent.ACTION_DOWN) {
			lastX = touchedX;
			lastY = touchedY;
			isMove = true;
		} else if (action == MotionEvent.ACTION_MOVE) {
			if (event.getPointerCount() > 1) {
				float touchedX2 = event.getX(1), touchedY2 = event.getY(1);
				float xx = touchedX2 - touchedX, yy = touchedY2 - touchedY;
				float distance = (float) Math.sqrt(xx * xx + yy * yy);
				if (isMove) {
					isMove = false;
					lastX = ((touchedX + touchedX2) / 2f - pixmap.x) / pixmap.scale;
					lastY = ((touchedY + touchedY2) / 2f - pixmap.y) / pixmap.scale;
				} else {
					float shouldX = (touchedX + touchedX2) / 2f;
					float shouldY = (touchedY + touchedY2) / 2f;
					pixmap.size /= distance / lastDistance;
					pixmap.x = shouldX - lastX * pixmap.scale;
					pixmap.y = shouldY - lastY * pixmap.scale;
				}
				lastDistance = distance;
			} else {
				if (isMove) {
					pixmap.x += touchedX - lastX;
					pixmap.y += touchedY - lastY;
				}
			}
			if (isMove) {
				lastX = touchedX;
				lastY = touchedY;
			}
		} else if (action == MotionEvent.ACTION_UP) {
			isMove = true;
		}
	}
}
