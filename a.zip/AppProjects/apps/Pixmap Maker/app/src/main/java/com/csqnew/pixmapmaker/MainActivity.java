package com.csqnew.pixmapmaker;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.graphics.*;
import android.view.*;
import android.content.res.*;
import android.content.*;
import java.io.*;
import android.text.*;
import android.provider.*;
import com.csqnew.pixmapmaker.moreutil.*;

public class MainActivity extends Activity
implements RadioGroup.OnCheckedChangeListener {

	PixmapView pixmap;

	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		pixmap = findViewById(R.id.activity_main_pixmap);
		this.<RadioGroup> findViewById(R.id.activity_main_radios_drawing).setOnCheckedChangeListener(this);
		checkScreenOrientation(null);
		setColor(0xff000000);
	}

	void setColor (int color) {
		pixmap.color = color;
		findViewById(R.id.activity_main_color_view).setBackgroundTintList(ColorStateList.valueOf(color));
	}

	public void checkScreenOrientation (View view) {
		setRequestedOrientation(getRequestedOrientation() == LinearLayout.VERTICAL ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
	}

	public void setColor (View view) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(R.string.color);
		final LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.dialog_color_option, null);
		final EditText edit = (EditText) layout.getChildAt(0);
		String hexString = Integer.toHexString(pixmap.color);
		edit.setText("00000000".substring(0, 8 - hexString.length()) + hexString);
		builder.setView(layout);
		builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick (DialogInterface p1, int p2) {
					setColor(Color.parseColor("#" + edit.getText()));
				}
			});
		builder.setNegativeButton(R.string.cancel, null);
		builder.show();
	}

	public void save (View view) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(R.string.save);
		final LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.dialog_save_bitmap, null);
		final SeekBar bar = layout.findViewById(R.id.dialog_save_bitmap_seek_scale);
		final TextView textScale = layout.findViewById(R.id.dialog_save_bitmap_text_scale);
		textScale.setText(getString(R.string.bitmap_scale, 1));
		bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

				@Override
				public void onProgressChanged (SeekBar p1, int p2, boolean p3) {
					textScale.setText(getString(R.string.bitmap_scale, p2 + 1));
				}

				@Override
				public void onStartTrackingTouch (SeekBar p1) {
				}

				@Override
				public void onStopTrackingTouch (SeekBar p1) {
				}
			});
		builder.setView(layout);
		builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick (DialogInterface p1, int p2) {
					EditText edit = (EditText) layout.getChildAt(0);
					String path = Environment.getExternalStorageDirectory() + "/New/pixmapmaker/";
					new File(path).mkdirs();
					path += edit.getText().toString();
					final RadioGroup types = layout.findViewById(R.id.dialog_save_bitmap_file_type);
					Bitmap map = pixmap.map;
					final int scale = bar.getProgress() + 1;
					final Bitmap rawMap = map;
					final String mPath = path;
					final Bitmap mMap = map;
					final ProgressDialog savingDialog = new ProgressDialog(MainActivity.this);
					savingDialog.setTitle(R.string.saving);
					savingDialog.setMessage(mPath);
					savingDialog.show();
					new Thread() {
						public void run () {
							try {
								Bitmap map = mMap;
								if (scale > 1) {
									map = Bitmap.createBitmap(scale * map.getWidth(), scale * map.getHeight(), Bitmap.Config.ARGB_8888);
									int[] pixels = new int[scale * scale];
									for (int x = 0; x < rawMap.getWidth(); x ++) {
										for (int y = 0; y < rawMap.getHeight(); y ++) {
											int color = rawMap.getPixel(x, y);
											for (int i = 0; i < pixels.length; i ++) {
												pixels[i] = color;
											}
											map.setPixels(pixels, 0, scale, x * scale, y * scale, scale, scale);
										}
									}
								}
								String path = mPath;
								switch (types.getCheckedRadioButtonId()) {
									default:case R.id.dialog_save_bitmap_file_type_png:
										File file = new File(path + ".png");
										file.createNewFile();
										OutputStream out = new FileOutputStream(file);
										map.compress(Bitmap.CompressFormat.PNG, 1, out);
										out.flush();
										out.close();
										break;
									case R.id.dialog_save_bitmap_file_type_jpeg:
										file = new File(path + ".jpeg");
										file.createNewFile();
										out = new FileOutputStream(file);
										map.compress(Bitmap.CompressFormat.JPEG, 1, out);
										out.flush();
										out.close();
								}
								savingDialog.dismiss();
							} catch (Exception e) {
								savingDialog.dismiss();
							}
						}
					}.start();
				}
			});
		builder.setNegativeButton(R.string.cancel, null);
		builder.show();
	}

	public void createNew (View view) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(R.string.create);
		final LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.dialog_create_bitmap, null);
		builder.setView(layout);
		builder.setNegativeButton(R.string.cancel, null);
		builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick (DialogInterface p1, int p2) {
					EditText editWidth = layout.findViewById(R.id.dialog_create_bitmap_width);
					EditText editHeight = layout.findViewById(R.id.dialog_create_bitmap_height);
					try {
						Bitmap map = Bitmap.createBitmap(Integer.parseInt(editWidth.getText().toString()), Integer.parseInt(editHeight.getText().toString()), Bitmap.Config.ARGB_8888);
						pixmap.setBitmap(map);
						pixmap.invalidate();
					} catch (Exception e) {}
				}
			});
		builder.show();
	}

	public void open (View view) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(R.string.open);
		LinearLayout layout = (LinearLayout) getLayoutInflater().inflate(R.layout.dialog_open_bitmap, null);
		final EditText editPath = (EditText) layout.getChildAt(0);
		builder.setView(layout);
		builder.setNegativeButton(R.string.cancel, null);
		builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick (DialogInterface p1, int p2) {
					pixmap.setBitmap(BitmapFactory.decodeFile(editPath.getText().toString()));
				}
			});
		builder.show();
	}

	public void resetMatrix(View view) {
		PixmapView pixmap = this.pixmap;
		pixmap.x = 0;
		pixmap.y = 0;
		pixmap.size = pixmap.map.getWidth();
		pixmap.invalidate();
	}

	@Override
	public void onCheckedChanged (RadioGroup p1, int p2) {
		DrawingUtil[] utils = pixmap.utils;
		switch (p2) {
			case R.id.activity_main_drawing_repos:
				pixmap.util = utils[0];
				break;
			case R.id.activity_main_drawing_paint:
				pixmap.util = utils[1];
				break;
			case R.id.activity_main_drawing_eraser:
				pixmap.util = utils[2];
				break;
			case R.id.activity_main_drawing_more_util:
				pixmap.drawType = 3;
		}
	}
}
