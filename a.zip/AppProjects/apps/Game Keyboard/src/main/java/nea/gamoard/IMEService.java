package nea.gamoard;
import android.inputmethodservice.*;

public class IMEService extends InputMethodService
{
	
}
