package nea.gamoard;
 
import android.app.*;
import android.os.*;
import android.content.*;

public class MainActivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
	}
}
