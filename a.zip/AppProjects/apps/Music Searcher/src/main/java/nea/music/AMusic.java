package nea.music;
import java.io.*;

public class AMusic implements Serializable
{
	public String title, url, pic, author, lrc;
}
