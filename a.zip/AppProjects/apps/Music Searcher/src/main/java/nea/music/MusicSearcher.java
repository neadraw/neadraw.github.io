package nea.music;
import java.net.*;
import java.io.*;
import org.json.*;
import java.util.*;

public class MusicSearcher
{

	public int page;
	public String type, input;
	public AMusic[] musicList = {};

	public MusicSearcher (String type)
	{
		this.type = type;
	}

	public synchronized void search (String input) throws Exception
	{
		this.input = input;
		setPage(1);
	}

	public synchronized void setPage (int page) throws Exception
	{
		this.page = page;
		JSONArray data = readJSON(input, page, type);
		musicList = new AMusic[data.length()];
		for (int i = 0; i < data.length(); i ++)
		{
			try
			{
				JSONObject musicObject = data.getJSONObject(i);
				AMusic music = new AMusic();
				musicList[i] = music;
				music.title = musicObject.getString("title");
				music.author = musicObject.getString("author");
				music.url = musicObject.getString("url");
				music.pic = musicObject.getString("pic");
				music.lrc = musicObject.getString("lrc");
			} catch (Exception e) {}
		}
	}

	public synchronized void goLastPage () throws Exception
	{
		int page = this.page;
		if (page == 1) return;
		setPage(page - 1);
	}

	public synchronized void goNextPage () throws Exception
	{
		int page = this.page;
		setPage(page + 1);
	}

	public static JSONArray readJSON (String input, int page, String type) throws Exception
	{
		HttpURLConnection connection = (HttpURLConnection) new URL("http://xmsj.org").openConnection();
		connection.setRequestMethod("POST");
		connection.addRequestProperty("X-Requested-With", "XMLHttpRequest");
		connection.setDoOutput(true);
		OutputStream outputStream = connection.getOutputStream();
		outputStream.write(String.format("filter=name&type=%s&page=%s&input=%s", type, page, URLEncoder.encode(input, "UTF-8")).getBytes("UTF-8"));
		outputStream.flush();
		outputStream.close();
		InputStream in = connection.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		String line = reader.readLine();
		reader.close();
		JSONObject jsonObject = new JSONObject(line);
		return jsonObject.getJSONArray("data");
	}
}
