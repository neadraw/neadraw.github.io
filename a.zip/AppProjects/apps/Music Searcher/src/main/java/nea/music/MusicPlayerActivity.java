package nea.music;

import android.app.*;
import android.os.*;
import android.media.*;
import java.io.*;
import java.net.*;
import android.widget.*;
import android.webkit.*;
import java.util.*;

public class MusicPlayerActivity extends Activity
implements DownloadListener, Runnable
{

	public AMusic music;
	public WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		setContentView(webView = new WebView(this));
		music = (AMusic) getIntent().getExtras().getSerializable("music");
		WebSettings settings = webView.getSettings();
		webView.setWebChromeClient(new WebChromeClient());
		settings.setJavaScriptEnabled(true);
		//settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
		webView.loadUrl("file:///android_asset/music_player.html?" + music.url + '|' + music.pic + '|' + music.title + '|' + music.author + '|' + music.lrc);
		webView.setDownloadListener(this);
    }

	@Override
	public void onDownloadStart(String url, String p2, String p3, String p4, long p5)
	{
		new Thread(this).start();
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		webView.destroy();
	}

	@Override
	public void run()
	{
		try
		{
			File dir = new File(Environment.getExternalStorageDirectory() + "/Download");
			dir.mkdirs();
			InputStream in = new URL(music.url).openStream();
			OutputStream out = new FileOutputStream(dir.getPath() + '/' + music.title + ".mp3");
			byte[] buffer = new byte[1024];
			int len;
			while ((len = in.read(buffer)) != - 1)
			{
				out.write(buffer, 0, len);
			}
			out.flush();
			out.close();
			in.close();
		}
		catch (Exception e)
		{
		}
	}
}
