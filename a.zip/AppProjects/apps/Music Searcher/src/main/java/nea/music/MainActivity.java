package nea.music;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import java.lang.reflect.*;

public class MainActivity extends Activity
implements RadioGroup.OnCheckedChangeListener, DialogInterface.OnClickListener, AdapterView.OnItemClickListener
{

	public MusicSearcher searcher;
	public EditText editMusicContent;
	public ListView listMusicView;
	public AlertDialog musicListDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		searcher = new MusicSearcher("netease");
		setContentView(R.layout.main);
		editMusicContent = findViewById(R.id.edit_music_content);
		RadioGroup chooseAPIRadios = findViewById(R.id.choose_api);
		chooseAPIRadios.setOnCheckedChangeListener(this);
		listMusicView = new ListView(this);
		listMusicView.setOnItemClickListener(this);
		musicListDialog = new AlertDialog.Builder(this).
			setCancelable(false).
			setNeutralButton(android.R.string.cancel, this).
			setNegativeButton(R.string.last_page, this).
			setPositiveButton(R.string.next_page, this).create();
		musicListDialog.setCancelable(false);
		musicListDialog.setCanceledOnTouchOutside(false);
		musicListDialog.setView(listMusicView);
		chooseAPIRadios.check(R.id.api_netease);
	}

	public void searchGo (View view)
	{
		new SearchingThread(this, 0).start();
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int id)
	{
		String apiType = "netease";
		switch (id)
		{
			case R.id.api_netease:
				apiType = "netease";
				break;
			case R.id.api_migu:
				apiType = "migu";
				break;
			case R.id.api_lizhi:
				apiType = "lizhi";
				break;
		}
		searcher.type = apiType;
	}

	public void showMusicListDialog ()
	{
		musicListDialog.show();
	}

	public void onFinishPage ()
	{
		listMusicView.setAdapter(new MusicAdapter(this));
		musicListDialog.setTitle(editMusicContent.getText().toString());
		musicListDialog.invalidateOptionsMenu();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		AMusic music = searcher.musicList[position];
		if (music == null) return;
		Intent intent = new Intent(this, MusicPlayerActivity.class);
		intent.putExtra("music", music);
		startActivity(intent);
	}

	@Override
	public void onClick(DialogInterface face, int id)
	{
		boolean cancel = false;
		switch (id)
		{
			case -3:
				cancel = true;
				listMusicView.setAdapter(null);
				break;
			case -2:
				new SearchingThread(this, - 1).start();
				break;
			case -1:
				new SearchingThread(this, 1).start();
				break;
		}
		try
		{ 
			Field field = musicListDialog.getClass().getSuperclass().getDeclaredField("mShowing"); 
			field.setAccessible(true); 
			field.setBoolean(musicListDialog, cancel);
		}
		catch (Exception e)
		{}
	}

	public static class MusicAdapter extends ArrayAdapter<AMusic>
	{
		public MusicAdapter (MainActivity activity)
		{
			super (activity, android.R.layout.simple_list_item_1, activity.searcher.musicList);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			AMusic music = getItem(position);
			TextView view = (TextView) super.getView(position, convertView, parent);
			if (music != null) view.setText('\n' + music.title + "\n> " + music.author + '\n');
			return view;
		}
	}
}
