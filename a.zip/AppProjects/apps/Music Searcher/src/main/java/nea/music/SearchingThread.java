package nea.music;
import android.os.*;
import android.widget.*;
import android.app.*;

public class SearchingThread extends Thread
{

	public MainActivity activity;
	public int type;
	public String content;
	public Handler handler;

	public SearchingThread (MainActivity activity, int type)
	{
		this.activity = activity;
		this.type = type;
		handler = new MHandler();
	}

	@Override
	public void run()
	{
		MusicSearcher searcher = activity.searcher;
		try
		{
			switch (type)
			{
				case 0:
					searcher.search(content);
					break;
				case 1:
					searcher.goNextPage();
					break;
				case - 1:
					searcher.goLastPage();
					break;
			}
			
		}
		catch (Exception e)
		{
		}
		Message msg = Message.obtain();
		msg.obj = activity;
		handler.sendMessage(msg);
	}

	@Override
	public void start()
	{
		content = activity.editMusicContent.getText().toString();
		AlertDialog dialog = activity.musicListDialog;
		dialog.setTitle(R.string.loading);
		/*ProgressBar bar = new ProgressBar(activity);
		float dp = activity.getResources().getDisplayMetrics().density;
		bar.setLayoutParams(new LinearLayout.LayoutParams((int) (dp * 48), (int) (dp * 48)));
		dialog.setView(bar);*/
		if (type == 0)
		{
			activity.showMusicListDialog();
		}
		super.start();
	}

	public static class MHandler extends Handler
	{

		@Override
		public void handleMessage(Message msg)
		{
			super.handleMessage(msg);
			MainActivity activity = (MainActivity) msg.obj;
			activity.onFinishPage();
		}
	}
}
