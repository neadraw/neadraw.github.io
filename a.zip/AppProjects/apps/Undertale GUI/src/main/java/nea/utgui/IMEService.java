package nea.utgui;
import android.inputmethodservice.*;
import android.view.*;
import java.util.*;
import android.view.WindowManager.*;
import android.graphics.*;
import android.widget.*;
import android.view.inputmethod.*;
import java.io.*;
import static java.lang.Math.*;
import android.text.*;

public class IMEService extends InputMethodService
{

    static IMEService self;
	WindowManager windowManager;
	boolean isShowing;
	Touchpad padMove, padMenu;

	@Override
	public void onCreate()
	{
		super.onCreate();
		self = this;
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
		padMove = new Touchpad(true);
		padMove.setLayoutParams(newLayoutParams(48, 48, 128, 128, Gravity.LEFT + Gravity.BOTTOM));
		padMenu = new Touchpad(false);
		padMenu.setLayoutParams(newLayoutParams(48, 48, 128, 128, Gravity.RIGHT + Gravity.BOTTOM));
		showViews();
	}

	@Override
	public void onDestroy()
	{
		super.onDestroy();
		hideViews();
	}

	public void showViews ()
	{
		if (isShowing) return;
		windowManager.addView(padMove, padMove.getLayoutParams());
		windowManager.addView(padMenu, padMenu.getLayoutParams());
		isShowing = true;
	}

	public void hideViews ()
	{
		if (!isShowing) return;
		windowManager.removeView(padMove);
		windowManager.removeView(padMenu);
		isShowing = false;
	}

	public LayoutParams newLayoutParams (float x, float y, float width, float height, int gravity)
	{
		LayoutParams params = new LayoutParams();
		params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_SPLIT_TOUCH | LayoutParams.FLAG_NOT_FOCUSABLE;
		params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;
		params.format = PixelFormat.TRANSPARENT;
		float dp = getResources().getDisplayMetrics().density;
		params.gravity = gravity;
		params.x = (int) (x * dp);
		params.y = (int) (y * dp);
		params.width = (int) (width * dp);
		params.height = (int) (height * dp);
		return params;
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event)
	{
		if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
		{
			if(isShowing)
				hideViews();
			else
				showViews();
		}
		return super.onKeyDown(keyCode, event);
	}

}

class Touchpad extends View
{
	static Bitmap bitmap;
	final static int[][] keys = {
		{KeyEvent.KEYCODE_DPAD_UP},
		{KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_LEFT},
		{KeyEvent.KEYCODE_DPAD_LEFT},
		{KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT},
		{KeyEvent.KEYCODE_DPAD_DOWN},
		{KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT},
		{KeyEvent.KEYCODE_DPAD_RIGHT},
		{KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_RIGHT}
	};
	boolean isMoveTouchpad;
	int lastCommand;

	public Touchpad (boolean isMove)
	{
		super (IMEService.self);
		isMoveTouchpad = isMove;
		try
		{
			if (bitmap != null) throw new Exception();
			InputStream in = getContext().getAssets().open("pad.png");
			bitmap = BitmapFactory.decodeStream(in);
			in.close();
		}
		catch (Exception e)
		{}
		setLongClickable(true);
		setBackgroundColor(0xffff4481);
		setAlpha(0.6f);
		setElevation(8 * getResources().getDisplayMetrics().density);
	}

	float centerX, centerY;

	@Override
	protected void onDraw(Canvas canvas)
	{
		super.onDraw(canvas);
		Paint paint = new Paint();
		float width = canvas.getWidth(), height = canvas.getHeight();
		if (isMoveTouchpad)
		{
			Rect src = new Rect(0, 0, 16, 16);
			RectF dst = new RectF(0, 0, width, height);
			canvas.drawBitmap(bitmap, src, dst, paint);
		}
		else
		{
			TextPaint text = new TextPaint();
			text.setColor(0xfffffffc);
			text.setTextAlign(Paint.Align.CENTER);
			text.setTextSize(height / 2);
			float translateY = height / 6;
			canvas.drawText("Z", width / 4, height / 4 + translateY, text);
			canvas.drawText("X", width / 4, height / 4 * 3 + translateY, text);
			canvas.drawText("C", width / 4 * 3, height / 4 * 3 + translateY, text);
		}
		centerX = width / 2;
		centerY = height / 2;
	}

	
	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		int action = event.getAction();
		float x = event.getX(), y = event.getY();
		IMEService ime = IMEService.self;
		InputConnection inputer = ime.getCurrentInputConnection();
		if (isMoveTouchpad)
		{
			double angle = (atan2(x - centerX, y - centerY) * 180 / PI + 202.5) % 360;
			int input =  (int) (angle / 45d);
			switch (action)
			{
				case MotionEvent.ACTION_DOWN:
					lastCommand = input;
					sendKeyEvents(inputer, KeyEvent.ACTION_DOWN, input);
					break;
				case MotionEvent.ACTION_MOVE:
					if (input != lastCommand)
					{
						sendKeyEvents(inputer, KeyEvent.ACTION_UP, lastCommand);
						sendKeyEvents(inputer, KeyEvent.ACTION_DOWN, input);
					}
					lastCommand = input;
					break;
				case MotionEvent.ACTION_UP:
					sendKeyEvents(inputer, KeyEvent.ACTION_UP, lastCommand);
					//Toast.makeText(getContext(), String.valueOf(input), Toast.LENGTH_SHORT).show();
					break;
			}
		}
		else
		{
			int key = 0;
			if (x >= centerX && y > centerY)
			{
				key = 17;
			}
			else if  (x < centerX && y <= centerY)
			{
				key = KeyEvent.KEYCODE_6;
			}
			else if (x >= centerX && y < centerY)
			{
				if (action == MotionEvent.ACTION_UP)
				{
					//ime.getSystemService(InputMethodManager.class).showInputMethodPicker();
				}
				return false;
			}
			else if (x < centerX && y >= centerY)
			{
				key = KeyEvent.KEYCODE_9;
			}
			switch (action)
			{
				case MotionEvent.ACTION_DOWN:
					inputer.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, key));
					break;
				case MotionEvent.ACTION_MOVE:
					if (key != lastCommand)
					{
						inputer.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, lastCommand));
						inputer.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, key));
					}
					break;
				case MotionEvent.ACTION_UP:
					inputer.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, lastCommand));
					break;
			}
			lastCommand = key;
		}
		return super.onTouchEvent(event);
	}

	static void sendKeyEvents (InputConnection inputer, int action, int input)
	{
		for (int key: keys[input])
		{
			inputer.sendKeyEvent(new KeyEvent(action, key));
		}
	}
}
