package nea.m18nat;
import android.app.*;
import android.os.*;
import android.content.*;
import android.widget.*;
import android.view.*;
import android.view.WindowManager.*;
import android.graphics.*;
import java.lang.reflect.*;
import android.graphics.drawable.*;
import java.util.*;

public class NatService extends Service
implements View.OnTouchListener, View.OnClickListener, PopupMenu.OnMenuItemClickListener
{

	WindowManager windowManager;
	Button popupButton;
	PopupMenu menu;

	@Override
	public void onCreate()
	{
		super.onCreate();
		
		float dp = getResources().getDisplayMetrics().density;
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
		popupButton = new Button(this);
		popupButton.setTextColor(0xff212121);
		GradientDrawable background = new GradientDrawable();
		background.setColor(0xfffffffd);
		background.setCornerRadius(2 * dp);
		popupButton.setBackground(background);
		popupButton.setElevation(dp * 4);
		popupButton.setText("N");
		popupButton.setOnTouchListener(this);
		popupButton.setLayoutParams(newLayoutParams(0, 0, 36, 36, Gravity.LEFT + Gravity.TOP));
		popupButton.setOnClickListener(this);
		windowManager.addView(popupButton, popupButton.getLayoutParams());
		menu = new PopupMenu(this, popupButton);
		menu.inflate(R.menu.menu);
		menu.setOnMenuItemClickListener(this);
	}

	@Override
	public void onDestroy()
	{
		super.onDestroy();
		windowManager.removeView(popupButton);
	}

	@Override
	public boolean onMenuItemClick(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.close_menu:
				menu.dismiss();
				break;
			case R.id.system_settings:
				startActivity(getPackageManager().getLaunchIntentForPackage("com.android.settings"));
				break;
			case R.id.light:
				startActivity(new Intent().setClassName("com.android.systemui", "com.android.systemui.settings.BrightnessDialog"));
				break;
			case R.id.power:
				startActivity(new Intent().setClassName("com.android.settings", "com.android.settings.fuelgauge.PowerUsageSummary"));
				break;
		}
		return false;
	}

	float lastTouchedX, lastTouchedY;
	@Override
	public boolean onTouch(View view, MotionEvent event)
	{
		float touchedX = event.getRawX(), touchedY = event.getRawY();
		switch (event.getAction())
		{
			case MotionEvent.ACTION_DOWN:
				lastTouchedX = touchedX;
				lastTouchedY = touchedY;
				break;
			case MotionEvent.ACTION_MOVE:
				LayoutParams params = (WindowManager.LayoutParams) popupButton.getLayoutParams();
				params.x += touchedX - lastTouchedX;
				params.y += touchedY - lastTouchedY;
				lastTouchedX = touchedX;
				lastTouchedY = touchedY;
				windowManager.updateViewLayout(popupButton, popupButton.getLayoutParams());
				break;
			case MotionEvent.ACTION_UP:
				break;
		}
		return false;
	}

	@Override
	public void onClick(View view)
	{
		menu.getMenu().getItem(2).setTitle("电量 " + getBattery(this) + "%");
		Calendar calendar = Calendar.getInstance();
		menu.getMenu().getItem(3).setTitle("时间 " + calendar.get(Calendar.HOUR) + ":" + calendar.get((Calendar.MINUTE)));
		menu.show();
	}

	@Override
	public IBinder onBind(Intent p1)
	{
		return null;
	}

	public LayoutParams newLayoutParams (float x, float y, float width, float height, int gravity)
	{
		LayoutParams params = new LayoutParams();
		params.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_SPLIT_TOUCH | LayoutParams.FLAG_NOT_FOCUSABLE;
		params.type = LayoutParams.TYPE_APPLICATION_OVERLAY;
		params.format = PixelFormat.TRANSPARENT;
		float dp = getResources().getDisplayMetrics().density;
		params.gravity = gravity;
		params.x = (int) (x * dp);
		params.y = (int) (y * dp);
		params.width = (int) (width * dp);
		params.height = (int) (height * dp);
		return params;
	}

	private int getBattery(Context context) {
		int level = 0;
		Intent batteryInfoIntent = context.getApplicationContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		level = batteryInfoIntent.getIntExtra("level", 0);
		int batterySum = batteryInfoIntent.getIntExtra("scale", 100);
		return 100 * level / batterySum;
	}
}
