package nea.khtest;
import android.os.*;
import com.badlogic.gdx.backends.android.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.utils.*;
import static com.badlogic.gdx.graphics.VertexAttributes.Usage.*;
import com.badlogic.gdx.graphics.g3d.attributes.*;
import com.badlogic.gdx.math.*;
import java.util.*;

public class Main extends AndroidApplication implements ApplicationListener
{

	PerspectiveCamera camera;
	CameraInputController controller;
	ModelBatch batch;

	Model model;
	ModelInstance instance;

	Texture texture;

	@Override
	public void create()
	{
		batch = new ModelBatch();
		texture = new Texture("head.png");
		Material material = new Material(TextureAttribute.createDiffuse(texture));
		ModelBuilder builder = new ModelBuilder();
		builder.begin();
		MeshPartBuilder part = builder.part("1", GL20.GL_TRIANGLES, Position | TextureCoordinates | Normal, material);
		part.box(0, 0, 0, 1, 1, 1);
		model = builder.end();
		instance = new ModelInstance(model);
	}

	@Override
	public void resize(int width, int height)
	{
		camera = new PerspectiveCamera(67, width, height);
		camera.far = 256;
		camera.near = 1;
		camera.update();
		controller = new CameraInputController(camera);
		//controller.scrollTarget = true;
		Gdx.input.setInputProcessor(controller);
	}

	float deg;
	@Override
	public void render()
	{
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
		Gdx.gl.glClearColor(0.2f, 0.2f, 0.1f, 1);
		controller.update();
		ModelBatch batch = this.batch;
		ModelInstance instance = this.instance;
		Matrix4 transform = instance.transform;
		Random random = new Random(114514);
		batch.begin(camera);
		int r = 12, d = r * 2 + 1;
		for (int i = 0; i < 512; i ++)
		{
			transform.setToTranslation(random.nextInt(d) - r, random.nextInt(d) - r, random.nextInt(d) - r);
			//transform.rotateRad(random.nextFloat(), random.nextFloat(), random.nextFloat(), random.nextFloat() * 360);
			batch.render(instance);
		}
		deg += Gdx.graphics.getDeltaTime();
		deg %= 360;
		transform.setToTranslation(0, 0, 0);
		transform.scale(4, 4, 4);
		transform.rotateRad(1, 0, 1, deg);
		batch.render(instance);
		batch.end();
	}

	@Override
	public void pause()
	{
	}

	@Override
	public void resume()
	{
	}

	@Override
	public void dispose()
	{
		texture.dispose();
		model.dispose();
	}

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		initialize(this);
	}
}
